#include <stdio.h>

int main()
{
	int arr[4]={11,234,11,44};
	//scanf("%d", &n);
	for(int i=0; i<4; i++)
	{
		printf("%d ", arr[i]);
	}
	return 0;
}