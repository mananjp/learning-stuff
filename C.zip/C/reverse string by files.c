#include <stdio.h>
#include <string.h>

void reverseWord(char *word) {
    int start = 0, end = strlen(word) - 1;
    while (start < end) {
        char temp = word[start];
        word[start] = word[end];
        word[end] = temp;
        start++;
        end--;
    }
}

int main() {
    FILE *file;
    char word[100];

    file = fopen("Demo.txt", "w");
    if (file == NULL) {
        printf("Could not open file for writing\n");
        return 1;
    }

    fprintf(file, "HELLO");
    fclose(file);

    file = fopen("Demo.txt", "r");
    if (file == NULL) {
        printf("Could not open file for reading\n");
        return 1;
    }

    printf("Reversed words from the file: \n");
    printf("original word is: HELLO\n");
    while (fscanf(file, "%99s", word) != EOF) {
        reverseWord(word);
        printf("opposite word is: %s ", word);
        printf("\nname:Manan Panchal id:24AIML024");
    }

    fclose(file);
    return 0;
}
