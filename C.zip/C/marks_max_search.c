From: <Saved by Blink>
Snapshot-Content-Location: https://www.programiz.com/c-programming/online-compiler/
Subject: Online C Compiler - Programiz
Date: Thu, 15 Aug 2024 21:31:51 +0530
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----"


------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7AC728952CBADC39E374A72D4E05DF1C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8"><link rel=3D"stylesheet" type=3D"text/css" href=3D=
"cid:css-01c3eafd-e4c8-4500-abfb-912cc72404f7@mhtml.blink" /><link rel=3D"s=
tylesheet" type=3D"text/css" href=3D"cid:css-facb9104-6360-414d-9a79-992940=
a2dbb2@mhtml.blink" /><link rel=3D"stylesheet" type=3D"text/css" href=3D"ci=
d:css-b9aede08-502b-44ca-871f-1c68723f81a1@mhtml.blink" /><link rel=3D"styl=
esheet" type=3D"text/css" href=3D"cid:css-f87a3247-f892-4244-94a7-45597da84=
181@mhtml.blink" /><link rel=3D"stylesheet" type=3D"text/css" href=3D"cid:c=
ss-f006c9d3-7ffb-4592-856d-35bfe338443d@mhtml.blink" /><link rel=3D"stylesh=
eet" type=3D"text/css" href=3D"cid:css-e0468f17-4aff-495a-a888-fef7d9c708c2=
@mhtml.blink" />
  <title>
    Online C Compiler - Programiz  </title>
  <link rel=3D"shortcut icon" href=3D"https://www.programiz.com/sites/tutor=
ial2program/files/favicon.png">
  <meta name=3D"viewport" content=3D"width=3Ddevice-width, initial-scale=3D=
1, user-scalable=3D0">
  <link rel=3D"canonical" href=3D"https://www.programiz.com/c-programming/o=
nline-compiler/">
  <meta name=3D"description" content=3D"Write and run your C programming co=
de using our online compiler. Enjoy additional features like code sharing, =
dark mode, and support for multiple languages.">

  <!-- Facebook Meta Tags -->
  <meta property=3D"og:type" content=3D"website">
  <meta property=3D"og:url" content=3D"https://programiz.com/c-programming/=
online-compiler/">
  <meta property=3D"og:title" content=3D"Online C Compiler - Programiz">
  <meta property=3D"og:description" content=3D"Write and run your C program=
ming code using our online compiler. Enjoy additional features like code sh=
aring, dark mode, and support for multiple languages.">
  <meta property=3D"og:image" content=3D"https://programiz.com/online-compi=
ler/assets/logos/compiler_logo.png">

  <!-- Twitter Meta Tags -->
  <meta name=3D"twitter:card" content=3D"summary">
  <meta property=3D"twitter:url" content=3D"https://programiz.com/c-program=
ming/online-compiler/">
  <meta name=3D"twitter:title" content=3D"Online C Compiler - Programiz">
  <meta name=3D"twitter:description" content=3D"Write and run your C progra=
mming code using our online compiler. Enjoy additional features like code s=
haring, dark mode, and support for multiple languages.">
  <meta name=3D"twitter:image" content=3D"https://programiz.com/online-comp=
iler/assets/logos/compiler_logo.png">

  <!-- CMP and header ad code start -->
 =20

 =20
 =20
 =20
 =20
  <!-- CMP and header tag ad code end -->

  <!-- Google Tag Manager -->
 =20
  <!-- End Google Tag Manager -->

  <!-- Buy sellads CSS-->
 =20

  <!-- Generated using https://dns-prefetch-generator.github.io/ -->
  <meta http-equiv=3D"x-dns-prefetch-control" content=3D"on">
  <link rel=3D"dns-prefetch" href=3D"https://www.googletagservices.com/">
  <link rel=3D"dns-prefetch" href=3D"https://www.google-analytics.com/">
  <link rel=3D"dns-prefetch" href=3D"https://c.amazon-adsystem.com/">
  <link rel=3D"dns-prefetch" href=3D"https://dsh7ky7308k4b.cloudfront.net/"=
>
  <link rel=3D"dns-prefetch" href=3D"https://securepubads.g.doubleclick.net=
/">
  <link rel=3D"dns-prefetch" href=3D"https://adservice.google.com/">
  <link rel=3D"dns-prefetch" href=3D"https://cdnjs.cloudflare.com/">
  <link rel=3D"dns-prefetch" href=3D"https://www.googletagmanager.com/">

  <link rel=3D"stylesheet" href=3D"https://www.programiz.com/c-programming/=
online-compiler/playground.css?v=3D1fsaf">
  <!-- Global site tag (gtag.js) - Google Analytics -->

<link rel=3D"preload" as=3D"script" href=3D"https://securepubads.g.doublecl=
ick.net/tag/js/gpt.js"><link rel=3D"preconnect dns-prefetch" href=3D"https:=
//mp.4dex.io/prebid"><link rel=3D"preconnect dns-prefetch" href=3D"https://=
ib.adnxs.com/"><link rel=3D"preconnect dns-prefetch" href=3D"https://ice.36=
0yield.com/"><link rel=3D"preconnect dns-prefetch" href=3D"https://htlb.cas=
alemedia.com/cygnus"><link rel=3D"preconnect dns-prefetch" href=3D"https://=
onetag-sys.com/prebid-request"><link rel=3D"preconnect dns-prefetch" href=
=3D"https://fastlane.rubiconproject.com/"><link rel=3D"preconnect dns-prefe=
tch" href=3D"https://btlr.sharethrough.com/WYu2BXv1/v1"><link rel=3D"precon=
nect dns-prefetch" href=3D"https://prg.smartadserver.com/"><link rel=3D"pre=
connect dns-prefetch" href=3D"https://pbs.360yield.com/"><link rel=3D"preco=
nnect dns-prefetch" href=3D"https://prebid.adnxs.com/"><link rel=3D"preconn=
ect dns-prefetch" href=3D"https://prebid-server.rubiconproject.com/"><link =
rel=3D"preconnect dns-prefetch" href=3D"https://prebid.openx.net/"><link re=
l=3D"preload" as=3D"script" href=3D"https://c.amazon-adsystem.com/aax2/apst=
ag.js"><meta http-equiv=3D"origin-trial" content=3D"AlK2UR5SkAlj8jjdEc9p3F3=
xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcm=
lnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZ=
XF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWlu=
Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"Amm8/NmvvQfh=
wCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBws=
AAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dX=
JlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxO=
TksImlzU3ViZG9tYWluIjp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" cont=
ent=3D"A9uiHDzQFAhqALUhTgTYJcz9XrGH2y0/9AORwCSapUO/f7Uh7ysIzyszNkuWDLqNYg84=
46Uj48XIstBW1qv/wAQAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDM=
iLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3Mj=
c4MjcxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-=
equiv=3D"origin-trial" content=3D"A9R+gkZL3TWq+Z7RJ2L0c7ZN7FZD5z4mHmVvjrPit=
g/EMz9P3j5d3W7Vw5ZR9jtJGmWKltM4BO3smNzpCgwYuwwAAACTeyJvcmlnaW4iOiJodHRwczov=
L2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF=
1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3Mjc4MjcxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1=
RoaXJkUGFydHkiOnRydWV9"><link rel=3D"preload" as=3D"script" href=3D"https:/=
/cmp.uniconsent.com/v2/vendors-v4.js?v=3Dgp2"><meta http-equiv=3D"origin-tr=
ial" content=3D"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNo=
vG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2=
F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5I=
joxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D=
"><meta http-equiv=3D"origin-trial" content=3D"A7CQXglZzTrThjGTBEn1rWTxHOEt=
kWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4=
iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3=
hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZ=
FBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"A3vKT=
9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUq=
AYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJ=
mZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1=
N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D=
"origin-trial" content=3D"A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+Njyardrwlie=
SjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJs=
ZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ=
5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=
=3D"><meta http-equiv=3D"origin-trial" content=3D"A3vKT9yxRPjmXN3DpIiz58f5J=
ykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmln=
aW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmF=
jeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZS=
wiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" conte=
nt=3D"A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9s=
vD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMi=
LCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJ=
pc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=
=3D"origin-trial" content=3D"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jP=
pQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb=
2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElz=
IiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp=
0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"A7CQXglZzTrThjG=
TBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAA=
CFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpd=
mFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1=
ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" con=
tent=3D"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6m=
Rmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLm=
NvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1M=
TY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta =
http-equiv=3D"origin-trial" content=3D"A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzge=
a+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHR=
wczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUE=
lzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5I=
jp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"A3vKT9yxRPjmX=
N3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEA=
AACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJ=
lIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbW=
FpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-=
trial" content=3D"A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44=
PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNr=
Lm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk=
1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><met=
a http-equiv=3D"origin-trial" content=3D"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/=
W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJod=
HRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRi=
b3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGl=
yZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"A7C=
QXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yed=
n0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0d=
XJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRv=
bWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"><meta http-equiv=3D"origi=
n-trial" content=3D"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbA=
DiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bm=
RpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwa=
XJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=
=3D=3D"><meta http-equiv=3D"origin-trial" content=3D"A7CQXglZzTrThjGTBEn1rW=
TxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvc=
mlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNh=
bmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXN=
UaGlyZFBhcnR5Ijp0cnVlfQ=3D=3D"></head>

<body><div id=3D"uniccmp" data-nosnippet=3D""></div>
  <!-- <select id=3D"language-changer"></select> -->
  <div class=3D"container" id=3D"root" data-lang=3D"c">
    <div class=3D"spinner" style=3D"display: none;">
      <div class=3D"loader"><span>{</span><span>}</span></div>
    </div>
    <div class=3D"mobile-nav-drawer show">
      <div class=3D"nav-backdrop">
      </div>
      <div class=3D"nav-menu">
        <div class=3D"nav-header-wrapper">
          <div class=3D"nav-logo-title-wrapper">
            <a href=3D"https://www.programiz.com/" target=3D"_blank" class=
=3D"nav-logo-link">
              <img id=3D"nav-logo" src=3D"https://www.programiz.com/c-progr=
amming/online-compiler/assets/logos/logo.svg">
            </a>
          </div>
          <button type=3D"button" class=3D"close-nav-btn" title=3D"Close na=
vigation">
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"24" height=
=3D"24" viewBox=3D"0 0 24 24" fill=3D"none" class=3D"svg replaced-svg">
<path d=3D"M19 4.85352L5.00006 18.8535" stroke=3D"#25265E" stroke-opacity=
=3D"0.7" stroke-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"rou=
nd"></path>
<path d=3D"M5 4.85352L18.9999 18.8535" stroke=3D"#25265E" stroke-opacity=3D=
"0.7" stroke-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"=
></path>
</svg>
          </button>
        </div>
        <div class=3D"nav-menu-list">
          <a target=3D"_blank" href=3D"https://www.programiz.com/python-pro=
gramming/online-compiler/" class=3D"change-lang-row python " title=3D"Pytho=
n Online Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewB=
ox=3D"0 0 24 25" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M9.091 11.663h5.782c1.61 0 2.877-1.353 2.8=
77-2.96V3.225c0-1.559-1.315-2.73-2.886-2.99A18.088 18.088 0 0011.853 0a16.2=
5 16.25 0 00-2.738.235c-2.45.43-2.866 1.33-2.866 2.99v2.132H12v.788H4.025C2=
.342 6.145.868 7.152.408 9.064c-.532 2.191-.556 3.531 0 5.82.411 1.702 1.39=
4 2.888 3.076 2.888h1.972V15.2c0-1.9 1.672-3.538 3.635-3.538zm-.364-7.707c-=
.6 0-1.087-.489-1.087-1.093 0-.606.486-1.1 1.087-1.1.597 0 1.086.494 1.086 =
1.1a1.09 1.09 0 01-1.086 1.093zm14.83 5.108c-.416-1.665-1.21-2.919-2.895-2.=
919h-2.118v2.558c0 1.98-1.744 3.551-3.671 3.551H9.091c-1.584 0-2.842 1.444-=
2.842 3.02v5.479c0 1.558 1.338 2.475 2.868 2.923 1.833.535 3.568.632 5.76 0=
 1.458-.42 2.873-1.264 2.873-2.923V18.56H12v-.788h8.662c1.682 0 2.31-1.138 =
2.895-2.89.604-1.801.578-3.506 0-5.818zm-8.32 10.958c.6 0 1.087.488 1.087 1=
.093 0 .606-.486 1.1-1.087 1.1a1.095 1.095 0 01-1.086-1.1 1.09 1.09 0 011.0=
86-1.093z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Python Online Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/r/online-c=
ompiler/" class=3D"change-lang-row r " title=3D"Online R Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=
=3D"40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<g clip-path=3D"url(#clip0_2886_601)">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M20.4449 31.25C31.18=
85 31.25 38.7187 25.3737 38.7187 18.125C38.7187 10.8763 32.1297 5 19.2656 5=
C8.52191 5 -0.1875 10.8763 -0.1875 18.125C-0.1875 25.3737 9.70118 31.25 20.=
4449 31.25ZM23.1934 27.9688C31.2187 27.9688 36.8437 23.9813 36.8437 19.0625=
C36.8437 14.1437 31.9219 10.1562 22.3125 10.1562C14.2871 10.1562 7.78131 14=
.1437 7.78131 19.0625C7.78131 23.9813 15.168 27.9688 23.1934 27.9688Z" fill=
=3D"#6D6D93"></path>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M16.2188 35H22.7814V=
26.3281H24.2416C24.9302 26.3281 25.5635 26.7057 25.891 27.3116L30.047 35H37=
.547L32.9028 26.9784C32.572 26.4069 32.0506 25.9702 31.43 25.7445L29.8126 2=
5.1562C32.3907 25.1562 35.2032 23.0469 35.4376 19.5312C35.672 16.0156 34.03=
14 13.2031 29.8126 13.2031H16.2188V35ZM27.0001 17.6562H22.7814V21.875H27.00=
01C29.3437 21.875 29.3437 17.6562 27.0001 17.6562Z" fill=3D"#6D6D93"></path=
>
</g>
<defs>
<clipPath id=3D"clip0_2886_601">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online R Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/sql/online=
-compiler/" class=3D"change-lang-row sql" title=3D"SQL Online Editor">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"21" height=
=3D"28" viewBox=3D"0 0 21 28" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M10.8017 4.96503C16.=
2496 4.96503 20.6659 4.07743 20.6659 2.98251C20.6659 1.8876 16.2496 1 10.80=
17 1C5.35386 1 0.9375 1.8876 0.9375 2.98251C0.9375 4.07743 5.35386 4.96503 =
10.8017 4.96503ZM10.8019 4.19152C15.7423 4.19152 19.7474 3.58535 19.7474 2.=
8376C19.7474 2.08986 15.7423 1.48369 10.8019 1.48369C5.86141 1.48369 1.8563=
8 2.08986 1.85638 2.8376C1.85638 3.58535 5.86141 4.19152 10.8019 4.19152Z" =
fill=3D"#A8A8BF"></path>
<path d=3D"M20.3659 2.98251C20.3659 3.01082 20.353 3.0721 20.2553 3.16803C2=
0.1571 3.26451 19.9962 3.37195 19.762 3.48323C19.2951 3.70509 18.6003 3.912=
85 17.7177 4.09024C15.9573 4.44404 13.512 4.66503 10.8017 4.66503V5.26503C1=
3.5393 5.26503 16.0261 5.04221 17.8359 4.67848C18.7383 4.49711 19.4881 4.27=
768 20.0195 4.02516C20.2845 3.89926 20.5112 3.75773 20.6757 3.59609C20.8409=
 3.4339 20.9659 3.22793 20.9659 2.98251H20.3659ZM10.8017 1.3C13.512 1.3 15.=
9573 1.52099 17.7177 1.87478C18.6003 2.05218 19.2951 2.25994 19.762 2.4818C=
19.9962 2.59307 20.1571 2.70052 20.2553 2.797C20.353 2.89292 20.3659 2.9542=
 20.3659 2.98251H20.9659C20.9659 2.7371 20.8409 2.53113 20.6757 2.36894C20.=
5112 2.2073 20.2845 2.06577 20.0195 1.93986C19.4881 1.68735 18.7383 1.46792=
 17.8359 1.28655C16.0261 0.922815 13.5393 0.7 10.8017 0.7V1.3ZM1.2375 2.982=
51C1.2375 2.9542 1.25046 2.89292 1.34812 2.797C1.44635 2.70052 1.60725 2.59=
307 1.84143 2.4818C2.30833 2.25994 3.00312 2.05218 3.88577 1.87478C5.64613 =
1.52099 8.09145 1.3 10.8017 1.3V0.7C8.06413 0.7 5.57733 0.922815 3.76755 1.=
28655C2.86513 1.46792 2.11534 1.68735 1.58392 1.93986C1.31896 2.06577 1.092=
26 2.2073 0.927691 2.36894C0.762556 2.53113 0.6375 2.7371 0.6375 2.98251H1.=
2375ZM10.8017 4.66503C8.09145 4.66503 5.64613 4.44404 3.88577 4.09024C3.003=
12 3.91285 2.30833 3.70509 1.84143 3.48323C1.60725 3.37195 1.44635 3.26451 =
1.34812 3.16803C1.25046 3.0721 1.2375 3.01082 1.2375 2.98251H0.6375C0.6375 =
3.22793 0.762556 3.4339 0.927691 3.59609C1.09226 3.75773 1.31896 3.89926 1.=
58392 4.02516C2.11534 4.27768 2.86513 4.49711 3.76755 4.67848C5.57733 5.042=
21 8.06413 5.26503 10.8017 5.26503V4.66503ZM19.4474 2.8376C19.4474 2.78735 =
19.4799 2.8007 19.3872 2.86927C19.3023 2.9321 19.158 3.00532 18.9433 3.0821=
5C18.5175 3.2345 17.8846 3.37692 17.0824 3.49834C15.4825 3.74048 13.2619 3.=
89152 10.8019 3.89152V4.49152C13.2823 4.49152 15.5344 4.33947 17.1722 4.091=
59C17.9887 3.968 18.6659 3.81867 19.1454 3.64707C19.3834 3.56191 19.5906 3.=
46511 19.744 3.35166C19.8896 3.24396 20.0474 3.07479 20.0474 2.8376H19.4474=
ZM10.8019 1.78369C13.2619 1.78369 15.4825 1.93473 17.0824 2.17687C17.8846 2=
.29829 18.5175 2.4407 18.9433 2.59306C19.158 2.66989 19.3023 2.74311 19.387=
2 2.80594C19.4799 2.87451 19.4474 2.88785 19.4474 2.8376H20.0474C20.0474 2.=
60042 19.8896 2.43125 19.744 2.32355C19.5906 2.2101 19.3834 2.11329 19.1454=
 2.02814C18.6659 1.85654 17.9887 1.70721 17.1722 1.58362C15.5344 1.33574 13=
.2823 1.18369 10.8019 1.18369V1.78369ZM2.15638 2.8376C2.15638 2.88785 2.123=
8 2.87451 2.21651 2.80594C2.30145 2.74311 2.44574 2.66989 2.66043 2.59306C3=
.08621 2.4407 3.71909 2.29829 4.52134 2.17687C6.1212 1.93473 8.34185 1.7836=
9 10.8019 1.78369V1.18369C8.32142 1.18369 6.06933 1.33574 4.43155 1.58362C3=
.61499 1.70721 2.93784 1.85654 2.45828 2.02814C2.22031 2.11329 2.0131 2.210=
1 1.85972 2.32355C1.71411 2.43125 1.55638 2.60042 1.55638 2.8376H2.15638ZM1=
0.8019 3.89152C8.34185 3.89152 6.1212 3.74048 4.52134 3.49834C3.71909 3.376=
92 3.08621 3.2345 2.66043 3.08215C2.44574 3.00532 2.30145 2.9321 2.21651 2.=
86927C2.1238 2.8007 2.15638 2.78735 2.15638 2.8376H1.55638C1.55638 3.07479 =
1.71411 3.24396 1.85972 3.35166C2.0131 3.46511 2.22031 3.56191 2.45828 3.64=
707C2.93784 3.81867 3.61499 3.968 4.43155 4.09159C6.06933 4.33947 8.32142 4=
.49152 10.8019 4.49152V3.89152Z" fill=3D"#A8A8BF"></path>
<path d=3D"M0.9375 2.93359C0.9375 2.93359 4.43011 4.25786 10.7679 4.25786C1=
7.1057 4.25786 20.6659 2.93359 20.6659 2.93359V8.76378C20.6659 8.76378 20.1=
582 11.1054 10.8017 11.1054C1.44522 11.1054 0.9375 8.76378 0.9375 8.76378V2=
.93359Z" fill=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-li=
necap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M0.9375 11.0636C0.9375 11.0636 0.944635 10.9089 0.985854 10.8218=
C1.04301 10.7012 1.22762 10.5801 1.22762 10.5801C1.22762 10.5801 2.92001 12=
.3208 10.8017 12.3208C18.6834 12.3208 20.3033 10.5801 20.3033 10.5801C20.49=
98 10.6953 20.6196 10.8408 20.6659 11.0636V16.8938C20.6659 16.8938 20.1582 =
19.2354 10.8017 19.2354C1.44522 19.2354 0.9375 16.8938 0.9375 16.8938V11.06=
36Z" fill=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-lineca=
p=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M0.9375 19.2238C0.9375 19.2238 0.944635 19.069 0.985854 18.982C1=
.04301 18.8613 1.22762 18.7402 1.22762 18.7402C1.22762 18.7402 2.92001 20.4=
81 10.8017 20.481C18.6834 20.481 20.3033 18.7402 20.3033 18.7402C20.4998 18=
.8554 20.6196 19.0009 20.6659 19.2238V25.054C20.6659 25.054 20.1582 27.3956=
 10.8017 27.3956C1.44522 27.3956 0.9375 25.054 0.9375 25.054V19.2238Z" fill=
=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-linecap=3D"roun=
d" stroke-linejoin=3D"round"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              SQL Online Editor
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/html/onlin=
e-compiler/" class=3D"change-lang-row html" title=3D"Online HTML/CSS Editor=
">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"86" height=
=3D"98" viewBox=3D"0 0 86 98" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M0 0L7.81641 87.668L=
42.8914 97.4047L78.0625 87.6547L85.8875 0H0ZM42.9624 39.9803H28.7717L27.788=
9 28.9693H42.9624H42.9998H68.9343L69.1499 26.5537L69.6405 21.1021L69.8976 1=
8.2178H42.9998H42.9624H16.0381L16.2959 21.1021L18.9381 50.7326H42.9624H42.9=
998H56.2022L54.9546 64.6772L42.9624 67.9139V67.9149L42.9521 67.9178L30.9779=
 64.6834L30.2131 56.1092H19.4186L20.9248 72.9912L42.9506 79.1053L42.9998 79=
.092V79.0902L65.0054 72.9912L65.1671 71.1748L67.6936 42.8678L67.9554 39.980=
3H65.0585H42.9998H42.9624Z" fill=3D"#F9F7F7"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online HTML/CSS Editor
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/java-progr=
amming/online-compiler/" class=3D"change-lang-row java " title=3D"Online Ja=
va Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewB=
ox=3D"0 0 21 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-rule=3D"evenodd" d=3D"M13.266 1s2.718 2.703-2.578 6.857c-3.285=
 2.578-2.069 4.3-.902 5.951.343.485.68.963.9 1.456-2.48-2.223-4.298-4.18-3.=
078-6.002.596-.89 1.543-1.626 2.501-2.372 1.922-1.495 3.889-3.026 3.157-5.8=
9zm-1.403 12.431c1.263 1.445-.331 2.744-.331 2.744s3.204-1.644 1.733-3.703a=
46.915 46.915 0 00-.175-.242c-1.278-1.764-2.008-2.772 3.452-5.92 0 0-8.956 =
2.223-4.679 7.122zm-4.65 7.678s-.998.577.713.772c2.073.236 3.133.202 5.417-=
.227 0 0 .601.374 1.44.698-5.122 2.18-11.592-.127-7.57-1.244zm-.625-2.847s-=
1.121.825.591 1.001c2.215.227 3.964.246 6.99-.333 0 0 .419.422 1.076.652-6.=
191 1.8-13.088.142-8.657-1.32zm11.235 6.028c1.554-.468.815-1.075.815-1.075 =
2.708 1.215-5.885 3.655-16.326 1.972-3.83-.617 1.842-2.77 2.88-2.044 0 0-.3=
28-.022-.902.101-.55.118-2.3.678-1.368 1.082 2.597 1.122 11.945.854 14.9-.0=
36zM6.01 16.845c-3.07-.409 1.684-1.531 1.684-1.531s-1.847-.124-4.117.967c-2=
.686 1.29 6.641 1.879 11.47.616.503-.34 1.196-.636 1.196-.636s-1.975.351-3.=
943.516c-2.409.2-4.993.24-6.29.067zM17.28 15.41c1.584-.328 3.854 2.108-1.05=
5 4.642-.02.055-.084.115-.096.127l-.002.001c6.555-1.712 4.145-6.036 1.011-4=
.941a.89.89 0 00-.419.321s.174-.07.561-.15zm3.017 9.127c-.172 2.216-7.408 2=
.681-12.118 2.382-3.096-.198-3.699-.694-3.699-.694 2.941.483 7.902.57 11.92=
3-.182 3.564-.666 3.893-1.506 3.893-1.506z" clip-rule=3D"evenodd"></path>
  <path d=3D"M10.688 7.857l-.186-.236.186.236zM13.266 1l.212-.213a.3.3 0 00=
-.502.287l.29-.074zm-3.48 12.808l-.245.174.245-.174zm.9 1.456l-.2.223a.3.3 =
0 00.474-.345l-.274.122zM7.608 9.262l-.25-.167.25.167zm2.501-2.372l.184.237=
-.184-.237zm1.423 9.285l-.19-.233a.3.3 0 00.327.5l-.137-.267zm.331-2.744l-.=
226.198.226-.197zm1.402-.96l.244-.174-.244.175zm-.175-.241l-.243.176.243-.1=
76zm3.452-5.92l.15.26a.3.3 0 00-.222-.55l.072.29zM7.926 21.882l-.034.298.03=
4-.298zm-.712-.773l.15.26a.3.3 0 00-.23-.549l.08.29zm6.129.546l.158-.255a.3=
.3 0 00-.214-.04l.056.295zm1.44.698l.118.276a.3.3 0 00-.01-.556l-.108.28zM7=
.18 19.263l-.03.298.03-.298zm-.591-1l.177.24a.3.3 0 00-.271-.526l.094.285zm=
7.582.667l.213-.211a.3.3 0 00-.27-.084l.057.295zm1.075.652l.084.288a.3.3 0 =
00.016-.571l-.1.283zm3.393 3.633l.122-.273a.3.3 0 00-.312.505l.19-.232zm-.8=
15 1.075l.086.287-.086-.287zm-15.511.897l-.048.297.048-.297zm2.88-2.044l-.0=
2.3a.3.3 0 00.192-.546l-.172.246zm-.902.101l.063.293-.063-.293zm-1.368 1.08=
2l-.119.275.12-.275zm4.773-9.012l.069.292a.3.3 0 00-.049-.591l-.02.299zm-1.=
684 1.53l.04-.297-.04.297zm-2.433-.563l.13.27-.13-.27zm11.47.616l.077.29a.3=
01.301 0 00.092-.042l-.168-.248zm1.196-.636l.118.276a.3.3 0 00-.17-.571l.05=
2.295zm-3.943.516l.025.299-.025-.3zm3.923 3.275l-.137-.267a.3.3 0 00-.143.1=
6l.28.107zm1.055-4.642l.061.294-.06-.294zm-1.15 4.769l-.208-.218-.005.005.2=
12.213zm0 0l.208.215.003-.003-.212-.212zm-.003.001l-.209-.215a.3.3 0 00.285=
.506l-.076-.29zm1.011-4.941l-.099-.284.1.284zm-.419.321l-.252-.162a.3.3 0 0=
0.364.44l-.112-.278zm-8.54 11.36l-.02.298.02-.299zm12.117-2.383l.3.023a.3.3=
 0 00-.579-.132l.28.11zM4.48 26.225l.049-.296a.3.3 0 00-.349.296h.3zm11.923=
-.182l-.055-.295.055.295zm-5.53-17.95c2.69-2.11 3.41-3.904 3.391-5.227-.01-=
.655-.2-1.17-.391-1.521a2.916 2.916 0 00-.353-.514 1.677 1.677 0 00-.036-.0=
39L13.48.79h-.001V.787L13.265 1c-.211.213-.211.213-.212.212l.002.003.016.01=
6c.014.017.037.042.064.078.055.07.131.178.208.32.154.286.311.706.32 1.246.0=
15 1.067-.555 2.702-3.162 4.746l.37.473zm-.84 5.542c-.597-.844-1.13-1.613-1=
.165-2.467-.033-.82.397-1.812 2.006-3.075l-.37-.472c-1.677 1.316-2.28 2.473=
-2.235 3.571.043 1.064.703 1.982 1.273 2.79l.49-.347zm.928 1.507c-.233-.525=
-.59-1.028-.929-1.507l-.49.347c.347.49.666.944.871 1.404l.548-.244zM7.358 9=
.095c-.34.51-.475 1.04-.432 1.585.043.537.257 1.068.578 1.59.638 1.037 1.74=
5 2.108 2.982 3.217l.4-.446c-1.242-1.114-2.285-2.133-2.871-3.086-.291-.473-=
.458-.912-.49-1.323-.033-.404.063-.801.332-1.203l-.499-.334zm2.567-2.442c-.=
948.738-1.938 1.505-2.567 2.442l.499.334c.564-.841 1.468-1.549 2.436-2.302l=
-.368-.474zm3.05-5.579c.343 1.342.056 2.352-.54 3.214-.609.882-1.54 1.61-2.=
51 2.365l.368.474c.953-.741 1.965-1.526 2.637-2.498.685-.993 1.016-2.18.627=
-3.703l-.582.148zm-1.443 15.1l.19.233.002-.002.006-.004a12.436 12.436 0 00.=
073-.066 2.969 2.969 0 00.639-.861c.137-.287.235-.64.201-1.03-.034-.395-.2-=
.806-.554-1.21l-.452.395c.279.318.386.612.408.866a1.39 1.39 0 01-.145.72 2.=
287 2.287 0 01-.556.726l-.002.002.19.232zm1.49-3.528c.32.45.375.854.3 1.211=
-.079.37-.303.722-.592 1.035a5.084 5.084 0 01-.888.745 5.698 5.698 0 01-.41=
7.255l-.024.013-.005.002h-.001l.137.268.137.267.001-.001.003-.001a5.685 5.6=
85 0 001.498-1.14c.328-.356.629-.802.738-1.319.111-.53.014-1.104-.4-1.684l-=
.488.35zm-.175-.24l.174.24.488-.349-.176-.243-.486.352zm3.545-6.355c-1.371.=
79-2.366 1.453-3.064 2.034-.696.577-1.12 1.093-1.318 1.595-.204.519-.15.99.=
036 1.439.179.43.488.854.801 1.287l.486-.352c-.325-.45-.587-.813-.733-1.166=
-.14-.335-.168-.642-.031-.99.143-.363.479-.8 1.142-1.352.66-.549 1.622-1.19=
2 2.98-1.975l-.299-.52zm-4.303 7.183c-1.026-1.175-1.214-2.133-1.01-2.905.21=
2-.794.86-1.479 1.69-2.047.823-.564 1.783-.985 2.544-1.266a15.575 15.575 0 =
011.296-.413h.004l.001-.001-.072-.291-.073-.291h-.002l-.005.002a3.097 3.097=
 0 00-.098.025 16.165 16.165 0 00-1.258.406c-.784.29-1.796.73-2.677 1.334-.=
875.6-1.664 1.388-1.93 2.388-.27 1.023.026 2.18 1.138 3.454l.452-.395zm-4.1=
3 8.35c-.417-.048-.627-.116-.72-.168-.045-.024-.041-.034-.03-.015a.124.124 =
0 01.013.083c-.005.02-.003-.003.057-.054a.704.704 0 01.082-.06l.004-.002-.1=
51-.26-.15-.26v.001h-.001l-.002.001-.004.003a1.94 1.94 0 00-.05.032c-.031.0=
2-.073.05-.117.089-.074.063-.215.197-.255.385a.477.477 0 00.054.342.658.658=
 0 00.258.24c.2.11.507.189.945.238l.068-.596zm5.328-.225c-2.256.424-3.285.4=
56-5.327.224l-.068.596c2.105.24 3.194.204 5.506-.23l-.11-.59zm1.604.713a9.7=
37 9.737 0 01-1.367-.659c-.008-.005-.014-.009-.018-.01l-.004-.003-.001-.001=
-.158.255-.159.255h.001l.002.001.006.004.023.014.084.05a10.362 10.362 0 001=
.375.654l.216-.56zm-7.757-1.253c-.517.144-.905.316-1.152.523a.919.919 0 00-=
.284.379.665.665 0 00-.001.46c.098.276.358.488.648.649.302.168.696.313 1.15=
.428 1.81.457 4.777.49 7.406-.63l-.235-.552c-2.494 1.061-5.324 1.03-7.023.6=
a4.304 4.304 0 01-1.007-.37c-.256-.143-.352-.263-.374-.326a.066.066 0 01-.0=
01-.051.335.335 0 01.106-.127c.149-.125.438-.269.927-.404l-.16-.579zm.076-1=
.854c-.415-.043-.597-.121-.665-.172-.028-.021-.024-.027-.02-.014.004.012 0 =
.015.004.001a.509.509 0 01.125-.176 1.176 1.176 0 01.106-.096l.005-.004h.00=
1l-.178-.242-.178-.241h-.001l-.002.001-.004.003-.012.01a1.51 1.51 0 00-.166=
.15c-.088.088-.218.24-.272.428-.029.1-.04.22 0 .346a.63.63 0 00.231.313c.20=
3.153.523.244.965.29l.061-.597zm6.904-.33c-2.996.573-4.715.554-6.904.33l-.0=
61.596c2.24.23 4.018.248 7.077-.337l-.113-.589zm1.23.664a2.835 2.835 0 01-.=
96-.579l-.002-.002h.001l-.213.212a46.433 46.433 0 00-.213.211v.001l.003.002=
.005.005.018.018.065.058a3.438 3.438 0 001.098.64l.199-.566zm-8.85-1.322c-.=
566.187-.984.386-1.25.603-.265.216-.45.517-.325.86.104.287.394.487.703.629.=
327.15.756.275 1.255.37 1.993.382 5.313.343 8.452-.569l-.167-.576c-3.052.88=
7-6.276.92-8.172.556-.473-.09-.85-.203-1.117-.326-.284-.131-.374-.243-.39-.=
288-.003-.009-.005-.016.003-.036a.457.457 0 01.137-.155c.18-.147.516-.319 1=
.059-.498l-.188-.57zm12.144 5.238l-.19.232h-.001l-.002-.001v-.001c-.001 0-.=
001 0 0 0l.008.008c.008.008.02.021.03.037.025.035.031.06.03.074 0 .001.002.=
047-.098.129-.106.087-.309.198-.679.31l.173.574c.408-.123.695-.263.888-.42.=
198-.164.307-.358.316-.567a.722.722 0 00-.139-.445.907.907 0 00-.127-.145l-=
.012-.01-.004-.004-.002-.002-.191.231zM2.264 25.484c5.253.846 10.045.657 13=
.194.1 1.564-.278 2.76-.652 3.4-1.058.163-.104.305-.218.407-.345a.724.724 0=
 00.177-.47c-.008-.372-.334-.613-.681-.77l-.246.548c.15.068.24.13.287.178.0=
23.023.033.04.037.048l.003.008v.005a.26.26 0 01-.044.076c-.047.059-.13.132-=
.261.215-.535.34-1.632.699-3.183.973-3.081.546-7.806.735-12.995-.1l-.095.59=
2zm3.1-2.587c-.202-.14-.475-.19-.74-.2a4.4 4.4 0 00-.91.077 7.598 7.598 0 0=
0-1.92.618c-.28.137-.534.293-.725.46-.18.158-.36.376-.369.643-.01.302.193.5=
18.447.66.255.141.626.25 1.117.329l.095-.593c-.466-.075-.756-.17-.92-.26a.4=
11.411 0 01-.13-.102l-.009-.013c0-.01.017-.083.164-.213.136-.12.34-.247.595=
-.372a7.003 7.003 0 011.759-.566c.295-.053.565-.076.784-.068.229.009.36.051=
.418.092l.344-.492zm-1.01.64c.271-.058.482-.081.621-.09a2.307 2.307 0 01.19=
7-.005l.02-.299.02-.3h-.024a2.871 2.871 0 00-.25.005 4.88 4.88 0 00-.711.10=
3l.126.586zm-1.313.513c-.097-.042-.115-.069-.11-.061.02.027.03.078.015.119-=
.006.017-.006.002.044-.039.045-.037.112-.08.2-.126.356-.188.903-.35 1.163-.=
406l-.126-.586c-.29.062-.894.239-1.317.461-.107.057-.212.121-.3.193a.715.71=
5 0 00-.226.293.464.464 0 00.066.45.85.85 0 00.353.253l.238-.55zm14.695-.04=
7c-1.434.431-4.473.721-7.502.76-1.508.018-3.002-.026-4.276-.143-1.285-.119-=
2.315-.31-2.917-.57l-.238.55c.696.302 1.809.498 3.1.617 1.3.12 2.816.164 4.=
339.145 3.033-.038 6.146-.327 7.667-.785l-.173-.574zM7.695 15.314l-.07-.292=
h-.003c-.002.002-.006.002-.01.003l-.041.01a16.032 16.032 0 00-.652.172c-.40=
1.112-.913.27-1.332.442-.208.086-.406.18-.559.282-.076.051-.152.11-.213.18a=
.521.521 0 00-.135.297.45.45 0 00.128.35c.076.08.176.137.276.18.202.086.497=
.152.888.204l.079-.595c-.377-.05-.606-.108-.732-.162-.063-.027-.079-.043-.0=
75-.04.01.012.039.053.034.114-.004.047-.026.064-.011.047a.495.495 0 01.094-=
.075c.104-.07.26-.147.455-.227.386-.16.87-.309 1.265-.42a20.51 20.51 0 01.6=
32-.166l.038-.01.01-.001h.002v-.001l-.068-.292zm-3.987 1.237a9.68 9.68 0 01=
2.822-.866c.36-.05.65-.068.849-.074a4.554 4.554 0 01.28.002h.016l.02-.299.0=
2-.3h-.001-.027a3.501 3.501 0 00-.324-.002 8.124 8.124 0 00-.917.08c-.77.10=
8-1.83.357-2.998.919l.26.54zm11.265.056c-2.373.62-5.878.79-8.46.64-1.3-.075=
-2.323-.23-2.849-.428a.984.984 0 01-.252-.128c-.045-.036-.014-.03-.011.023.=
003.054-.029.062.018.017.045-.044.134-.105.289-.18l-.26-.54c-.181.087-.334.=
18-.445.287a.581.581 0 00-.201.448c.01.19.126.327.236.414.112.09.257.16.414=
.22.619.235 1.725.39 3.026.466 2.617.151 6.19-.017 8.647-.659l-.152-.58zm1.=
271-.346l-.117-.276h-.001l-.002.001a7.207 7.207 0 00-1.243.662l.336.497c.23=
4-.158.52-.31.75-.424a9.775 9.775 0 01.367-.172l.021-.009.006-.002-.117-.27=
7zm-3.918.815a45.615 45.615 0 002.728-.322 52.192 52.192 0 001.152-.182l.06=
7-.011.018-.003.004-.001h.001l-.052-.296-.052-.295h-.002-.004c-.003.002-.00=
9.002-.016.004a13.238 13.238 0 01-.314.053c-.214.035-.52.084-.889.137a45.05=
 45.05 0 01-2.69.318l.05.598zm-6.354.066c1.33.177 3.941.135 6.354-.066l-.05=
-.598c-2.404.2-4.962.237-6.225.07l-.08.594zm10.39 3.177c2.47-1.276 3.309-2.=
614 3.12-3.712-.184-1.077-1.331-1.684-2.264-1.49l.122.587c.652-.135 1.432.3=
12 1.551 1.005.115.671-.366 1.817-2.804 3.076l.275.534zm-.027.077a.91.91 0 =
00.066-.07.584.584 0 00.104-.168l-.561-.212a.147.147 0 01.007-.016l.002-.00=
3-.008.01a.326.326 0 01-.024.024l.414.435zm.005-.005l-.424-.425.424.425zm-.=
004.004l.002-.001-.419-.43-.002.001.419.43zm.9-4.873c1.441-.503 2.593.258 2=
.732 1.18.07.463-.093 1.038-.687 1.615-.597.58-1.622 1.153-3.23 1.573l.151.=
58c1.669-.435 2.8-1.046 3.497-1.723.701-.681.968-1.44.863-2.135-.21-1.394-1=
.83-2.248-3.524-1.656l.198.566zm-.518.038l.253.162-.001.001v.001l-.001.001v=
-.002l.011-.014a.594.594 0 01.257-.187l-.2-.566a1.169 1.169 0 00-.566.434l-=
.003.005-.001.002h-.001v.001l.252.162zm.5-.444a5.432 5.432 0 00-.566.149 1.=
725 1.725 0 00-.04.015h-.003l-.002.001.111.28.112.278h-.001l.003-.001.018-.=
007a4.842 4.842 0 01.49-.127l-.122-.588zm-9.06 12.102c2.37.151 5.38.11 7.82=
5-.25 1.22-.18 2.32-.441 3.133-.809.793-.358 1.422-.868 1.479-1.599l-.599-.=
046c-.029.377-.368.756-1.127 1.099-.739.333-1.775.585-2.974.761-2.393.353-5=
.358.395-7.698.246l-.038.598zm-3.979-.993a.622.622 0 00.105.228l.004.003a.4=
1.41 0 00.004.004l.006.005a.385.385 0 00.055.037c.033.02.079.046.14.075.123=
.058.312.132.594.21.564.156 1.51.332 3.071.431l.039-.598c-1.535-.098-2.438-=
.27-2.95-.411a3.156 3.156 0 01-.497-.174.819.819 0 01-.081-.043l-.008-.005.=
003.002.003.003.004.002.003.004a.622.622 0 01.105.228h-.6zm12.168-.477c-3.9=
85.746-8.91.659-11.82.181l-.097.592c2.974.488 7.97.576 12.027-.183l-.11-.59=
zm3.948-1.21l-.279-.111v-.001l.002-.002v-.003l.003-.006a.173.173 0 01.004-.=
007l-.001.002a.426.426 0 01-.05.06c-.063.064-.19.173-.434.308-.49.272-1.428=
.64-3.193.97l.11.59c1.8-.336 2.808-.72 3.374-1.035.284-.158.462-.301.573-.4=
15a1.027 1.027 0 00.153-.203.499.499 0 00.015-.03l.001-.005.001-.001v-.001l=
-.279-.11z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online Java Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/c-programm=
ing/online-compiler/" class=3D"change-lang-row c active" title=3D"C Online =
Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewB=
ox=3D"0 0 24 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M23.903 6.916l.067-.044c-.134-.243-.334-.4=
64-.534-.574L12.696.155C12.518.045 12.274 0 12.007 0c-.267 0-.511.066-.69.1=
55L.646 6.32C.267 6.54 0 7.093 0 7.513v12.308c0 .243.044.508.2.752l-.044.02=
2c.11.176.266.331.422.42l10.718 6.165c.178.11.422.154.689.154.267 0 .511-.0=
66.69-.154l10.672-6.165c.378-.221.645-.774.645-1.194V7.491c.022-.177 0-.376=
-.089-.575zM12.007 19.07a5.455 5.455 0 004.736-2.74l2.869 1.68a8.794 8.794 =
0 01-7.605 4.374c-4.847 0-8.783-3.91-8.783-8.728 0-4.817 3.936-8.728 8.783-=
8.728a8.796 8.796 0 017.627 4.42l-2.89 1.656a5.43 5.43 0 00-4.737-2.762c-3.=
002 0-5.448 2.431-5.448 5.414 0 2.983 2.446 5.414 5.448 5.414z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              C Online Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/cpp-progra=
mming/online-compiler/" class=3D"change-lang-row cpp " title=3D"C++ Online =
Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewB=
ox=3D"0 0 24 27" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill=3D"#25265E" fill-opacity=3D".4" d=3D"M23.903 6.639l.067-.043c-=
.134-.233-.334-.445-.534-.551L12.696.148C12.518.042 12.274 0 12.007 0a1.64 =
1.64 0 00-.69.148L.646 6.066C.267 6.278 0 6.808 0 7.21v11.814c0 .233.044.48=
8.2.72l-.044.022c.11.17.266.318.422.403l10.718 5.918c.178.106.422.148.689.1=
48.267 0 .511-.064.69-.148l10.672-5.918c.378-.212.645-.742.645-1.145V7.19c.=
022-.17 0-.36-.089-.551zm-7.893 6.893v-.849h1.111v-1.06h1.112v1.06h1.112v.8=
49h-1.112v1.06h-1.112v-1.06H16.01zm.733-2.97c-.934-1.59-2.712-2.65-4.736-2.=
65-3.002 0-5.448 2.332-5.448 5.195 0 2.864 2.446 5.197 5.448 5.197 2.024 0 =
3.802-1.06 4.736-2.63l2.869 1.612c-1.512 2.502-4.358 4.2-7.605 4.2-4.847 0-=
8.783-3.755-8.783-8.379 0-4.623 3.936-8.377 8.783-8.377 3.269 0 6.115 1.718=
 7.627 4.242l-2.89 1.59zm6.604 2.97h-1.112v1.06h-.889v-1.06h-1.334v-.849h1.=
334v-1.06h.89v1.06h1.111v.849z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              C++ Online Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/csharp-pro=
gramming/online-compiler/" class=3D"change-lang-row csharp " title=3D"C# On=
line Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewB=
ox=3D"0 0 24 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M23.903 6.916l.067-.044c-.134-.243-.334-.4=
64-.534-.574L12.696.155C12.518.045 12.274 0 12.007 0c-.267 0-.511.066-.69.1=
55L.646 6.32C.267 6.54 0 7.093 0 7.513v12.308c0 .243.044.508.2.752l-.044.02=
2c.11.176.266.331.422.42l10.718 6.165c.178.11.422.154.689.154.267 0 .511-.0=
66.69-.154l10.672-6.165c.378-.221.645-.774.645-1.194V7.491c.022-.177 0-.376=
-.089-.575zM12.007 22.384c-4.847 0-8.783-3.91-8.783-8.728 0-4.817 3.936-8.7=
28 8.783-8.728a8.796 8.796 0 017.627 4.42l-2.89 1.656a5.43 5.43 0 00-4.737-=
2.762c-3.002 0-5.448 2.431-5.448 5.414 0 2.983 2.446 5.414 5.448 5.414a5.45=
5 5.455 0 004.736-2.74l2.869 1.68a8.794 8.794 0 01-7.605 4.374zm11.34-9.17h=
-.711l-.2.884h.911v1.105h-1.112l-.266 1.326h-1.09l.267-1.326H20.3l-.267 1.3=
26h-1.067l.267-1.326h-.556v-1.105h.778l.2-.884h-.978V12.11h1.178l.267-1.325=
h1.09l-.267 1.325h.845l.267-1.325h1.067l-.267 1.325h.49v1.105zm-2.824.884h.=
845l.2-.884h-.845l-.2.884z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              C# Online Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/javascript=
/online-compiler/" class=3D"change-lang-row javascript " title=3D"JavaScrip=
t Online Compiler (Editor)">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" viewBox=3D"0 0 630 =
630" class=3D"change-lang-btn-icon svg replaced-svg">
<rect width=3D"630" height=3D"630" fill=3D"#25265E" fill-opacity=3D"0.0"></=
rect>
<path d=3D"m423.2 492.19c12.69 20.72 29.2 35.95 58.4 35.95 24.53 0 40.2-12.=
26 40.2-29.2 0-20.3-16.1-27.49-43.1-39.3l-14.8-6.35c-42.72-18.2-71.1-41-71.=
1-89.2 0-44.4 33.83-78.2 86.7-78.2 37.64 0 64.7 13.1 84.2 47.4l-46.1 29.6c-=
10.15-18.2-21.1-25.37-38.1-25.37-17.34 0-28.33 11-28.33 25.37 0 17.76 11 24=
.95 36.4 35.95l14.8 6.34c50.3 21.57 78.7 43.56 78.7 93 0 53.3-41.87 82.5-98=
.1 82.5-54.98 0-90.5-26.2-107.88-60.54zm-209.13 5.13c9.3 16.5 17.76 30.45 3=
8.1 30.45 19.45 0 31.72-7.61 31.72-37.2v-201.3h59.2v202.1c0 61.3-35.94 89.2=
-88.4 89.2-47.4 0-74.85-24.53-88.81-54.075z"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              JavaScript Online Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/golang/onl=
ine-compiler/" class=3D"change-lang-row golang " title=3D"Online GoLang Com=
piler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=
=3D"40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<g clip-path=3D"url(#clip0_2886_601)">
<path d=3D"M3.00684 16.739C2.9516 16.739 2.89634 16.6837 2.9516 16.6285L3.3=
3841 16.0759C3.39365 16.0206 3.44891 15.9654 3.55944 15.9654H10.522C10.5772=
 15.9654 10.6325 16.0206 10.5772 16.0759L10.2457 16.5731C10.1905 16.6285 10=
.1352 16.6837 10.0247 16.6837L3.00684 16.739ZM0.0781503 18.5072C0.0228897 1=
8.5072 -0.0323709 18.4519 0.0228897 18.3967L0.409701 17.8441C0.464961 17.78=
88 0.520209 17.7336 0.63073 17.7336H9.52736C9.58262 17.7336 9.63788 17.7888=
 9.63788 17.8441L9.47211 18.3967C9.47211 18.4519 9.36159 18.5072 9.30633 18=
.5072H0.0781503ZM4.77513 20.3307C4.71987 20.3307 4.66461 20.2755 4.71987 20=
.2202L4.99616 19.7229C5.05142 19.6676 5.10668 19.6124 5.21719 19.6124H9.085=
3C9.14055 19.6124 9.19581 19.6676 9.19581 19.7229L9.14055 20.165C9.14055 20=
.2202 9.0853 20.2755 9.03004 20.2755L4.77513 20.3307ZM24.9997 16.3521L21.73=
94 17.181C21.4632 17.2362 21.408 17.2916 21.187 16.96C20.9106 16.6285 20.68=
96 16.4074 20.2475 16.2416C19.0318 15.6338 17.8161 15.7995 16.711 16.5179C1=
5.3848 17.3468 14.7217 18.6178 14.7217 20.2202C14.7217 21.7674 15.8268 23.0=
384 17.3741 23.2595C18.7003 23.4252 19.8054 22.9831 20.6896 21.9886C20.8554=
 21.7674 21.0211 21.5464 21.2422 21.2702H17.4846C17.0977 21.2702 16.9872 20=
.9938 17.0977 20.6624C17.3741 20.0545 17.8161 19.0598 18.0925 18.5624C18.14=
77 18.4519 18.3134 18.2309 18.5898 18.2309H25.6628C25.6076 18.7835 25.6076 =
19.2809 25.5523 19.8334C25.3313 21.215 24.834 22.5412 23.9499 23.6462C22.56=
84 25.4698 20.7449 26.6303 18.4239 26.9617C16.4899 27.2381 14.7217 26.8512 =
13.1744 25.6908C11.7377 24.5857 10.9088 23.149 10.6879 21.3807C10.4115 19.2=
809 11.0746 17.3468 12.3455 15.689C13.727 13.8655 15.5505 12.7051 17.8161 1=
2.3183C19.6396 11.9867 21.408 12.2078 22.9552 13.2576C24.0051 13.9207 24.72=
35 14.8602 25.2208 16.0206C25.2761 16.2416 25.2208 16.2969 24.9997 16.3521Z=
" fill=3D"#6D6D93"></path>
<path d=3D"M31.4177 27.1297C29.6494 27.0745 28.0469 26.5771 26.6653 25.4168=
C25.505 24.4221 24.7867 23.1511 24.5655 21.6592C24.2341 19.4489 24.8419 17.=
5148 26.1681 15.8018C27.6048 13.9229 29.3179 12.9836 31.6387 12.5415C33.628=
 12.2099 35.5068 12.3758 37.1646 13.5361C38.7118 14.586 39.6511 16.0227 39.=
9275 17.9015C40.259 20.554 39.4854 22.6537 37.7171 24.4773C36.4461 25.8035 =
34.8437 26.5771 33.0754 26.964C32.4675 27.0745 31.9149 27.0745 31.4177 27.1=
297ZM36.0594 19.283C36.0594 19.0068 36.0594 18.841 36.0041 18.6199C35.6725 =
16.6858 33.9043 15.5808 32.0255 16.0227C30.202 16.4096 29.0415 17.5701 28.5=
994 19.3935C28.2679 20.8856 28.9863 22.4328 30.3677 23.0959C31.4177 23.538 =
32.5228 23.4827 33.5175 22.9854C35.1199 22.2118 35.9489 20.9408 36.0594 19.=
283Z" fill=3D"#6D6D93"></path>
</g>
<defs>
<clipPath id=3D"clip0_2886_601">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online GoLang Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/php/online=
-compiler/" class=3D"change-lang-row php " title=3D"Online PHP Compiler">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=
=3D"40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<path d=3D"M3.83821 13.8008H9.6625C11.372 13.8151 12.6107 14.308 13.3788 15=
.2786C14.1468 16.2492 14.4002 17.5748 14.1394 19.2556C14.0381 20.0236 13.81=
34 20.7769 13.4657 21.5158C13.1323 22.2547 12.669 22.921 12.0748 23.5152C11=
.3503 24.2684 10.5753 24.7465 9.74943 24.9495C8.9236 25.1525 8.06865 25.253=
8 7.185 25.2538H4.57711L3.75128 29.3829H0.730469L3.83821 13.8008ZM6.3809 16=
.2783L5.07696 22.798C5.16389 22.8124 5.25082 22.8197 5.33775 22.8197C5.4390=
3 22.8197 5.54072 22.8197 5.642 22.8197C7.03288 22.8341 8.19208 22.6967 9.1=
1919 22.4068C10.0463 22.1026 10.6696 21.0451 10.9882 19.2339C11.249 17.7126=
 10.9882 16.8359 10.2058 16.6043C9.4378 16.3726 8.4746 16.2639 7.3154 16.27=
83C7.14154 16.2926 6.97506 16.3 6.81555 16.3C6.67081 16.3 6.51868 16.3 6.35=
917 16.3L6.3809 16.2783Z" fill=3D"#25265E" fill-opacity=3D"0.67"></path>
<path d=3D"M17.5748 9.64844H20.5739L19.7263 13.7993H22.4211C23.8989 13.8284=
 24.9999 14.1327 25.7244 14.7121C26.4634 15.2915 26.6807 16.3929 26.3764 18=
.0154L24.9203 25.2523H21.8778L23.2687 18.3414C23.4134 17.6169 23.37 17.1027=
 23.1383 16.7984C22.9066 16.4942 22.4068 16.342 21.6387 16.342L19.2265 16.3=
203L17.4444 25.2523H14.4453L17.5748 9.64844Z" fill=3D"#25265E" fill-opacity=
=3D"0.67"></path>
<path d=3D"M29.5999 13.8008H35.4242C37.1337 13.8151 38.3725 14.308 39.1405 =
15.2786C39.9085 16.2492 40.1619 17.5748 39.9011 19.2556C39.7998 20.0236 39.=
5751 20.7769 39.2274 21.5158C38.894 22.2547 38.4307 22.921 37.8365 23.5152C=
37.112 24.2684 36.337 24.7465 35.5111 24.9495C34.6853 25.1525 33.8304 25.25=
38 32.9467 25.2538H30.3388L29.513 29.3829H26.4922L29.5999 13.8008ZM32.1426 =
16.2783L30.8387 22.798C30.9256 22.8124 31.0125 22.8197 31.0995 22.8197C31.2=
007 22.8197 31.3024 22.8197 31.4037 22.8197C32.7946 22.8341 33.9538 22.6967=
 34.8809 22.4068C35.808 22.1026 36.4313 21.0451 36.7499 19.2339C37.0107 17.=
7126 36.7499 16.8359 35.9675 16.6043C35.1995 16.3726 34.2363 16.2639 33.077=
1 16.2783C32.9033 16.2926 32.7368 16.3 32.5773 16.3C32.4325 16.3 32.2804 16=
.3 32.1209 16.3L32.1426 16.2783Z" fill=3D"#25265E" fill-opacity=3D"0.67"></=
path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online PHP Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/swift/onli=
ne-compiler/" class=3D"change-lang-row swift " title=3D"Online Swift Compil=
er">
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=
=3D"40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M29.9196 33.8549C32.=
0265 33.0205 36.1973 31.7405 38.4533 35.8806C38.9712 36.8532 40.1207 31.705=
9 35.9618 26.8506L35.8873 26.7661C35.9081 26.6956 35.9286 26.6286 35.9487 2=
6.5631C35.9889 26.4317 36.0272 26.3061 36.0638 26.1702C38.159 18.6894 33.15=
65 9.75527 24.7445 5C28.3777 9.66308 30.0412 15.2949 28.5857 20.25C28.4536 =
20.7083 28.2951 21.1588 28.1109 21.5995C27.9383 21.4841 27.7225 21.361 27.4=
439 21.2149C21.1601 17.3644 15.3113 12.871 9.99608 7.81009C13.1936 12.2165 =
16.7354 16.3731 20.5896 20.2423C17.8902 18.7855 10.3022 13.638 5.53115 9.55=
93C6.1325 10.4985 6.82774 11.3767 7.60662 12.181C11.5537 16.9401 16.8504 22=
.768 23.0888 27.2504C18.7062 29.7914 12.4836 29.9798 6.257 27.2504C4.73944 =
26.619 3.30917 25.8028 2 24.8209C4.81703 28.9559 8.83711 32.1663 13.539 34.=
0355C19.5694 36.4535 25.5607 36.2113 29.9196 33.8549Z" fill=3D"#25265E" fil=
l-opacity=3D"0.67"></path>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online Swift Compiler
            </span>
          </a>
          <a target=3D"_blank" href=3D"https://www.programiz.com/rust/onlin=
e-compiler/" class=3D"change-lang-row rust " title=3D"Online Rust Compiler"=
>
            <span class=3D"change-lang-btn">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=
=3D"40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon s=
vg replaced-svg">
<g clip-path=3D"url(#clip0_2886_605)">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.8839 2.84442L14.=
4084 2.68631L15.1505 0.663847C15.2559 0.46731 15.603 0.273265 15.9643 0.487=
312C16.1369 0.589616 16.7641 1.30652 17.1641 1.76388C17.2685 1.88336 17.357=
7 1.98513 17.419 2.05361H18.0516L19.129 0.167618C19.2712 -0.0427356 19.6845=
 -0.0686346 19.924 0.167618C20.0716 0.313238 20.3929 0.883897 20.6664 1.369=
34C20.8365 1.6714 20.9878 1.94045 21.0674 2.05361H21.7002L23.0602 0.523151C=
23.2474 0.335748 23.7311 0.346159 23.9339 0.741787C24.0241 0.917836 24.1409=
 1.26358 24.261 1.61915C24.4107 2.06265 24.5658 2.52141 24.6807 2.68514C24.=
8677 2.79683 25.0045 2.83134 25.2354 2.82004L26.8525 1.60471C27.0398 1.4173=
 27.596 1.5539 27.7135 1.90697C27.7613 2.05037 27.7923 2.37341 27.826 2.726=
28C27.8754 3.24222 27.931 3.82191 28.0541 3.99709C28.1741 4.11715 28.4858 4=
.32123 28.7737 4.17717C29.0617 4.03311 29.9347 3.61122 30.3351 3.41829C30.5=
515 3.36255 30.9609 3.33726 31.0997 3.70769V6.0165L31.4596 6.33811L33.3422 =
5.88792C33.4493 5.86421 33.6878 5.83122 33.7855 5.88792C33.8831 5.94446 34.=
079 6.15146 34.1646 6.24798C34.1882 6.28658 34.2134 6.46532 34.1261 6.87189=
C34.0386 7.27831 33.7984 8.13447 33.6892 8.51171L34.0233 8.9619L36.2913 8.8=
8484C36.452 8.95764 36.6884 9.30023 36.6319 9.54721C36.5883 9.7375 36.2534 =
10.4298 35.9726 11.0103C35.8889 11.1831 35.8101 11.3462 35.7453 11.4829L35.=
9958 12.036L38.0905 12.3383C38.249 12.4048 38.5492 12.6355 38.4824 13.0264L=
37.2295 14.7949C37.2038 14.9386 37.1935 15.2555 37.3579 15.3739C37.5225 15.=
4921 38.7073 15.899 39.2792 16.0876C39.4055 16.1627 39.6506 16.3732 39.6198=
 16.615C39.5888 16.8568 39.5469 16.9473 39.5297 16.9623L37.9813 18.3772V18.=
9046C38.6516 19.3032 39.9924 20.1328 39.9924 20.2615C39.9924 20.291 39.9939=
 20.3274 39.9956 20.3675C40.003 20.5459 40.0137 20.8013 39.9089 20.8853C39.=
8061 20.9677 38.581 21.687 37.9813 22.0365V22.6282C38.5252 23.1083 39.612 2=
4.0892 39.6069 24.1716C39.6053 24.1959 39.606 24.2307 39.6067 24.2719C39.60=
91 24.4049 39.6128 24.6049 39.549 24.7376C39.4822 24.8765 38.0561 25.3871 3=
7.3516 25.6251L37.2231 26.1975C37.6301 26.7419 38.4478 27.8425 38.4631 27.8=
888C38.4824 27.9467 38.5081 28.4548 38.174 28.6863L36.0537 28.9821L35.7838 =
29.4645L36.6641 31.4324C36.6983 31.5782 36.6757 31.9211 36.3106 32.1269L34.=
0167 32.0755L33.7149 32.4356L34.2032 34.6545C34.2009 34.7894 34.0656 35.082=
8 33.5413 35.1753L31.5174 34.6995L31.1126 34.9952L31.1768 37.2655C31.1211 3=
7.424 30.8915 37.7195 30.4186 37.6321L28.5232 36.7381L28.0348 36.9954L27.67=
49 39.2076C27.5893 39.3319 27.3178 39.5497 26.9167 39.4263L25.1756 38.1786C=
25.0406 38.1916 24.7567 38.2327 24.7 38.2945C24.6435 38.3562 24.094 39.7864=
 23.8263 40.4939C23.6999 40.5817 23.3816 40.7138 23.1194 40.5389L21.6223 38=
.9568H21.1148L19.8619 40.9119C19.7612 40.9784 19.4982 41.0715 19.2514 40.91=
19L17.9663 38.9568H17.433L15.8587 40.6032C15.7367 40.646 15.4475 40.6856 15=
.2677 40.5003L14.3938 38.3651C14.3402 38.2966 14.1626 38.1659 13.8798 38.19=
16L12.0614 39.4906C11.8793 39.4991 11.4909 39.4468 11.3932 39.169C11.2956 3=
8.8912 11.1427 37.6385 11.0784 37.0468L10.5515 36.7317L8.66886 37.6192C8.50=
183 37.6813 8.12144 37.7028 7.93648 37.2912V34.9888C7.92145 34.9373 7.82077=
 34.8075 7.53802 34.6995L5.48195 35.1817C5.30641 35.1883 4.94094 35.1007 4.=
8844 34.6995C4.82785 34.2981 5.17779 33.1217 5.35986 32.5836L5.07076 32.094=
8L2.7769 32.1527C2.62698 32.0605 2.33741 31.8041 2.37854 31.516C2.41966 31.=
2279 3.02536 30.0755 3.32307 29.5352L3.02108 29.0079L0.842888 28.6992C0.716=
532 28.6456 0.481784 28.4278 0.553747 27.9853L1.84522 26.1975C1.83237 26.04=
31 1.77584 25.7087 1.65246 25.6058L-0.300845 24.9434C-0.412213 24.8533 -0.6=
23394 24.5948 -0.577139 24.2809C-0.53087 23.967 0.547293 23.0612 1.08058 22=
.6475V22.0365C0.476606 21.7278 -0.768624 21.0409 -0.917697 20.7631C-1.06676=
 20.4853 -0.979805 20.2743 -0.917697 20.2036L1.11917 18.943V18.3965C0.65226=
8 18.0127 -0.335528 17.1526 -0.551416 16.7822V16.3513C-0.544992 16.3021 -0.=
460183 16.1712 -0.172317 16.0426C0.115533 15.914 1.23269 15.5517 1.75527 15=
.3866L1.87094 14.8272L0.579441 13.0457V12.602C0.624419 12.4969 0.818471 12.=
2816 1.23483 12.2611C1.6512 12.2406 2.62056 12.1067 3.0532 12.0424L3.31021 =
11.5086L2.38496 9.57289C2.34212 9.36072 2.36183 8.92466 2.78333 8.8783C3.20=
484 8.8321 4.44964 8.859 5.01935 8.8783L5.38552 8.53754L4.85229 6.36379C4.8=
4801 6.1773 4.97437 5.80812 5.51414 5.82347L7.57021 6.31881L7.97505 5.9972L=
7.87863 3.72056C7.92357 3.56192 8.12918 3.25751 8.59187 3.30896L10.5002 4.2=
4791L11.0721 3.96495L11.374 1.89411C11.4553 1.70332 11.7184 1.36547 12.1194=
 1.5404C12.5203 1.71532 13.4628 2.48263 13.8839 2.84442ZM20.7002 4.89056C20=
.7002 5.53728 20.1767 6.06134 19.5305 6.06134C18.8845 6.06134 18.3608 5.537=
28 18.3608 4.89056C18.3608 4.244 18.8845 3.71982 19.5305 3.71982C20.1767 3.=
71982 20.7002 4.244 20.7002 4.89056ZM24.5236 10.4094H8.48148C11.3531 7.2965=
5 13.1362 6.23065 16.6696 5.7262C16.6696 5.7262 18.6748 7.73337 19.0091 7.9=
0056C19.3433 8.0679 19.7703 8.10498 20.1788 7.90056C20.513 7.73337 22.3512 =
5.7262 22.3512 5.7262C27.0871 6.75866 29.3134 8.52402 32.7117 13.2527C32.37=
75 13.7546 31.6422 14.9588 31.3748 15.7616C31.1076 16.5644 31.4863 17.0997 =
31.709 17.2669L34.3827 18.605L34.5499 21.6156H32.5447C33.3802 25.2953 29.70=
38 25.4625 29.2026 22.9536C28.8835 21.3574 28.0884 20.5562 27.1972 19.7758C=
31.8762 17.2669 30.3723 11.2457 24.5236 10.4094ZM7.14457 17.2669C7.81303 16=
.8655 7.7573 16.3191 7.64599 16.0961L7.27076 15.1849C7.25269 15.1409 7.2850=
4 15.0925 7.33257 15.0925H9.81838V24.7934H5.12585C4.3237 22.6525 4.45268 19=
.7955 4.61979 18.6246C5.17688 18.3459 6.47627 17.6683 7.14457 17.2669ZM16.3=
354 15.0925V17.7686H21.6827C23.6881 17.7686 24.0223 15.2599 21.6827 15.0925=
H16.3354ZM16.3354 24.7934V22.1173H20.513C21.5157 22.1173 22.6854 23.2881 23=
.0196 26.2987C23.287 28.7073 24.5793 29.4209 25.192 29.4766H31.709L30.3723 =
30.8146C30.0938 30.7588 29.236 30.614 28.0327 30.4801C26.8296 30.3463 26.41=
75 30.982 26.3617 31.3165L26.0275 34.1597C20.6881 35.8537 17.848 35.8704 12=
.9933 33.9926C12.9376 33.4351 12.7929 32.1193 12.6591 31.3165C12.5254 30.51=
35 11.935 30.3129 11.6565 30.3129L8.64867 30.8146L7.57583 29.5876C7.53802 2=
9.5443 7.5687 29.4766 7.62625 29.4766H19.6775C19.7698 29.4766 19.8447 29.40=
17 19.8447 29.3093V24.9607C19.8447 24.8683 19.7698 24.7934 19.6775 24.7934H=
16.3354ZM34.3827 16.9324C35.0288 16.9324 35.5524 16.4082 35.5524 15.7616C35=
.5524 15.115 35.0288 14.5908 34.3827 14.5908C33.7367 14.5908 33.213 15.115 =
33.213 15.7616C33.213 16.4082 33.7367 16.9324 34.3827 16.9324ZM4.68672 16.8=
641C5.33268 16.8641 5.85641 16.3399 5.85641 15.6934C5.85641 15.0468 5.33268=
 14.5226 4.68672 14.5226C4.04068 14.5226 3.51697 15.0468 3.51697 15.6934C3.=
51697 16.3399 4.04068 16.8641 4.68672 16.8641ZM11.5203 33.1356C11.5203 33.7=
822 10.9966 34.3064 10.3506 34.3064C9.70449 34.3064 9.18091 33.7822 9.18091=
 33.1356C9.18091 32.4891 9.70449 31.9649 10.3506 31.9649C10.9966 31.9649 11=
.5203 32.4891 11.5203 33.1356ZM28.7012 34.3271C29.3471 34.3271 29.8709 33.8=
029 29.8709 33.1563C29.8709 32.5096 29.3471 31.9854 28.7012 31.9854C28.0552=
 31.9854 27.5314 32.5096 27.5314 33.1563C27.5314 33.8029 28.0552 34.3271 28=
.7012 34.3271Z" fill=3D"#25265E" fill-opacity=3D"0.67"></path>
</g>
<defs>
<clipPath id=3D"clip0_2886_605">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
            </span>
            <span class=3D"nav-menu-text">
              Online Rust Compiler
            </span>
          </a>
        </div>
      </div>
    </div>

    <!-- Share code -->

    <!-- Progress bar: share link generating modal -->
    <div class=3D"share-link-generating-modal" style=3D"display: none;">
      <div class=3D"modal-backdrop-share">
      </div>

      <div class=3D"modal-content">
        <div class=3D"modal-header">
          <h2 class=3D"modal-title">Generating Link</h2>
          <h2 class=3D"modal-title modal-title-mob">Generating Link</h2>
        </div>
        <div class=3D"modal-body">
          <div class=3D"progress-bar">
            <div class=3D"progress"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Notification -->
    <div class=3D"notification " id=3D"notification" style=3D"display:none;=
">
      <div class=3D"check-icon-wrapper">
        <img src=3D"https://www.programiz.com/c-programming/online-compiler=
/assets/icons/check.svg" alt=3D"check">
      </div>

      <div class=3D"notification-message-wrapper">
        <p class=3D"notification-message"></p>
        <button type=3D"button" class=3D"close-modal-notification" title=3D=
"Close">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"20" height=3D"=
20" viewBox=3D"0 0 32 32" fill=3D"none" class=3D"svg replaced-svg">
<path d=3D"M25.333 6.4707L6.66643 25.1373" stroke=3D"#25265E" stroke-opacit=
y=3D"0.67" stroke-width=3D"2.66667" stroke-linecap=3D"round" stroke-linejoi=
n=3D"round"></path>
<path d=3D"M6.66699 6.4707L25.3336 25.1373" stroke=3D"#25265E" stroke-opaci=
ty=3D"0.67" stroke-width=3D"2.66667" stroke-linecap=3D"round" stroke-linejo=
in=3D"round"></path>
</svg>
        </button>
      </div>
    </div>

    <!-- Share link modal -->
    <div class=3D" share-link-modal" style=3D"display: none;">
      <div class=3D"modal-backdrop-share">
      </div>

      <div class=3D"modal-content">
        <div class=3D"modal-header">
          <h2 class=3D"modal-title">Share your code</h2>
          <h2 class=3D"modal-title modal-title-mob">Share code</h2>
          <button type=3D"button" class=3D"close-modal" title=3D"Close">
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"24" height=
=3D"24" viewBox=3D"0 0 24 24" fill=3D"none" class=3D"svg replaced-svg">
<path d=3D"M19 4.85352L5.00006 18.8535" stroke=3D"#25265E" stroke-opacity=
=3D"0.7" stroke-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"rou=
nd"></path>
<path d=3D"M5 4.85352L18.9999 18.8535" stroke=3D"#25265E" stroke-opacity=3D=
"0.7" stroke-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"=
></path>
</svg>
          </button>
        </div>

        <div class=3D"modal-body">
          <div class=3D"share-code-container">
            <input type=3D"text" class=3D"share-code-value js-bound" value=
=3D"https://www.programiz.com/online-compiler/XXXXXXXXX" readonly=3D"">
          </div>
          <button class=3D"share-code-copy-btn" title=3D"Copy Link">Copy Li=
nk</button>
          <button class=3D"share-code-copy-btn code-copied-success" title=
=3D"Copied to clipboard">
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"20" height=
=3D"20" viewBox=3D"0 0 20 20" fill=3D"none" class=3D"svg replaced-svg">
<g clip-path=3D"url(#clip0_13050_2098)">
<path d=3D"M18.3334 9.2333V9.99997C18.3323 11.797 17.7504 13.5455 16.6745 1=
4.9848C15.5985 16.4241 14.0861 17.477 12.3628 17.9866C10.6395 18.4961 8.797=
74 18.4349 7.11208 17.8121C5.42642 17.1894 3.98723 16.0384 3.00915 14.5309C=
2.03108 13.0233 1.56651 11.24 1.68475 9.4469C1.80299 7.65377 2.49769 5.9469=
1 3.66525 4.58086C4.83281 3.21482 6.41068 2.26279 8.16351 1.86676C9.91635 1=
.47073 11.7502 1.65192 13.3917 2.3833" stroke=3D"#56BD5B" stroke-width=3D"2=
" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M18.3333 3.33337L10 11.675L7.5 9.17504" stroke=3D"#56BD5B" strok=
e-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
</g>
<defs>
<clipPath id=3D"clip0_13050_2098">
<rect width=3D"20" height=3D"20" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
            Copied to clipboard
          </button>

          <!-- Social media share -->
          <div class=3D"social-wrapper">
            <span>or share using</span>
            <div id=3D"social-icons">
            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Share code end -->

    <div class=3D"wrapper" style=3D"display: block;">
      <div class=3D"header">
        <div class=3D"header-wrapper">
          <div class=3D"burger-menu">
            <button type=3D"button" class=3D"burger-menu-btn" title=3D"Open=
 navigation">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"24" height=
=3D"24" viewBox=3D"0 0 24 24" fill=3D"none" class=3D"svg burger-menu-btn-ic=
on replaced-svg">
  <path d=3D"M3 12H21" stroke=3D"#25265E" stroke-opacity=3D"0.7" stroke-wid=
th=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
  <path d=3D"M3 6H21" stroke=3D"#25265E" stroke-opacity=3D"0.7" stroke-widt=
h=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
  <path d=3D"M3 18H21" stroke=3D"#25265E" stroke-opacity=3D"0.7" stroke-wid=
th=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
</svg>
            </button>
          </div>
          <div class=3D"logo-wrapper">
            <h1 class=3D"logo-title-wrapper">
              <a href=3D"https://www.programiz.com/" target=3D"_blank" clas=
s=3D"logo-link">
                <img id=3D"logo" src=3D"https://www.programiz.com/c-program=
ming/online-compiler/assets/logos/logo.svg">
                <span class=3D"logo-sub-title-wrapper">
                  <span class=3D"logo-sub-title">
                    C Online                    Compiler                  <=
/span>
                </span>
              </a>
            </h1>
          </div>
        </div>
        <div class=3D"compiler-header-ad">
          <div class=3D"pgAdWrapper" style=3D"display: flex; justify-conten=
t: center; align-items: center; min-width: 728px; min-height: 90px;"><div i=
d=3D"div-gpt-ad-Programizcom36786" class=3D"content-top-ad" style=3D"min-he=
ight: 1px;" data-google-query-id=3D"CJLIvKOv94cDFbdynQkdBiI9pQ">
          <div id=3D"google_ads_iframe_/8095840,68410703/.2_A.36786.3_Progr=
amiz.com_tier1_0__container__" style=3D"border: 0pt none;"><iframe id=3D"go=
ogle_ads_iframe_/8095840,68410703/.2_A.36786.3_Programiz.com_tier1_0" name=
=3D"google_ads_iframe_/8095840,68410703/.2_A.36786.3_Programiz.com_tier1_0"=
 title=3D"3rd party ad content" width=3D"728" height=3D"90" scrolling=3D"no=
" marginwidth=3D"0" marginheight=3D"0" frameborder=3D"0" aria-label=3D"Adve=
rtisement" tabindex=3D"0" allow=3D"attribution-reporting" data-load-complet=
e=3D"true" style=3D"border: 0px; vertical-align: bottom;" data-google-conta=
iner-id=3D"1"></iframe></div></div><div class=3D"adSpinner ad-slot__label" =
style=3D"display: none;"><svg xmlns=3D"http://www.w3.org/2000/svg" x=3D"0px=
" y=3D"0px" viewBox=3D"0 0 1000 1000" xml:space=3D"preserve"><g class=3D"az=
_logo_group"><g><g><g><g><g class=3D"letter letter__1"><path fill=3D"#97979=
7" d=3D"M136.3,652.2v53.5c0,7.9-5.7,13.7-13.7,13.7c-5.5,0-13.1-5.7-13.1-13.=
7c-11.7,9.8-24.8,13.7-40.4,13.7C30.6,719.3,0,690.7,0,652.2s30.6-69.1,69.1-6=
9.1S136.3,613.7,136.3,652.2z M109.5,652.2c0-22.9-17.5-42.3-40.4-42.3s-42.3,=
19.4-42.3,42.3s19.4,40.4,42.3,40.4C92,692.5,109.5,675,109.5,652.2z"></path>=
</g><g class=3D"letter letter__2"><path fill=3D"#979797" d=3D"M264.6,705.9c=
0,7.4-6,13.7-13.4,13.7h-84.9c-5.2,0-10.1-3-12.3-7.6c-2.5-4.9-1.9-10.4,1.4-1=
4.5l68.3-87.9h-57.9c-7.4,0-13.4-6.3-13.4-13.7s6-13.4,13.4-13.4h84.9c5.2,0,1=
0.1,2.7,12.3,7.6c2.5,4.6,1.9,10.1-1.4,14.2l-68.3,88.2h57.9C258.6,692.5,264.=
6,698.5,264.6,705.9z"></path></g><g class=3D"letter letter__3"><path fill=
=3D"#979797" d=3D"M408.2,651c0,7.4-6,13.4-13.7,13.4h-94.2c5.7,16.4,21,28.1,=
39.3,28.1c6.3,0,17.5-0.5,30.6-9c6.3-4.1,14.7-0.3,18,6.3c3.3,6.8-0.3,13.9-6.=
6,18c-18,12-31.9,11.7-42.1,11.7c-38,0-68.5-30.9-68.5-68.5c0-38,30.6-68.5,68=
.5-68.5C372.7,582.5,408.2,606.5,408.2,651z M300.4,637.3h78.9c-5.7-19.1-23.2=
-27.9-39.6-27.9C321.4,609.5,306.1,621.2,300.4,637.3z"></path></g><g class=
=3D"letter letter__4"><path fill=3D"#979797" d=3D"M506.5,596.2c0,7.4-6,13.7=
-13.7,13.7c-22.9,0-41.5,18.6-41.5,41.5v54.9c0,7.4-6,13.7-13.4,13.7c-7.6,0-1=
3.7-6.3-13.7-13.7v-54.9c0-38,30.9-68.5,68.5-68.5C500.5,582.8,506.5,588.8,50=
6.5,596.2z"></path></g><g class=3D"letter letter__5"><path fill=3D"#979797"=
 d=3D"M522.6,706.2v-110c0-7.4,6-13.4,13.7-13.4c7.4,0,13.4,6,13.4,13.4v110c0=
,7.6-6,13.7-13.4,13.7C528.6,719.8,522.6,713.8,522.6,706.2z"></path><path fi=
ll=3D"#979797" d=3D"M526.7,563.3c-2.5-2.5-4.1-6-4.1-9.6c0-3.5,1.6-7.1,4.1-9=
.6s6-4.1,9.6-4.1s7.1,1.6,9.6,4.1s3.8,6,3.8,9.6  c0,3.5-1.4,7.1-3.8,9.6c-2.5=
,2.5-6,3.8-9.6,3.8S529.2,565.8,526.7,563.3z"></path></g><g class=3D"letter =
letter__6"><path fill=3D"#979797" d=3D"M565.8,651c0-38,30.9-68.5,68.5-68.5c=
38,0,68.5,30.6,68.5,68.5c0,37.7-30.6,68.5-68.5,68.5C596.6,719.5,565.8,688.8=
,565.8,651z M592.8,651c0,22.7,18.6,41.5,41.5,41.5s41.5-18.8,41.5-41.5c0-22.=
9-18.6-41.5-41.5-41.5C611.4,609.5,592.8,628.2,592.8,651z"></path></g><g cla=
ss=3D"letter letter__7"><path fill=3D"#979797" d=3D"M856,651v54.9c0,7.6-6,1=
3.7-13.7,13.7c-7.4,0-13.4-6-13.4-13.7V651c0-22.9-18.6-41.5-41.5-41.5s-41.5,=
18.6-41.5,41.5v54.9c0,7.6-6,13.7-13.7,13.7c-7.4,0-13.4-6-13.4-13.7V651c0-38=
,30.9-68.5,68.5-68.5C825.2,582.5,856,613,856,651z"></path></g></g></g></g><=
/g><g class=3D"az__logo"><path fill=3D"#979797" d=3D"M607.4,302c0.7,0.9,1.2=
,1.5,1.6,2.1c8.1,12.3,13.2,25.8,14.5,40.5c1.1,12.7-0.8,25.1-5.7,36.9c-9.3,2=
2.6-25.2,39.3-46.8,50.5c-16.7,8.7-34.5,12.3-53.2,11.1c-21.8-1.3-41.2-8.8-58=
.1-22.8c-1.5-1.2-2.9-2.5-4.3-3.9c-25.1-25.8-41.5-56.4-48.7-91.7c-2.5-12.3-3=
.6-24.6-3.6-37.1c0-17.1,0-34.2,0-51.3c0-10.5-1.8-20.7-5.8-30.5c-10.2-25.3-3=
3-43.7-59.8-48.1c-43.8-7.2-81.7,21.4-90.4,60.9c-1.5,6.8-2,13.7-1.6,20.6c0.1=
,1.8,0.2,3.6,0.2,5.4c-0.9,0.4-1.1-0.2-1.4-0.6c-3.8-5.5-7.2-11.2-10.3-17.2c-=
7.7-15-12.7-30.9-15.1-47.7c-4.2-30.7,1.3-59.6,16.8-86.4c19.2-33.4,47.5-56,8=
3.6-69c11.1-4,22.6-6.7,34.3-8c12.9-1.5,25.8-1.4,38.6,0.3c15.6,2.1,30.6,6.3,=
44.8,13.1c3.1,1.5,6.1,3.1,9,4.8c54.5,32.9,93.7,87.4,107.7,149.5c3,13.4,4.9,=
27,5.5,40.7c0.2,5.1,0.4,10.2,0.4,15.3c0.1,15.9,0.2,31.7,0.3,47.6c0,2.6,0.2,=
5.3,0.8,7.7c2.7,10.1,9.2,16.6,19.4,18.8c10.1,2.1,18.5-1.1,25.2-8.9c0.3-0.3,=
0.5-0.7,0.8-1.1C606.5,303.1,606.8,302.8,607.4,302z"></path><path fill=3D"#9=
79797" d=3D"M365.6,4.1c-1,0.1-2,0.2-3,0.2c-8.3,0.2-16.5,0.9-24.7,2.2c-23,3.=
8-44.3,12-63.8,24.8c-22.5,14.7-40.7,33.5-53.9,56.9c-9,15.9-14.8,33-17.5,51.=
1c-2,13.2-2.3,26.4-0.7,39.6c4.6,37.7,20.6,69.8,46.9,97c10.2,10.5,21.6,19.3,=
34.1,26.9c10.7,6.5,22.3,10.4,34.9,11.3c20.9,1.5,39.6-4.3,56-17.4c3.4-2.7,6.=
6-5.5,9.9-8.3c0.6-0.5,1.2-0.9,1.8-1.3c0.8,0.5,0.6,1.1,0.6,1.6c0,3.7,0.1,7.5=
,0,11.2c-0.1,6.6,0.7,13.1,1.7,19.6c3.1,19.9,9.1,39,18,57.1c9.7,19.8,22.4,37=
.5,38,53.1c1.7,1.8,3.5,3.5,5.2,5.3c-8.2,7.3-40.8,22-61.5,27.7c-34.6,9.6-69.=
6,11.3-105,5.1c-36.7-6.5-70-20.9-99.7-43.3C90.9,355.7,63.6,234,111,134.6C13=
5.2,84,173,46.7,223.5,22.4C271.8-0.8,324.4-4.2,365.6,4.1z"></path><path fil=
l=3D"#979797" d=3D"M505.4,452c2.7,0.5,5.3,1,7.8,1.4c18.7,3.1,37.1,1.5,54.9-=
4.9c28.3-10.2,49.6-28.7,63.4-55.5c6.9-13.3,10.2-27.6,10.3-42.5c0.1-15-3.3-2=
9.2-9.6-42.7c-6.4-13.5-15.3-25.1-26.2-35.2c-11.9-10.9-19.6-24.2-23.2-39.9c-=
9.6-41.7,15.3-82.2,55.4-93.4c27.6-7.7,56.9,0.2,76.8,20.3c25.8,26.1,42.4,57,=
49.7,93c2.3,11.4,3.6,22.8,3.4,34.4c-0.1,6.3,0,12.7-0.6,19c-1.5,15.2-4.7,30-=
9.9,44.3c-21,57.7-69.3,101.2-128.7,115.7c-18.1,4.4-36.4,6-55,4.8c-23-1.4-44=
.9-7.1-65.7-16.9C507.2,453.5,506,453.3,505.4,452z"></path></g></g></svg></d=
iv></div>

          <!-- buysell ads -->
          <div class=3D"compiler-header-ad" id=3D"carbon-block"></div>

        </div>
        <div id=3D"add-replacement"></div>
        <div id=3D"feedback-desktop">
          <a id=3D"ad-link" href=3D"https://programiz.pro/?utm_source=3Dcom=
piler-nav&amp;utm_campaign=3Dprogramiz&amp;utm_medium=3Dreferral" target=3D=
"_blank">Programiz PRO =E2=9D=AF</a>
        </div>
        <div id=3D"feedback-mobile">
          <a id=3D"mobile-ad-link" href=3D"https://programiz.pro/?utm_sourc=
e=3Dcompiler-nav&amp;utm_campaign=3Dprogramiz&amp;utm_medium=3Dreferral" ta=
rget=3D"_blank">Programiz PRO</a>
        </div>
      </div>
      <div class=3D"mobile-top-bar clearfix">
        <div class=3D"pills-wrapper">
          <div class=3D"pills clearfix">
            <button class=3D"pill active compiler-pill">
              main.c            </button>
            <button class=3D"pill shell-pill">
              Output            </button>
          </div>
        </div>

        <!-- Change the position of option wrapper which contain dark mode =
toggle and share in mob view -->
        <div class=3D"options-wrapper">
          <!-- <div id=3D"back-button" class=3D"options-item-wrapper clearf=
ix">
              <img class=3D"svg options-item" src=3D"./assets/icons/back-ar=
row.svg" />
            </div> -->
          <div id=3D"toggle-dark-mode-mobile" class=3D"options-item-wrapper=
 clearfix">
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 24 24" fill=3D"none" stroke=3D"currentColor" stroke-=
width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round" class=3D"tog=
gle-dark-mode-mobile-icon moon svg options-item replaced-svg">
  <path d=3D"M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
</svg>
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 24 24" fill=3D"none" stroke=3D"#ffffff" stroke-width=
=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round" class=3D"toggle-d=
ark-mode-mobile-icon sun svg options-item replaced-svg">
  <circle cx=3D"12" cy=3D"12" r=3D"5"></circle>
  <line x1=3D"12" y1=3D"1" x2=3D"12" y2=3D"3"></line>
  <line x1=3D"12" y1=3D"21" x2=3D"12" y2=3D"23"></line>
  <line x1=3D"4.22" y1=3D"4.22" x2=3D"5.64" y2=3D"5.64"></line>
  <line x1=3D"18.36" y1=3D"18.36" x2=3D"19.78" y2=3D"19.78"></line>
  <line x1=3D"1" y1=3D"12" x2=3D"3" y2=3D"12"></line>
  <line x1=3D"21" y1=3D"12" x2=3D"23" y2=3D"12"></line>
  <line x1=3D"4.22" y1=3D"19.78" x2=3D"5.64" y2=3D"18.36"></line>
  <line x1=3D"18.36" y1=3D"5.64" x2=3D"19.78" y2=3D"4.22"></line>
</svg>
          </div>
          <button class=3D"share-button-mob" title=3D"Share code">
            <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 18 18" fill=3D"none" class=3D"svg share-icon replace=
d-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 6C14.7426 6 15=
.75 4.99264 15.75 3.75C15.75 2.50736 14.7426 1.5 13.5 1.5C12.2574 1.5 11.25=
 2.50736 11.25 3.75C11.25 4.99264 12.2574 6 13.5 6Z" stroke=3D"white" strok=
e-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></pa=
th>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M4.5 11.25C5.74264 1=
1.25 6.75 10.2426 6.75 9C6.75 7.75736 5.74264 6.75 4.5 6.75C3.25736 6.75 2.=
25 7.75736 2.25 9C2.25 10.2426 3.25736 11.25 4.5 11.25Z" stroke=3D"white" s=
troke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round">=
</path>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 16.5C14.7426 1=
6.5 15.75 15.4926 15.75 14.25C15.75 13.0074 14.7426 12 13.5 12C12.2574 12 1=
1.25 13.0074 11.25 14.25C11.25 15.4926 12.2574 16.5 13.5 16.5Z" stroke=3D"w=
hite" stroke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"=
round"></path>
<path d=3D"M6.44336 10.1328L11.5659 13.1178" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M11.5584 4.88281L6.44336 7.86781" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
</svg>
          </button>
        </div>
        <div class=3D"other-options-wrapper">
          <!-- <div id=3D"feedback-mobile" class=3D"options-item-wrapper">
              <a href=3D"https://programiz.com/contact" class=3D"options-it=
em">
                <img class=3D"svg" src=3D"./assets/icons/message-square.svg=
" />
              </a>
            </div> -->
          <div class=3D"mobile-top-bar-run-button run"><img src=3D"https://=
www.programiz.com/c-programming/online-compiler/assets/icons/play.svg" alt=
=3D"run-icon"></div>
        </div>
      </div>
      <div class=3D"sidebar-wrapper">
        <a target=3D"_blank" href=3D"https://www.programiz.com/python-progr=
amming/online-compiler/" class=3D"change-lang-btn python " title=3D"Online =
Python Compiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewBox=
=3D"0 0 24 25" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M9.091 11.663h5.782c1.61 0 2.877-1.353 2.8=
77-2.96V3.225c0-1.559-1.315-2.73-2.886-2.99A18.088 18.088 0 0011.853 0a16.2=
5 16.25 0 00-2.738.235c-2.45.43-2.866 1.33-2.866 2.99v2.132H12v.788H4.025C2=
.342 6.145.868 7.152.408 9.064c-.532 2.191-.556 3.531 0 5.82.411 1.702 1.39=
4 2.888 3.076 2.888h1.972V15.2c0-1.9 1.672-3.538 3.635-3.538zm-.364-7.707c-=
.6 0-1.087-.489-1.087-1.093 0-.606.486-1.1 1.087-1.1.597 0 1.086.494 1.086 =
1.1a1.09 1.09 0 01-1.086 1.093zm14.83 5.108c-.416-1.665-1.21-2.919-2.895-2.=
919h-2.118v2.558c0 1.98-1.744 3.551-3.671 3.551H9.091c-1.584 0-2.842 1.444-=
2.842 3.02v5.479c0 1.558 1.338 2.475 2.868 2.923 1.833.535 3.568.632 5.76 0=
 1.458-.42 2.873-1.264 2.873-2.923V18.56H12v-.788h8.662c1.682 0 2.31-1.138 =
2.895-2.89.604-1.801.578-3.506 0-5.818zm-8.32 10.958c.6 0 1.087.488 1.087 1=
.093 0 .606-.486 1.1-1.087 1.1a1.095 1.095 0 01-1.086-1.1 1.09 1.09 0 011.0=
86-1.093z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/r/online-com=
piler/" class=3D"change-lang-btn r " title=3D"Online R Compiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=3D"=
40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<g clip-path=3D"url(#clip0_2886_601)">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M20.4449 31.25C31.18=
85 31.25 38.7187 25.3737 38.7187 18.125C38.7187 10.8763 32.1297 5 19.2656 5=
C8.52191 5 -0.1875 10.8763 -0.1875 18.125C-0.1875 25.3737 9.70118 31.25 20.=
4449 31.25ZM23.1934 27.9688C31.2187 27.9688 36.8437 23.9813 36.8437 19.0625=
C36.8437 14.1437 31.9219 10.1562 22.3125 10.1562C14.2871 10.1562 7.78131 14=
.1437 7.78131 19.0625C7.78131 23.9813 15.168 27.9688 23.1934 27.9688Z" fill=
=3D"#6D6D93"></path>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M16.2188 35H22.7814V=
26.3281H24.2416C24.9302 26.3281 25.5635 26.7057 25.891 27.3116L30.047 35H37=
.547L32.9028 26.9784C32.572 26.4069 32.0506 25.9702 31.43 25.7445L29.8126 2=
5.1562C32.3907 25.1562 35.2032 23.0469 35.4376 19.5312C35.672 16.0156 34.03=
14 13.2031 29.8126 13.2031H16.2188V35ZM27.0001 17.6562H22.7814V21.875H27.00=
01C29.3437 21.875 29.3437 17.6562 27.0001 17.6562Z" fill=3D"#6D6D93"></path=
>
</g>
<defs>
<clipPath id=3D"clip0_2886_601">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
        </a>

        <a target=3D"_blank" href=3D"https://www.programiz.com/sql/online-c=
ompiler/" class=3D"change-lang-btn sql" title=3D"Online SQL Editor">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"21" height=3D"=
28" viewBox=3D"0 0 21 28" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M10.8017 4.96503C16.=
2496 4.96503 20.6659 4.07743 20.6659 2.98251C20.6659 1.8876 16.2496 1 10.80=
17 1C5.35386 1 0.9375 1.8876 0.9375 2.98251C0.9375 4.07743 5.35386 4.96503 =
10.8017 4.96503ZM10.8019 4.19152C15.7423 4.19152 19.7474 3.58535 19.7474 2.=
8376C19.7474 2.08986 15.7423 1.48369 10.8019 1.48369C5.86141 1.48369 1.8563=
8 2.08986 1.85638 2.8376C1.85638 3.58535 5.86141 4.19152 10.8019 4.19152Z" =
fill=3D"#A8A8BF"></path>
<path d=3D"M20.3659 2.98251C20.3659 3.01082 20.353 3.0721 20.2553 3.16803C2=
0.1571 3.26451 19.9962 3.37195 19.762 3.48323C19.2951 3.70509 18.6003 3.912=
85 17.7177 4.09024C15.9573 4.44404 13.512 4.66503 10.8017 4.66503V5.26503C1=
3.5393 5.26503 16.0261 5.04221 17.8359 4.67848C18.7383 4.49711 19.4881 4.27=
768 20.0195 4.02516C20.2845 3.89926 20.5112 3.75773 20.6757 3.59609C20.8409=
 3.4339 20.9659 3.22793 20.9659 2.98251H20.3659ZM10.8017 1.3C13.512 1.3 15.=
9573 1.52099 17.7177 1.87478C18.6003 2.05218 19.2951 2.25994 19.762 2.4818C=
19.9962 2.59307 20.1571 2.70052 20.2553 2.797C20.353 2.89292 20.3659 2.9542=
 20.3659 2.98251H20.9659C20.9659 2.7371 20.8409 2.53113 20.6757 2.36894C20.=
5112 2.2073 20.2845 2.06577 20.0195 1.93986C19.4881 1.68735 18.7383 1.46792=
 17.8359 1.28655C16.0261 0.922815 13.5393 0.7 10.8017 0.7V1.3ZM1.2375 2.982=
51C1.2375 2.9542 1.25046 2.89292 1.34812 2.797C1.44635 2.70052 1.60725 2.59=
307 1.84143 2.4818C2.30833 2.25994 3.00312 2.05218 3.88577 1.87478C5.64613 =
1.52099 8.09145 1.3 10.8017 1.3V0.7C8.06413 0.7 5.57733 0.922815 3.76755 1.=
28655C2.86513 1.46792 2.11534 1.68735 1.58392 1.93986C1.31896 2.06577 1.092=
26 2.2073 0.927691 2.36894C0.762556 2.53113 0.6375 2.7371 0.6375 2.98251H1.=
2375ZM10.8017 4.66503C8.09145 4.66503 5.64613 4.44404 3.88577 4.09024C3.003=
12 3.91285 2.30833 3.70509 1.84143 3.48323C1.60725 3.37195 1.44635 3.26451 =
1.34812 3.16803C1.25046 3.0721 1.2375 3.01082 1.2375 2.98251H0.6375C0.6375 =
3.22793 0.762556 3.4339 0.927691 3.59609C1.09226 3.75773 1.31896 3.89926 1.=
58392 4.02516C2.11534 4.27768 2.86513 4.49711 3.76755 4.67848C5.57733 5.042=
21 8.06413 5.26503 10.8017 5.26503V4.66503ZM19.4474 2.8376C19.4474 2.78735 =
19.4799 2.8007 19.3872 2.86927C19.3023 2.9321 19.158 3.00532 18.9433 3.0821=
5C18.5175 3.2345 17.8846 3.37692 17.0824 3.49834C15.4825 3.74048 13.2619 3.=
89152 10.8019 3.89152V4.49152C13.2823 4.49152 15.5344 4.33947 17.1722 4.091=
59C17.9887 3.968 18.6659 3.81867 19.1454 3.64707C19.3834 3.56191 19.5906 3.=
46511 19.744 3.35166C19.8896 3.24396 20.0474 3.07479 20.0474 2.8376H19.4474=
ZM10.8019 1.78369C13.2619 1.78369 15.4825 1.93473 17.0824 2.17687C17.8846 2=
.29829 18.5175 2.4407 18.9433 2.59306C19.158 2.66989 19.3023 2.74311 19.387=
2 2.80594C19.4799 2.87451 19.4474 2.88785 19.4474 2.8376H20.0474C20.0474 2.=
60042 19.8896 2.43125 19.744 2.32355C19.5906 2.2101 19.3834 2.11329 19.1454=
 2.02814C18.6659 1.85654 17.9887 1.70721 17.1722 1.58362C15.5344 1.33574 13=
.2823 1.18369 10.8019 1.18369V1.78369ZM2.15638 2.8376C2.15638 2.88785 2.123=
8 2.87451 2.21651 2.80594C2.30145 2.74311 2.44574 2.66989 2.66043 2.59306C3=
.08621 2.4407 3.71909 2.29829 4.52134 2.17687C6.1212 1.93473 8.34185 1.7836=
9 10.8019 1.78369V1.18369C8.32142 1.18369 6.06933 1.33574 4.43155 1.58362C3=
.61499 1.70721 2.93784 1.85654 2.45828 2.02814C2.22031 2.11329 2.0131 2.210=
1 1.85972 2.32355C1.71411 2.43125 1.55638 2.60042 1.55638 2.8376H2.15638ZM1=
0.8019 3.89152C8.34185 3.89152 6.1212 3.74048 4.52134 3.49834C3.71909 3.376=
92 3.08621 3.2345 2.66043 3.08215C2.44574 3.00532 2.30145 2.9321 2.21651 2.=
86927C2.1238 2.8007 2.15638 2.78735 2.15638 2.8376H1.55638C1.55638 3.07479 =
1.71411 3.24396 1.85972 3.35166C2.0131 3.46511 2.22031 3.56191 2.45828 3.64=
707C2.93784 3.81867 3.61499 3.968 4.43155 4.09159C6.06933 4.33947 8.32142 4=
.49152 10.8019 4.49152V3.89152Z" fill=3D"#A8A8BF"></path>
<path d=3D"M0.9375 2.93359C0.9375 2.93359 4.43011 4.25786 10.7679 4.25786C1=
7.1057 4.25786 20.6659 2.93359 20.6659 2.93359V8.76378C20.6659 8.76378 20.1=
582 11.1054 10.8017 11.1054C1.44522 11.1054 0.9375 8.76378 0.9375 8.76378V2=
.93359Z" fill=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-li=
necap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M0.9375 11.0636C0.9375 11.0636 0.944635 10.9089 0.985854 10.8218=
C1.04301 10.7012 1.22762 10.5801 1.22762 10.5801C1.22762 10.5801 2.92001 12=
.3208 10.8017 12.3208C18.6834 12.3208 20.3033 10.5801 20.3033 10.5801C20.49=
98 10.6953 20.6196 10.8408 20.6659 11.0636V16.8938C20.6659 16.8938 20.1582 =
19.2354 10.8017 19.2354C1.44522 19.2354 0.9375 16.8938 0.9375 16.8938V11.06=
36Z" fill=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-lineca=
p=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M0.9375 19.2238C0.9375 19.2238 0.944635 19.069 0.985854 18.982C1=
.04301 18.8613 1.22762 18.7402 1.22762 18.7402C1.22762 18.7402 2.92001 20.4=
81 10.8017 20.481C18.6834 20.481 20.3033 18.7402 20.3033 18.7402C20.4998 18=
.8554 20.6196 19.0009 20.6659 19.2238V25.054C20.6659 25.054 20.1582 27.3956=
 10.8017 27.3956C1.44522 27.3956 0.9375 25.054 0.9375 25.054V19.2238Z" fill=
=3D"#A8A8BF" stroke=3D"#A8A8BF" stroke-width=3D"0.6" stroke-linecap=3D"roun=
d" stroke-linejoin=3D"round"></path>
</svg>
        </a>

        <a target=3D"_blank" href=3D"https://www.programiz.com/html/online-=
compiler/" class=3D"change-lang-btn html" title=3D"Online HTML/CSS Editor">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"86" height=3D"=
98" viewBox=3D"0 0 86 98" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M0 0L7.81641 87.668L=
42.8914 97.4047L78.0625 87.6547L85.8875 0H0ZM42.9624 39.9803H28.7717L27.788=
9 28.9693H42.9624H42.9998H68.9343L69.1499 26.5537L69.6405 21.1021L69.8976 1=
8.2178H42.9998H42.9624H16.0381L16.2959 21.1021L18.9381 50.7326H42.9624H42.9=
998H56.2022L54.9546 64.6772L42.9624 67.9139V67.9149L42.9521 67.9178L30.9779=
 64.6834L30.2131 56.1092H19.4186L20.9248 72.9912L42.9506 79.1053L42.9998 79=
.092V79.0902L65.0054 72.9912L65.1671 71.1748L67.6936 42.8678L67.9554 39.980=
3H65.0585H42.9998H42.9624Z" fill=3D"#F9F7F7"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/java-program=
ming/online-compiler/" class=3D"change-lang-btn java " title=3D"Online Java=
 Compiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewBox=
=3D"0 0 21 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-rule=3D"evenodd" d=3D"M13.266 1s2.718 2.703-2.578 6.857c-3.285=
 2.578-2.069 4.3-.902 5.951.343.485.68.963.9 1.456-2.48-2.223-4.298-4.18-3.=
078-6.002.596-.89 1.543-1.626 2.501-2.372 1.922-1.495 3.889-3.026 3.157-5.8=
9zm-1.403 12.431c1.263 1.445-.331 2.744-.331 2.744s3.204-1.644 1.733-3.703a=
46.915 46.915 0 00-.175-.242c-1.278-1.764-2.008-2.772 3.452-5.92 0 0-8.956 =
2.223-4.679 7.122zm-4.65 7.678s-.998.577.713.772c2.073.236 3.133.202 5.417-=
.227 0 0 .601.374 1.44.698-5.122 2.18-11.592-.127-7.57-1.244zm-.625-2.847s-=
1.121.825.591 1.001c2.215.227 3.964.246 6.99-.333 0 0 .419.422 1.076.652-6.=
191 1.8-13.088.142-8.657-1.32zm11.235 6.028c1.554-.468.815-1.075.815-1.075 =
2.708 1.215-5.885 3.655-16.326 1.972-3.83-.617 1.842-2.77 2.88-2.044 0 0-.3=
28-.022-.902.101-.55.118-2.3.678-1.368 1.082 2.597 1.122 11.945.854 14.9-.0=
36zM6.01 16.845c-3.07-.409 1.684-1.531 1.684-1.531s-1.847-.124-4.117.967c-2=
.686 1.29 6.641 1.879 11.47.616.503-.34 1.196-.636 1.196-.636s-1.975.351-3.=
943.516c-2.409.2-4.993.24-6.29.067zM17.28 15.41c1.584-.328 3.854 2.108-1.05=
5 4.642-.02.055-.084.115-.096.127l-.002.001c6.555-1.712 4.145-6.036 1.011-4=
.941a.89.89 0 00-.419.321s.174-.07.561-.15zm3.017 9.127c-.172 2.216-7.408 2=
.681-12.118 2.382-3.096-.198-3.699-.694-3.699-.694 2.941.483 7.902.57 11.92=
3-.182 3.564-.666 3.893-1.506 3.893-1.506z" clip-rule=3D"evenodd"></path>
  <path d=3D"M10.688 7.857l-.186-.236.186.236zM13.266 1l.212-.213a.3.3 0 00=
-.502.287l.29-.074zm-3.48 12.808l-.245.174.245-.174zm.9 1.456l-.2.223a.3.3 =
0 00.474-.345l-.274.122zM7.608 9.262l-.25-.167.25.167zm2.501-2.372l.184.237=
-.184-.237zm1.423 9.285l-.19-.233a.3.3 0 00.327.5l-.137-.267zm.331-2.744l-.=
226.198.226-.197zm1.402-.96l.244-.174-.244.175zm-.175-.241l-.243.176.243-.1=
76zm3.452-5.92l.15.26a.3.3 0 00-.222-.55l.072.29zM7.926 21.882l-.034.298.03=
4-.298zm-.712-.773l.15.26a.3.3 0 00-.23-.549l.08.29zm6.129.546l.158-.255a.3=
.3 0 00-.214-.04l.056.295zm1.44.698l.118.276a.3.3 0 00-.01-.556l-.108.28zM7=
.18 19.263l-.03.298.03-.298zm-.591-1l.177.24a.3.3 0 00-.271-.526l.094.285zm=
7.582.667l.213-.211a.3.3 0 00-.27-.084l.057.295zm1.075.652l.084.288a.3.3 0 =
00.016-.571l-.1.283zm3.393 3.633l.122-.273a.3.3 0 00-.312.505l.19-.232zm-.8=
15 1.075l.086.287-.086-.287zm-15.511.897l-.048.297.048-.297zm2.88-2.044l-.0=
2.3a.3.3 0 00.192-.546l-.172.246zm-.902.101l.063.293-.063-.293zm-1.368 1.08=
2l-.119.275.12-.275zm4.773-9.012l.069.292a.3.3 0 00-.049-.591l-.02.299zm-1.=
684 1.53l.04-.297-.04.297zm-2.433-.563l.13.27-.13-.27zm11.47.616l.077.29a.3=
01.301 0 00.092-.042l-.168-.248zm1.196-.636l.118.276a.3.3 0 00-.17-.571l.05=
2.295zm-3.943.516l.025.299-.025-.3zm3.923 3.275l-.137-.267a.3.3 0 00-.143.1=
6l.28.107zm1.055-4.642l.061.294-.06-.294zm-1.15 4.769l-.208-.218-.005.005.2=
12.213zm0 0l.208.215.003-.003-.212-.212zm-.003.001l-.209-.215a.3.3 0 00.285=
.506l-.076-.29zm1.011-4.941l-.099-.284.1.284zm-.419.321l-.252-.162a.3.3 0 0=
0.364.44l-.112-.278zm-8.54 11.36l-.02.298.02-.299zm12.117-2.383l.3.023a.3.3=
 0 00-.579-.132l.28.11zM4.48 26.225l.049-.296a.3.3 0 00-.349.296h.3zm11.923=
-.182l-.055-.295.055.295zm-5.53-17.95c2.69-2.11 3.41-3.904 3.391-5.227-.01-=
.655-.2-1.17-.391-1.521a2.916 2.916 0 00-.353-.514 1.677 1.677 0 00-.036-.0=
39L13.48.79h-.001V.787L13.265 1c-.211.213-.211.213-.212.212l.002.003.016.01=
6c.014.017.037.042.064.078.055.07.131.178.208.32.154.286.311.706.32 1.246.0=
15 1.067-.555 2.702-3.162 4.746l.37.473zm-.84 5.542c-.597-.844-1.13-1.613-1=
.165-2.467-.033-.82.397-1.812 2.006-3.075l-.37-.472c-1.677 1.316-2.28 2.473=
-2.235 3.571.043 1.064.703 1.982 1.273 2.79l.49-.347zm.928 1.507c-.233-.525=
-.59-1.028-.929-1.507l-.49.347c.347.49.666.944.871 1.404l.548-.244zM7.358 9=
.095c-.34.51-.475 1.04-.432 1.585.043.537.257 1.068.578 1.59.638 1.037 1.74=
5 2.108 2.982 3.217l.4-.446c-1.242-1.114-2.285-2.133-2.871-3.086-.291-.473-=
.458-.912-.49-1.323-.033-.404.063-.801.332-1.203l-.499-.334zm2.567-2.442c-.=
948.738-1.938 1.505-2.567 2.442l.499.334c.564-.841 1.468-1.549 2.436-2.302l=
-.368-.474zm3.05-5.579c.343 1.342.056 2.352-.54 3.214-.609.882-1.54 1.61-2.=
51 2.365l.368.474c.953-.741 1.965-1.526 2.637-2.498.685-.993 1.016-2.18.627=
-3.703l-.582.148zm-1.443 15.1l.19.233.002-.002.006-.004a12.436 12.436 0 00.=
073-.066 2.969 2.969 0 00.639-.861c.137-.287.235-.64.201-1.03-.034-.395-.2-=
.806-.554-1.21l-.452.395c.279.318.386.612.408.866a1.39 1.39 0 01-.145.72 2.=
287 2.287 0 01-.556.726l-.002.002.19.232zm1.49-3.528c.32.45.375.854.3 1.211=
-.079.37-.303.722-.592 1.035a5.084 5.084 0 01-.888.745 5.698 5.698 0 01-.41=
7.255l-.024.013-.005.002h-.001l.137.268.137.267.001-.001.003-.001a5.685 5.6=
85 0 001.498-1.14c.328-.356.629-.802.738-1.319.111-.53.014-1.104-.4-1.684l-=
.488.35zm-.175-.24l.174.24.488-.349-.176-.243-.486.352zm3.545-6.355c-1.371.=
79-2.366 1.453-3.064 2.034-.696.577-1.12 1.093-1.318 1.595-.204.519-.15.99.=
036 1.439.179.43.488.854.801 1.287l.486-.352c-.325-.45-.587-.813-.733-1.166=
-.14-.335-.168-.642-.031-.99.143-.363.479-.8 1.142-1.352.66-.549 1.622-1.19=
2 2.98-1.975l-.299-.52zm-4.303 7.183c-1.026-1.175-1.214-2.133-1.01-2.905.21=
2-.794.86-1.479 1.69-2.047.823-.564 1.783-.985 2.544-1.266a15.575 15.575 0 =
011.296-.413h.004l.001-.001-.072-.291-.073-.291h-.002l-.005.002a3.097 3.097=
 0 00-.098.025 16.165 16.165 0 00-1.258.406c-.784.29-1.796.73-2.677 1.334-.=
875.6-1.664 1.388-1.93 2.388-.27 1.023.026 2.18 1.138 3.454l.452-.395zm-4.1=
3 8.35c-.417-.048-.627-.116-.72-.168-.045-.024-.041-.034-.03-.015a.124.124 =
0 01.013.083c-.005.02-.003-.003.057-.054a.704.704 0 01.082-.06l.004-.002-.1=
51-.26-.15-.26v.001h-.001l-.002.001-.004.003a1.94 1.94 0 00-.05.032c-.031.0=
2-.073.05-.117.089-.074.063-.215.197-.255.385a.477.477 0 00.054.342.658.658=
 0 00.258.24c.2.11.507.189.945.238l.068-.596zm5.328-.225c-2.256.424-3.285.4=
56-5.327.224l-.068.596c2.105.24 3.194.204 5.506-.23l-.11-.59zm1.604.713a9.7=
37 9.737 0 01-1.367-.659c-.008-.005-.014-.009-.018-.01l-.004-.003-.001-.001=
-.158.255-.159.255h.001l.002.001.006.004.023.014.084.05a10.362 10.362 0 001=
.375.654l.216-.56zm-7.757-1.253c-.517.144-.905.316-1.152.523a.919.919 0 00-=
.284.379.665.665 0 00-.001.46c.098.276.358.488.648.649.302.168.696.313 1.15=
.428 1.81.457 4.777.49 7.406-.63l-.235-.552c-2.494 1.061-5.324 1.03-7.023.6=
a4.304 4.304 0 01-1.007-.37c-.256-.143-.352-.263-.374-.326a.066.066 0 01-.0=
01-.051.335.335 0 01.106-.127c.149-.125.438-.269.927-.404l-.16-.579zm.076-1=
.854c-.415-.043-.597-.121-.665-.172-.028-.021-.024-.027-.02-.014.004.012 0 =
.015.004.001a.509.509 0 01.125-.176 1.176 1.176 0 01.106-.096l.005-.004h.00=
1l-.178-.242-.178-.241h-.001l-.002.001-.004.003-.012.01a1.51 1.51 0 00-.166=
.15c-.088.088-.218.24-.272.428-.029.1-.04.22 0 .346a.63.63 0 00.231.313c.20=
3.153.523.244.965.29l.061-.597zm6.904-.33c-2.996.573-4.715.554-6.904.33l-.0=
61.596c2.24.23 4.018.248 7.077-.337l-.113-.589zm1.23.664a2.835 2.835 0 01-.=
96-.579l-.002-.002h.001l-.213.212a46.433 46.433 0 00-.213.211v.001l.003.002=
.005.005.018.018.065.058a3.438 3.438 0 001.098.64l.199-.566zm-8.85-1.322c-.=
566.187-.984.386-1.25.603-.265.216-.45.517-.325.86.104.287.394.487.703.629.=
327.15.756.275 1.255.37 1.993.382 5.313.343 8.452-.569l-.167-.576c-3.052.88=
7-6.276.92-8.172.556-.473-.09-.85-.203-1.117-.326-.284-.131-.374-.243-.39-.=
288-.003-.009-.005-.016.003-.036a.457.457 0 01.137-.155c.18-.147.516-.319 1=
.059-.498l-.188-.57zm12.144 5.238l-.19.232h-.001l-.002-.001v-.001c-.001 0-.=
001 0 0 0l.008.008c.008.008.02.021.03.037.025.035.031.06.03.074 0 .001.002.=
047-.098.129-.106.087-.309.198-.679.31l.173.574c.408-.123.695-.263.888-.42.=
198-.164.307-.358.316-.567a.722.722 0 00-.139-.445.907.907 0 00-.127-.145l-=
.012-.01-.004-.004-.002-.002-.191.231zM2.264 25.484c5.253.846 10.045.657 13=
.194.1 1.564-.278 2.76-.652 3.4-1.058.163-.104.305-.218.407-.345a.724.724 0=
 00.177-.47c-.008-.372-.334-.613-.681-.77l-.246.548c.15.068.24.13.287.178.0=
23.023.033.04.037.048l.003.008v.005a.26.26 0 01-.044.076c-.047.059-.13.132-=
.261.215-.535.34-1.632.699-3.183.973-3.081.546-7.806.735-12.995-.1l-.095.59=
2zm3.1-2.587c-.202-.14-.475-.19-.74-.2a4.4 4.4 0 00-.91.077 7.598 7.598 0 0=
0-1.92.618c-.28.137-.534.293-.725.46-.18.158-.36.376-.369.643-.01.302.193.5=
18.447.66.255.141.626.25 1.117.329l.095-.593c-.466-.075-.756-.17-.92-.26a.4=
11.411 0 01-.13-.102l-.009-.013c0-.01.017-.083.164-.213.136-.12.34-.247.595=
-.372a7.003 7.003 0 011.759-.566c.295-.053.565-.076.784-.068.229.009.36.051=
.418.092l.344-.492zm-1.01.64c.271-.058.482-.081.621-.09a2.307 2.307 0 01.19=
7-.005l.02-.299.02-.3h-.024a2.871 2.871 0 00-.25.005 4.88 4.88 0 00-.711.10=
3l.126.586zm-1.313.513c-.097-.042-.115-.069-.11-.061.02.027.03.078.015.119-=
.006.017-.006.002.044-.039.045-.037.112-.08.2-.126.356-.188.903-.35 1.163-.=
406l-.126-.586c-.29.062-.894.239-1.317.461-.107.057-.212.121-.3.193a.715.71=
5 0 00-.226.293.464.464 0 00.066.45.85.85 0 00.353.253l.238-.55zm14.695-.04=
7c-1.434.431-4.473.721-7.502.76-1.508.018-3.002-.026-4.276-.143-1.285-.119-=
2.315-.31-2.917-.57l-.238.55c.696.302 1.809.498 3.1.617 1.3.12 2.816.164 4.=
339.145 3.033-.038 6.146-.327 7.667-.785l-.173-.574zM7.695 15.314l-.07-.292=
h-.003c-.002.002-.006.002-.01.003l-.041.01a16.032 16.032 0 00-.652.172c-.40=
1.112-.913.27-1.332.442-.208.086-.406.18-.559.282-.076.051-.152.11-.213.18a=
.521.521 0 00-.135.297.45.45 0 00.128.35c.076.08.176.137.276.18.202.086.497=
.152.888.204l.079-.595c-.377-.05-.606-.108-.732-.162-.063-.027-.079-.043-.0=
75-.04.01.012.039.053.034.114-.004.047-.026.064-.011.047a.495.495 0 01.094-=
.075c.104-.07.26-.147.455-.227.386-.16.87-.309 1.265-.42a20.51 20.51 0 01.6=
32-.166l.038-.01.01-.001h.002v-.001l-.068-.292zm-3.987 1.237a9.68 9.68 0 01=
2.822-.866c.36-.05.65-.068.849-.074a4.554 4.554 0 01.28.002h.016l.02-.299.0=
2-.3h-.001-.027a3.501 3.501 0 00-.324-.002 8.124 8.124 0 00-.917.08c-.77.10=
8-1.83.357-2.998.919l.26.54zm11.265.056c-2.373.62-5.878.79-8.46.64-1.3-.075=
-2.323-.23-2.849-.428a.984.984 0 01-.252-.128c-.045-.036-.014-.03-.011.023.=
003.054-.029.062.018.017.045-.044.134-.105.289-.18l-.26-.54c-.181.087-.334.=
18-.445.287a.581.581 0 00-.201.448c.01.19.126.327.236.414.112.09.257.16.414=
.22.619.235 1.725.39 3.026.466 2.617.151 6.19-.017 8.647-.659l-.152-.58zm1.=
271-.346l-.117-.276h-.001l-.002.001a7.207 7.207 0 00-1.243.662l.336.497c.23=
4-.158.52-.31.75-.424a9.775 9.775 0 01.367-.172l.021-.009.006-.002-.117-.27=
7zm-3.918.815a45.615 45.615 0 002.728-.322 52.192 52.192 0 001.152-.182l.06=
7-.011.018-.003.004-.001h.001l-.052-.296-.052-.295h-.002-.004c-.003.002-.00=
9.002-.016.004a13.238 13.238 0 01-.314.053c-.214.035-.52.084-.889.137a45.05=
 45.05 0 01-2.69.318l.05.598zm-6.354.066c1.33.177 3.941.135 6.354-.066l-.05=
-.598c-2.404.2-4.962.237-6.225.07l-.08.594zm10.39 3.177c2.47-1.276 3.309-2.=
614 3.12-3.712-.184-1.077-1.331-1.684-2.264-1.49l.122.587c.652-.135 1.432.3=
12 1.551 1.005.115.671-.366 1.817-2.804 3.076l.275.534zm-.027.077a.91.91 0 =
00.066-.07.584.584 0 00.104-.168l-.561-.212a.147.147 0 01.007-.016l.002-.00=
3-.008.01a.326.326 0 01-.024.024l.414.435zm.005-.005l-.424-.425.424.425zm-.=
004.004l.002-.001-.419-.43-.002.001.419.43zm.9-4.873c1.441-.503 2.593.258 2=
.732 1.18.07.463-.093 1.038-.687 1.615-.597.58-1.622 1.153-3.23 1.573l.151.=
58c1.669-.435 2.8-1.046 3.497-1.723.701-.681.968-1.44.863-2.135-.21-1.394-1=
.83-2.248-3.524-1.656l.198.566zm-.518.038l.253.162-.001.001v.001l-.001.001v=
-.002l.011-.014a.594.594 0 01.257-.187l-.2-.566a1.169 1.169 0 00-.566.434l-=
.003.005-.001.002h-.001v.001l.252.162zm.5-.444a5.432 5.432 0 00-.566.149 1.=
725 1.725 0 00-.04.015h-.003l-.002.001.111.28.112.278h-.001l.003-.001.018-.=
007a4.842 4.842 0 01.49-.127l-.122-.588zm-9.06 12.102c2.37.151 5.38.11 7.82=
5-.25 1.22-.18 2.32-.441 3.133-.809.793-.358 1.422-.868 1.479-1.599l-.599-.=
046c-.029.377-.368.756-1.127 1.099-.739.333-1.775.585-2.974.761-2.393.353-5=
.358.395-7.698.246l-.038.598zm-3.979-.993a.622.622 0 00.105.228l.004.003a.4=
1.41 0 00.004.004l.006.005a.385.385 0 00.055.037c.033.02.079.046.14.075.123=
.058.312.132.594.21.564.156 1.51.332 3.071.431l.039-.598c-1.535-.098-2.438-=
.27-2.95-.411a3.156 3.156 0 01-.497-.174.819.819 0 01-.081-.043l-.008-.005.=
003.002.003.003.004.002.003.004a.622.622 0 01.105.228h-.6zm12.168-.477c-3.9=
85.746-8.91.659-11.82.181l-.097.592c2.974.488 7.97.576 12.027-.183l-.11-.59=
zm3.948-1.21l-.279-.111v-.001l.002-.002v-.003l.003-.006a.173.173 0 01.004-.=
007l-.001.002a.426.426 0 01-.05.06c-.063.064-.19.173-.434.308-.49.272-1.428=
.64-3.193.97l.11.59c1.8-.336 2.808-.72 3.374-1.035.284-.158.462-.301.573-.4=
15a1.027 1.027 0 00.153-.203.499.499 0 00.015-.03l.001-.005.001-.001v-.001l=
-.279-.11z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/c-programmin=
g/online-compiler/" class=3D"change-lang-btn c active" title=3D"Online C Co=
mpiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewBox=
=3D"0 0 24 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M23.903 6.916l.067-.044c-.134-.243-.334-.4=
64-.534-.574L12.696.155C12.518.045 12.274 0 12.007 0c-.267 0-.511.066-.69.1=
55L.646 6.32C.267 6.54 0 7.093 0 7.513v12.308c0 .243.044.508.2.752l-.044.02=
2c.11.176.266.331.422.42l10.718 6.165c.178.11.422.154.689.154.267 0 .511-.0=
66.69-.154l10.672-6.165c.378-.221.645-.774.645-1.194V7.491c.022-.177 0-.376=
-.089-.575zM12.007 19.07a5.455 5.455 0 004.736-2.74l2.869 1.68a8.794 8.794 =
0 01-7.605 4.374c-4.847 0-8.783-3.91-8.783-8.728 0-4.817 3.936-8.728 8.783-=
8.728a8.796 8.796 0 017.627 4.42l-2.89 1.656a5.43 5.43 0 00-4.737-2.762c-3.=
002 0-5.448 2.431-5.448 5.414 0 2.983 2.446 5.414 5.448 5.414z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/cpp-programm=
ing/online-compiler/" class=3D"change-lang-btn cpp " title=3D"Online C++ Co=
mpiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewBox=
=3D"0 0 24 27" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill=3D"#25265E" fill-opacity=3D".4" d=3D"M23.903 6.639l.067-.043c-=
.134-.233-.334-.445-.534-.551L12.696.148C12.518.042 12.274 0 12.007 0a1.64 =
1.64 0 00-.69.148L.646 6.066C.267 6.278 0 6.808 0 7.21v11.814c0 .233.044.48=
8.2.72l-.044.022c.11.17.266.318.422.403l10.718 5.918c.178.106.422.148.689.1=
48.267 0 .511-.064.69-.148l10.672-5.918c.378-.212.645-.742.645-1.145V7.19c.=
022-.17 0-.36-.089-.551zm-7.893 6.893v-.849h1.111v-1.06h1.112v1.06h1.112v.8=
49h-1.112v1.06h-1.112v-1.06H16.01zm.733-2.97c-.934-1.59-2.712-2.65-4.736-2.=
65-3.002 0-5.448 2.332-5.448 5.195 0 2.864 2.446 5.197 5.448 5.197 2.024 0 =
3.802-1.06 4.736-2.63l2.869 1.612c-1.512 2.502-4.358 4.2-7.605 4.2-4.847 0-=
8.783-3.755-8.783-8.379 0-4.623 3.936-8.377 8.783-8.377 3.269 0 6.115 1.718=
 7.627 4.242l-2.89 1.59zm6.604 2.97h-1.112v1.06h-.889v-1.06h-1.334v-.849h1.=
334v-1.06h.89v1.06h1.111v.849z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/csharp-progr=
amming/online-compiler/" class=3D"change-lang-btn csharp " title=3D"Online =
C# Compiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"none" viewBox=
=3D"0 0 24 28" class=3D"change-lang-btn-icon svg replaced-svg">
  <path fill-opacity=3D".4" d=3D"M23.903 6.916l.067-.044c-.134-.243-.334-.4=
64-.534-.574L12.696.155C12.518.045 12.274 0 12.007 0c-.267 0-.511.066-.69.1=
55L.646 6.32C.267 6.54 0 7.093 0 7.513v12.308c0 .243.044.508.2.752l-.044.02=
2c.11.176.266.331.422.42l10.718 6.165c.178.11.422.154.689.154.267 0 .511-.0=
66.69-.154l10.672-6.165c.378-.221.645-.774.645-1.194V7.491c.022-.177 0-.376=
-.089-.575zM12.007 22.384c-4.847 0-8.783-3.91-8.783-8.728 0-4.817 3.936-8.7=
28 8.783-8.728a8.796 8.796 0 017.627 4.42l-2.89 1.656a5.43 5.43 0 00-4.737-=
2.762c-3.002 0-5.448 2.431-5.448 5.414 0 2.983 2.446 5.414 5.448 5.414a5.45=
5 5.455 0 004.736-2.74l2.869 1.68a8.794 8.794 0 01-7.605 4.374zm11.34-9.17h=
-.711l-.2.884h.911v1.105h-1.112l-.266 1.326h-1.09l.267-1.326H20.3l-.267 1.3=
26h-1.067l.267-1.326h-.556v-1.105h.778l.2-.884h-.978V12.11h1.178l.267-1.325=
h1.09l-.267 1.325h.845l.267-1.325h1.067l-.267 1.325h.49v1.105zm-2.824.884h.=
845l.2-.884h-.845l-.2.884z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/javascript/o=
nline-compiler/" class=3D"change-lang-btn javascript " title=3D"Online Java=
Script Compiler (Editor)">
          <svg xmlns=3D"http://www.w3.org/2000/svg" viewBox=3D"0 0 630 630"=
 class=3D"change-lang-btn-icon svg replaced-svg">
<rect width=3D"630" height=3D"630" fill=3D"#25265E" fill-opacity=3D"0.0"></=
rect>
<path d=3D"m423.2 492.19c12.69 20.72 29.2 35.95 58.4 35.95 24.53 0 40.2-12.=
26 40.2-29.2 0-20.3-16.1-27.49-43.1-39.3l-14.8-6.35c-42.72-18.2-71.1-41-71.=
1-89.2 0-44.4 33.83-78.2 86.7-78.2 37.64 0 64.7 13.1 84.2 47.4l-46.1 29.6c-=
10.15-18.2-21.1-25.37-38.1-25.37-17.34 0-28.33 11-28.33 25.37 0 17.76 11 24=
.95 36.4 35.95l14.8 6.34c50.3 21.57 78.7 43.56 78.7 93 0 53.3-41.87 82.5-98=
.1 82.5-54.98 0-90.5-26.2-107.88-60.54zm-209.13 5.13c9.3 16.5 17.76 30.45 3=
8.1 30.45 19.45 0 31.72-7.61 31.72-37.2v-201.3h59.2v202.1c0 61.3-35.94 89.2=
-88.4 89.2-47.4 0-74.85-24.53-88.81-54.075z"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/golang/onlin=
e-compiler/" class=3D"change-lang-btn golang " title=3D"Online Golang Compi=
ler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=3D"=
40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<g clip-path=3D"url(#clip0_2886_601)">
<path d=3D"M3.00684 16.739C2.9516 16.739 2.89634 16.6837 2.9516 16.6285L3.3=
3841 16.0759C3.39365 16.0206 3.44891 15.9654 3.55944 15.9654H10.522C10.5772=
 15.9654 10.6325 16.0206 10.5772 16.0759L10.2457 16.5731C10.1905 16.6285 10=
.1352 16.6837 10.0247 16.6837L3.00684 16.739ZM0.0781503 18.5072C0.0228897 1=
8.5072 -0.0323709 18.4519 0.0228897 18.3967L0.409701 17.8441C0.464961 17.78=
88 0.520209 17.7336 0.63073 17.7336H9.52736C9.58262 17.7336 9.63788 17.7888=
 9.63788 17.8441L9.47211 18.3967C9.47211 18.4519 9.36159 18.5072 9.30633 18=
.5072H0.0781503ZM4.77513 20.3307C4.71987 20.3307 4.66461 20.2755 4.71987 20=
.2202L4.99616 19.7229C5.05142 19.6676 5.10668 19.6124 5.21719 19.6124H9.085=
3C9.14055 19.6124 9.19581 19.6676 9.19581 19.7229L9.14055 20.165C9.14055 20=
.2202 9.0853 20.2755 9.03004 20.2755L4.77513 20.3307ZM24.9997 16.3521L21.73=
94 17.181C21.4632 17.2362 21.408 17.2916 21.187 16.96C20.9106 16.6285 20.68=
96 16.4074 20.2475 16.2416C19.0318 15.6338 17.8161 15.7995 16.711 16.5179C1=
5.3848 17.3468 14.7217 18.6178 14.7217 20.2202C14.7217 21.7674 15.8268 23.0=
384 17.3741 23.2595C18.7003 23.4252 19.8054 22.9831 20.6896 21.9886C20.8554=
 21.7674 21.0211 21.5464 21.2422 21.2702H17.4846C17.0977 21.2702 16.9872 20=
.9938 17.0977 20.6624C17.3741 20.0545 17.8161 19.0598 18.0925 18.5624C18.14=
77 18.4519 18.3134 18.2309 18.5898 18.2309H25.6628C25.6076 18.7835 25.6076 =
19.2809 25.5523 19.8334C25.3313 21.215 24.834 22.5412 23.9499 23.6462C22.56=
84 25.4698 20.7449 26.6303 18.4239 26.9617C16.4899 27.2381 14.7217 26.8512 =
13.1744 25.6908C11.7377 24.5857 10.9088 23.149 10.6879 21.3807C10.4115 19.2=
809 11.0746 17.3468 12.3455 15.689C13.727 13.8655 15.5505 12.7051 17.8161 1=
2.3183C19.6396 11.9867 21.408 12.2078 22.9552 13.2576C24.0051 13.9207 24.72=
35 14.8602 25.2208 16.0206C25.2761 16.2416 25.2208 16.2969 24.9997 16.3521Z=
" fill=3D"#6D6D93"></path>
<path d=3D"M31.4177 27.1297C29.6494 27.0745 28.0469 26.5771 26.6653 25.4168=
C25.505 24.4221 24.7867 23.1511 24.5655 21.6592C24.2341 19.4489 24.8419 17.=
5148 26.1681 15.8018C27.6048 13.9229 29.3179 12.9836 31.6387 12.5415C33.628=
 12.2099 35.5068 12.3758 37.1646 13.5361C38.7118 14.586 39.6511 16.0227 39.=
9275 17.9015C40.259 20.554 39.4854 22.6537 37.7171 24.4773C36.4461 25.8035 =
34.8437 26.5771 33.0754 26.964C32.4675 27.0745 31.9149 27.0745 31.4177 27.1=
297ZM36.0594 19.283C36.0594 19.0068 36.0594 18.841 36.0041 18.6199C35.6725 =
16.6858 33.9043 15.5808 32.0255 16.0227C30.202 16.4096 29.0415 17.5701 28.5=
994 19.3935C28.2679 20.8856 28.9863 22.4328 30.3677 23.0959C31.4177 23.538 =
32.5228 23.4827 33.5175 22.9854C35.1199 22.2118 35.9489 20.9408 36.0594 19.=
283Z" fill=3D"#6D6D93"></path>
</g>
<defs>
<clipPath id=3D"clip0_2886_601">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/php/online-c=
ompiler/" class=3D"change-lang-btn php " title=3D"Online PHP Compiler ">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=3D"=
40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<path d=3D"M3.83821 13.8008H9.6625C11.372 13.8151 12.6107 14.308 13.3788 15=
.2786C14.1468 16.2492 14.4002 17.5748 14.1394 19.2556C14.0381 20.0236 13.81=
34 20.7769 13.4657 21.5158C13.1323 22.2547 12.669 22.921 12.0748 23.5152C11=
.3503 24.2684 10.5753 24.7465 9.74943 24.9495C8.9236 25.1525 8.06865 25.253=
8 7.185 25.2538H4.57711L3.75128 29.3829H0.730469L3.83821 13.8008ZM6.3809 16=
.2783L5.07696 22.798C5.16389 22.8124 5.25082 22.8197 5.33775 22.8197C5.4390=
3 22.8197 5.54072 22.8197 5.642 22.8197C7.03288 22.8341 8.19208 22.6967 9.1=
1919 22.4068C10.0463 22.1026 10.6696 21.0451 10.9882 19.2339C11.249 17.7126=
 10.9882 16.8359 10.2058 16.6043C9.4378 16.3726 8.4746 16.2639 7.3154 16.27=
83C7.14154 16.2926 6.97506 16.3 6.81555 16.3C6.67081 16.3 6.51868 16.3 6.35=
917 16.3L6.3809 16.2783Z" fill=3D"#25265E" fill-opacity=3D"0.67"></path>
<path d=3D"M17.5748 9.64844H20.5739L19.7263 13.7993H22.4211C23.8989 13.8284=
 24.9999 14.1327 25.7244 14.7121C26.4634 15.2915 26.6807 16.3929 26.3764 18=
.0154L24.9203 25.2523H21.8778L23.2687 18.3414C23.4134 17.6169 23.37 17.1027=
 23.1383 16.7984C22.9066 16.4942 22.4068 16.342 21.6387 16.342L19.2265 16.3=
203L17.4444 25.2523H14.4453L17.5748 9.64844Z" fill=3D"#25265E" fill-opacity=
=3D"0.67"></path>
<path d=3D"M29.5999 13.8008H35.4242C37.1337 13.8151 38.3725 14.308 39.1405 =
15.2786C39.9085 16.2492 40.1619 17.5748 39.9011 19.2556C39.7998 20.0236 39.=
5751 20.7769 39.2274 21.5158C38.894 22.2547 38.4307 22.921 37.8365 23.5152C=
37.112 24.2684 36.337 24.7465 35.5111 24.9495C34.6853 25.1525 33.8304 25.25=
38 32.9467 25.2538H30.3388L29.513 29.3829H26.4922L29.5999 13.8008ZM32.1426 =
16.2783L30.8387 22.798C30.9256 22.8124 31.0125 22.8197 31.0995 22.8197C31.2=
007 22.8197 31.3024 22.8197 31.4037 22.8197C32.7946 22.8341 33.9538 22.6967=
 34.8809 22.4068C35.808 22.1026 36.4313 21.0451 36.7499 19.2339C37.0107 17.=
7126 36.7499 16.8359 35.9675 16.6043C35.1995 16.3726 34.2363 16.2639 33.077=
1 16.2783C32.9033 16.2926 32.7368 16.3 32.5773 16.3C32.4325 16.3 32.2804 16=
.3 32.1209 16.3L32.1426 16.2783Z" fill=3D"#25265E" fill-opacity=3D"0.67"></=
path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/swift/online=
-compiler/" class=3D"change-lang-btn swift " title=3D"Online Swift Compiler=
 ">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=3D"=
40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M29.9196 33.8549C32.=
0265 33.0205 36.1973 31.7405 38.4533 35.8806C38.9712 36.8532 40.1207 31.705=
9 35.9618 26.8506L35.8873 26.7661C35.9081 26.6956 35.9286 26.6286 35.9487 2=
6.5631C35.9889 26.4317 36.0272 26.3061 36.0638 26.1702C38.159 18.6894 33.15=
65 9.75527 24.7445 5C28.3777 9.66308 30.0412 15.2949 28.5857 20.25C28.4536 =
20.7083 28.2951 21.1588 28.1109 21.5995C27.9383 21.4841 27.7225 21.361 27.4=
439 21.2149C21.1601 17.3644 15.3113 12.871 9.99608 7.81009C13.1936 12.2165 =
16.7354 16.3731 20.5896 20.2423C17.8902 18.7855 10.3022 13.638 5.53115 9.55=
93C6.1325 10.4985 6.82774 11.3767 7.60662 12.181C11.5537 16.9401 16.8504 22=
.768 23.0888 27.2504C18.7062 29.7914 12.4836 29.9798 6.257 27.2504C4.73944 =
26.619 3.30917 25.8028 2 24.8209C4.81703 28.9559 8.83711 32.1663 13.539 34.=
0355C19.5694 36.4535 25.5607 36.2113 29.9196 33.8549Z" fill=3D"#25265E" fil=
l-opacity=3D"0.67"></path>
</svg>
        </a>
        <a target=3D"_blank" href=3D"https://www.programiz.com/rust/online-=
compiler/" class=3D"change-lang-btn rust " title=3D"Online Rust Compiler">
          <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"40" height=3D"=
40" viewBox=3D"0 0 40 40" fill=3D"none" class=3D"change-lang-btn-icon svg r=
eplaced-svg">
<g clip-path=3D"url(#clip0_2886_605)">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.8839 2.84442L14.=
4084 2.68631L15.1505 0.663847C15.2559 0.46731 15.603 0.273265 15.9643 0.487=
312C16.1369 0.589616 16.7641 1.30652 17.1641 1.76388C17.2685 1.88336 17.357=
7 1.98513 17.419 2.05361H18.0516L19.129 0.167618C19.2712 -0.0427356 19.6845=
 -0.0686346 19.924 0.167618C20.0716 0.313238 20.3929 0.883897 20.6664 1.369=
34C20.8365 1.6714 20.9878 1.94045 21.0674 2.05361H21.7002L23.0602 0.523151C=
23.2474 0.335748 23.7311 0.346159 23.9339 0.741787C24.0241 0.917836 24.1409=
 1.26358 24.261 1.61915C24.4107 2.06265 24.5658 2.52141 24.6807 2.68514C24.=
8677 2.79683 25.0045 2.83134 25.2354 2.82004L26.8525 1.60471C27.0398 1.4173=
 27.596 1.5539 27.7135 1.90697C27.7613 2.05037 27.7923 2.37341 27.826 2.726=
28C27.8754 3.24222 27.931 3.82191 28.0541 3.99709C28.1741 4.11715 28.4858 4=
.32123 28.7737 4.17717C29.0617 4.03311 29.9347 3.61122 30.3351 3.41829C30.5=
515 3.36255 30.9609 3.33726 31.0997 3.70769V6.0165L31.4596 6.33811L33.3422 =
5.88792C33.4493 5.86421 33.6878 5.83122 33.7855 5.88792C33.8831 5.94446 34.=
079 6.15146 34.1646 6.24798C34.1882 6.28658 34.2134 6.46532 34.1261 6.87189=
C34.0386 7.27831 33.7984 8.13447 33.6892 8.51171L34.0233 8.9619L36.2913 8.8=
8484C36.452 8.95764 36.6884 9.30023 36.6319 9.54721C36.5883 9.7375 36.2534 =
10.4298 35.9726 11.0103C35.8889 11.1831 35.8101 11.3462 35.7453 11.4829L35.=
9958 12.036L38.0905 12.3383C38.249 12.4048 38.5492 12.6355 38.4824 13.0264L=
37.2295 14.7949C37.2038 14.9386 37.1935 15.2555 37.3579 15.3739C37.5225 15.=
4921 38.7073 15.899 39.2792 16.0876C39.4055 16.1627 39.6506 16.3732 39.6198=
 16.615C39.5888 16.8568 39.5469 16.9473 39.5297 16.9623L37.9813 18.3772V18.=
9046C38.6516 19.3032 39.9924 20.1328 39.9924 20.2615C39.9924 20.291 39.9939=
 20.3274 39.9956 20.3675C40.003 20.5459 40.0137 20.8013 39.9089 20.8853C39.=
8061 20.9677 38.581 21.687 37.9813 22.0365V22.6282C38.5252 23.1083 39.612 2=
4.0892 39.6069 24.1716C39.6053 24.1959 39.606 24.2307 39.6067 24.2719C39.60=
91 24.4049 39.6128 24.6049 39.549 24.7376C39.4822 24.8765 38.0561 25.3871 3=
7.3516 25.6251L37.2231 26.1975C37.6301 26.7419 38.4478 27.8425 38.4631 27.8=
888C38.4824 27.9467 38.5081 28.4548 38.174 28.6863L36.0537 28.9821L35.7838 =
29.4645L36.6641 31.4324C36.6983 31.5782 36.6757 31.9211 36.3106 32.1269L34.=
0167 32.0755L33.7149 32.4356L34.2032 34.6545C34.2009 34.7894 34.0656 35.082=
8 33.5413 35.1753L31.5174 34.6995L31.1126 34.9952L31.1768 37.2655C31.1211 3=
7.424 30.8915 37.7195 30.4186 37.6321L28.5232 36.7381L28.0348 36.9954L27.67=
49 39.2076C27.5893 39.3319 27.3178 39.5497 26.9167 39.4263L25.1756 38.1786C=
25.0406 38.1916 24.7567 38.2327 24.7 38.2945C24.6435 38.3562 24.094 39.7864=
 23.8263 40.4939C23.6999 40.5817 23.3816 40.7138 23.1194 40.5389L21.6223 38=
.9568H21.1148L19.8619 40.9119C19.7612 40.9784 19.4982 41.0715 19.2514 40.91=
19L17.9663 38.9568H17.433L15.8587 40.6032C15.7367 40.646 15.4475 40.6856 15=
.2677 40.5003L14.3938 38.3651C14.3402 38.2966 14.1626 38.1659 13.8798 38.19=
16L12.0614 39.4906C11.8793 39.4991 11.4909 39.4468 11.3932 39.169C11.2956 3=
8.8912 11.1427 37.6385 11.0784 37.0468L10.5515 36.7317L8.66886 37.6192C8.50=
183 37.6813 8.12144 37.7028 7.93648 37.2912V34.9888C7.92145 34.9373 7.82077=
 34.8075 7.53802 34.6995L5.48195 35.1817C5.30641 35.1883 4.94094 35.1007 4.=
8844 34.6995C4.82785 34.2981 5.17779 33.1217 5.35986 32.5836L5.07076 32.094=
8L2.7769 32.1527C2.62698 32.0605 2.33741 31.8041 2.37854 31.516C2.41966 31.=
2279 3.02536 30.0755 3.32307 29.5352L3.02108 29.0079L0.842888 28.6992C0.716=
532 28.6456 0.481784 28.4278 0.553747 27.9853L1.84522 26.1975C1.83237 26.04=
31 1.77584 25.7087 1.65246 25.6058L-0.300845 24.9434C-0.412213 24.8533 -0.6=
23394 24.5948 -0.577139 24.2809C-0.53087 23.967 0.547293 23.0612 1.08058 22=
.6475V22.0365C0.476606 21.7278 -0.768624 21.0409 -0.917697 20.7631C-1.06676=
 20.4853 -0.979805 20.2743 -0.917697 20.2036L1.11917 18.943V18.3965C0.65226=
8 18.0127 -0.335528 17.1526 -0.551416 16.7822V16.3513C-0.544992 16.3021 -0.=
460183 16.1712 -0.172317 16.0426C0.115533 15.914 1.23269 15.5517 1.75527 15=
.3866L1.87094 14.8272L0.579441 13.0457V12.602C0.624419 12.4969 0.818471 12.=
2816 1.23483 12.2611C1.6512 12.2406 2.62056 12.1067 3.0532 12.0424L3.31021 =
11.5086L2.38496 9.57289C2.34212 9.36072 2.36183 8.92466 2.78333 8.8783C3.20=
484 8.8321 4.44964 8.859 5.01935 8.8783L5.38552 8.53754L4.85229 6.36379C4.8=
4801 6.1773 4.97437 5.80812 5.51414 5.82347L7.57021 6.31881L7.97505 5.9972L=
7.87863 3.72056C7.92357 3.56192 8.12918 3.25751 8.59187 3.30896L10.5002 4.2=
4791L11.0721 3.96495L11.374 1.89411C11.4553 1.70332 11.7184 1.36547 12.1194=
 1.5404C12.5203 1.71532 13.4628 2.48263 13.8839 2.84442ZM20.7002 4.89056C20=
.7002 5.53728 20.1767 6.06134 19.5305 6.06134C18.8845 6.06134 18.3608 5.537=
28 18.3608 4.89056C18.3608 4.244 18.8845 3.71982 19.5305 3.71982C20.1767 3.=
71982 20.7002 4.244 20.7002 4.89056ZM24.5236 10.4094H8.48148C11.3531 7.2965=
5 13.1362 6.23065 16.6696 5.7262C16.6696 5.7262 18.6748 7.73337 19.0091 7.9=
0056C19.3433 8.0679 19.7703 8.10498 20.1788 7.90056C20.513 7.73337 22.3512 =
5.7262 22.3512 5.7262C27.0871 6.75866 29.3134 8.52402 32.7117 13.2527C32.37=
75 13.7546 31.6422 14.9588 31.3748 15.7616C31.1076 16.5644 31.4863 17.0997 =
31.709 17.2669L34.3827 18.605L34.5499 21.6156H32.5447C33.3802 25.2953 29.70=
38 25.4625 29.2026 22.9536C28.8835 21.3574 28.0884 20.5562 27.1972 19.7758C=
31.8762 17.2669 30.3723 11.2457 24.5236 10.4094ZM7.14457 17.2669C7.81303 16=
.8655 7.7573 16.3191 7.64599 16.0961L7.27076 15.1849C7.25269 15.1409 7.2850=
4 15.0925 7.33257 15.0925H9.81838V24.7934H5.12585C4.3237 22.6525 4.45268 19=
.7955 4.61979 18.6246C5.17688 18.3459 6.47627 17.6683 7.14457 17.2669ZM16.3=
354 15.0925V17.7686H21.6827C23.6881 17.7686 24.0223 15.2599 21.6827 15.0925=
H16.3354ZM16.3354 24.7934V22.1173H20.513C21.5157 22.1173 22.6854 23.2881 23=
.0196 26.2987C23.287 28.7073 24.5793 29.4209 25.192 29.4766H31.709L30.3723 =
30.8146C30.0938 30.7588 29.236 30.614 28.0327 30.4801C26.8296 30.3463 26.41=
75 30.982 26.3617 31.3165L26.0275 34.1597C20.6881 35.8537 17.848 35.8704 12=
.9933 33.9926C12.9376 33.4351 12.7929 32.1193 12.6591 31.3165C12.5254 30.51=
35 11.935 30.3129 11.6565 30.3129L8.64867 30.8146L7.57583 29.5876C7.53802 2=
9.5443 7.5687 29.4766 7.62625 29.4766H19.6775C19.7698 29.4766 19.8447 29.40=
17 19.8447 29.3093V24.9607C19.8447 24.8683 19.7698 24.7934 19.6775 24.7934H=
16.3354ZM34.3827 16.9324C35.0288 16.9324 35.5524 16.4082 35.5524 15.7616C35=
.5524 15.115 35.0288 14.5908 34.3827 14.5908C33.7367 14.5908 33.213 15.115 =
33.213 15.7616C33.213 16.4082 33.7367 16.9324 34.3827 16.9324ZM4.68672 16.8=
641C5.33268 16.8641 5.85641 16.3399 5.85641 15.6934C5.85641 15.0468 5.33268=
 14.5226 4.68672 14.5226C4.04068 14.5226 3.51697 15.0468 3.51697 15.6934C3.=
51697 16.3399 4.04068 16.8641 4.68672 16.8641ZM11.5203 33.1356C11.5203 33.7=
822 10.9966 34.3064 10.3506 34.3064C9.70449 34.3064 9.18091 33.7822 9.18091=
 33.1356C9.18091 32.4891 9.70449 31.9649 10.3506 31.9649C10.9966 31.9649 11=
.5203 32.4891 11.5203 33.1356ZM28.7012 34.3271C29.3471 34.3271 29.8709 33.8=
029 29.8709 33.1563C29.8709 32.5096 29.3471 31.9854 28.7012 31.9854C28.0552=
 31.9854 27.5314 32.5096 27.5314 33.1563C27.5314 33.8029 28.0552 34.3271 28=
.7012 34.3271Z" fill=3D"#25265E" fill-opacity=3D"0.67"></path>
</g>
<defs>
<clipPath id=3D"clip0_2886_605">
<rect width=3D"40" height=3D"40" fill=3D"white"></rect>
</clipPath>
</defs>
</svg>
        </a>
      </div>
      <div class=3D"editor-wrapper">
        <div class=3D"editor-desktop-top-bar">
          <div class=3D"file-name">
            main.c          </div>
          <div class=3D"desktop-top-bar__btn-wrapper">
            <button type=3D"button" id=3D"toggle-expanded-mode-desktop" tit=
le=3D"Enter Fullscreen">
              <svg xmlns=3D"http://www.w3.org/2000/svg" fill=3D"rgba(37, 38=
, 94, 0.7)" viewBox=3D"0 0 16 16" width=3D"18" height=3D"18" class=3D"toggl=
e-expanded-mode-mobile-icon expand svg replaced-svg">
  <path d=3D"M5.038 2.22a.889.889 0 000-1.778v1.777zM.445 5.033a.889.889 0 =
101.778 0H.445zm13.334 0a.889.889 0 001.777 0H13.78zM10.964.44a.889.889 0 0=
00 1.778V.441zm0 13.334a.889.889 0 000 1.778v-1.778zm4.592-2.815a.889.889 0=
 00-1.777 0h1.777zm-13.333 0a.889.889 0 00-1.778 0h1.778zm2.815 4.593a.889.=
889 0 000-1.778v1.778zm0-15.111H2.815v1.777h2.223V.442zm-2.223 0a2.37 2.37 =
0 00-2.37 2.37h1.778c0-.327.265-.593.592-.593V.442zm-2.37 2.37v2.222h1.778V=
2.812H.445zm15.111 2.222V2.812H13.78v2.222h1.777zm0-2.222a2.37 2.37 0 00-2.=
37-2.37v1.777c.327 0 .593.265.593.593h1.777zm-2.37-2.37h-2.222v1.777h2.222V=
.441zm-2.222 15.11h2.222v-1.777h-2.222v1.778zm2.222 0a2.37 2.37 0 002.37-2.=
37H13.78a.593.593 0 01-.593.593v1.778zm2.37-2.37V10.96H13.78v2.222h1.777zM.=
446 10.96v2.222h1.777V10.96H.445zm0 2.222a2.37 2.37 0 002.37 2.37v-1.777a.5=
93.593 0 01-.593-.593H.445zm2.37 2.37h2.222v-1.777H2.816v1.778z" fill=3D"wh=
ite" fill-opacity=3D"0.87"></path>
</svg>
              <svg xmlns=3D"http://www.w3.org/2000/svg" viewBox=3D"0 0 16 1=
6" width=3D"18" height=3D"18" fill=3D"rgba(37, 38, 94, 0.7)" class=3D"toggl=
e-expanded-mode-mobile-icon minimize hidden svg replaced-svg">
  <path fill=3D"#25265E" fill-opacity=3D".7" d=3D"M5.926 1.334a.889.889 0 1=
0-1.778 0h1.778zM1.333 4.15a.889.889 0 100 1.778V4.149zm13.334 1.778a.889.8=
89 0 000-1.778v1.778zm-2.815-4.593a.889.889 0 00-1.778 0h1.778zm-1.778 13.3=
34a.889.889 0 001.778 0h-1.778zm4.593-2.815a.889.889 0 000-1.778v1.778zM1.3=
34 10.075a.889.889 0 000 1.778v-1.778zm2.814 4.593a.889.889 0 001.778 0H4.1=
48zm0-13.334v2.223h1.778V1.334H4.148zm0 2.223a.593.593 0 01-.592.592v1.778a=
2.37 2.37 0 002.37-2.37H4.148zm-.592.592H1.333v1.778h2.223V4.149zm11.11 0h-=
2.221v1.778h2.222V4.149zm-2.221 0a.593.593 0 01-.593-.593h-1.778a2.37 2.37 =
0 002.37 2.37V4.15zm-.593-.593V1.334h-1.778v2.222h1.778zm0 11.112v-2.222h-1=
.778v2.222h1.778zm0-2.222c0-.328.265-.593.593-.593v-1.778a2.37 2.37 0 00-2.=
37 2.37h1.777zm.593-.593h2.222v-1.778h-2.222v1.778zm-11.111 0h2.222v-1.778H=
1.334v1.778zm2.222 0c.327 0 .592.265.592.593h1.778a2.37 2.37 0 00-2.37-2.37=
v1.777zm.592.593v2.222h1.778v-2.222H4.148z"></path>
</svg>
            </button>
            <button type=3D"button" id=3D"toggle-dark-mode-desktop" title=
=3D"Toggle dark mode">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 24 24" fill=3D"none" stroke=3D"currentColor" stroke-=
width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round" class=3D"tog=
gle-dark-mode-mobile-icon moon svg replaced-svg">
  <path d=3D"M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
</svg>
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 24 24" fill=3D"none" stroke=3D"#ffffff" stroke-width=
=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round" class=3D"toggle-d=
ark-mode-mobile-icon sun svg replaced-svg">
  <circle cx=3D"12" cy=3D"12" r=3D"5"></circle>
  <line x1=3D"12" y1=3D"1" x2=3D"12" y2=3D"3"></line>
  <line x1=3D"12" y1=3D"21" x2=3D"12" y2=3D"23"></line>
  <line x1=3D"4.22" y1=3D"4.22" x2=3D"5.64" y2=3D"5.64"></line>
  <line x1=3D"18.36" y1=3D"18.36" x2=3D"19.78" y2=3D"19.78"></line>
  <line x1=3D"1" y1=3D"12" x2=3D"3" y2=3D"12"></line>
  <line x1=3D"21" y1=3D"12" x2=3D"23" y2=3D"12"></line>
  <line x1=3D"4.22" y1=3D"19.78" x2=3D"5.64" y2=3D"18.36"></line>
  <line x1=3D"18.36" y1=3D"5.64" x2=3D"19.78" y2=3D"4.22"></line>
</svg>
            </button>
            <!-- Change first none to flex to re-enable the save button -->
            <!--  Uncomment this if require in future -->
            <!-- <button class=3D"desktop-save-button"
                            style=3D"display: block">

                            <span>
                                &nbsp;Save&nbsp;
                            </span>
                        </button> -->
            <button class=3D"share-button" title=3D"Share code">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 18 18" fill=3D"none" class=3D"toggle-expanded-mode-m=
obile-icon svg share-icon replaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 6C14.7426 6 15=
.75 4.99264 15.75 3.75C15.75 2.50736 14.7426 1.5 13.5 1.5C12.2574 1.5 11.25=
 2.50736 11.25 3.75C11.25 4.99264 12.2574 6 13.5 6Z" stroke=3D"white" strok=
e-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></pa=
th>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M4.5 11.25C5.74264 1=
1.25 6.75 10.2426 6.75 9C6.75 7.75736 5.74264 6.75 4.5 6.75C3.25736 6.75 2.=
25 7.75736 2.25 9C2.25 10.2426 3.25736 11.25 4.5 11.25Z" stroke=3D"white" s=
troke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round">=
</path>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 16.5C14.7426 1=
6.5 15.75 15.4926 15.75 14.25C15.75 13.0074 14.7426 12 13.5 12C12.2574 12 1=
1.25 13.0074 11.25 14.25C11.25 15.4926 12.2574 16.5 13.5 16.5Z" stroke=3D"w=
hite" stroke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"=
round"></path>
<path d=3D"M6.44336 10.1328L11.5659 13.1178" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M11.5584 4.88281L6.44336 7.86781" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
</svg>
              Share
            </button>
            <button class=3D"share-button tablet-share" title=3D"Share code=
">
              <svg xmlns=3D"http://www.w3.org/2000/svg" width=3D"18" height=
=3D"18" viewBox=3D"0 0 18 18" fill=3D"none" class=3D"toggle-expanded-mode-m=
obile-icon svg share-icon replaced-svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 6C14.7426 6 15=
.75 4.99264 15.75 3.75C15.75 2.50736 14.7426 1.5 13.5 1.5C12.2574 1.5 11.25=
 2.50736 11.25 3.75C11.25 4.99264 12.2574 6 13.5 6Z" stroke=3D"white" strok=
e-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></pa=
th>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M4.5 11.25C5.74264 1=
1.25 6.75 10.2426 6.75 9C6.75 7.75736 5.74264 6.75 4.5 6.75C3.25736 6.75 2.=
25 7.75736 2.25 9C2.25 10.2426 3.25736 11.25 4.5 11.25Z" stroke=3D"white" s=
troke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round">=
</path>
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M13.5 16.5C14.7426 1=
6.5 15.75 15.4926 15.75 14.25C15.75 13.0074 14.7426 12 13.5 12C12.2574 12 1=
1.25 13.0074 11.25 14.25C11.25 15.4926 12.2574 16.5 13.5 16.5Z" stroke=3D"w=
hite" stroke-width=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"=
round"></path>
<path d=3D"M6.44336 10.1328L11.5659 13.1178" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
<path d=3D"M11.5584 4.88281L6.44336 7.86781" stroke=3D"white" stroke-width=
=3D"1.77778" stroke-linecap=3D"round" stroke-linejoin=3D"round"></path>
</svg>
            </button>
            <button class=3D"desktop-run-button run" style=3D"cursor: point=
er;">
              <span class=3D"run-text">
                                &nbsp;Run&nbsp;
                              </span>




























































            </button>
          </div>
        </div>
        <button class=3D"mobile-run-button run">
          Run
        </button>
        <div id=3D"editor" class=3D" ace_editor ace-tm" style=3D"font-famil=
y: droid_sans_monoregular; font-size: 14px; line-height: 22px; height: 533.=
2px;"><textarea class=3D"ace_text-input" wrap=3D"off" autocorrect=3D"off" a=
utocapitalize=3D"off" spellcheck=3D"false" style=3D"opacity: 0; font-size: =
1px; height: 1px; width: 1px; top: 468px; left: 381px;"></textarea><div cla=
ss=3D"ace_gutter" aria-hidden=3D"true" style=3D"left: 0px; width: 50px;"><d=
iv class=3D"ace_layer ace_gutter-layer ace_folding-enabled" style=3D"height=
: 1e+06px; top: -60px; left: 0px; width: 50px;"><div class=3D"ace_gutter-ce=
ll " style=3D"height: 22px; top: 44px;">3<span style=3D"display: inline-blo=
ck; height: 22px;" class=3D"ace_fold-widget ace_start ace_open"></span></di=
v><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 66px;">4<span=
 style=3D"display: none; height: 22px;" class=3D"ace_fold-widget ace_start =
ace_open"></span></div><div class=3D"ace_gutter-cell " style=3D"height: 22p=
x; top: 88px;">5<span class=3D"ace_fold-widget ace_start ace_open" style=3D=
"display: none; height: 22px;"></span></div><div class=3D"ace_gutter-cell "=
 style=3D"height: 22px; top: 110px;">6<span style=3D"display: none; height:=
 22px;" class=3D"ace_fold-widget ace_start ace_open"></span></div><div clas=
s=3D"ace_gutter-cell " style=3D"height: 22px; top: 132px;">7<span style=3D"=
display: none; height: 22px;" class=3D"ace_fold-widget ace_start ace_open">=
</span></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 15=
4px;">8<span style=3D"display: none; height: 22px;" class=3D"ace_fold-widge=
t ace_start ace_open"></span></div><div class=3D"ace_gutter-cell " style=3D=
"height: 22px; top: 176px;">9<span style=3D"display: none; height: 22px;" c=
lass=3D"ace_fold-widget ace_start ace_open"></span></div><div class=3D"ace_=
gutter-cell " style=3D"height: 22px; top: 198px;">10<span style=3D"display:=
 inline-block; height: 22px;" class=3D"ace_fold-widget ace_start ace_open">=
</span></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 22=
0px;">11<span style=3D"display: none; height: 22px;" class=3D"ace_fold-widg=
et ace_start ace_open"></span></div><div class=3D"ace_gutter-cell " style=
=3D"height: 22px; top: 242px;">12<span style=3D"display: none; height: 22px=
;" class=3D"ace_fold-widget ace_start ace_open"></span></div><div class=3D"=
ace_gutter-cell " style=3D"height: 22px; top: 264px;">13<span style=3D"disp=
lay: none; height: 22px;" class=3D"ace_fold-widget ace_start ace_open"></sp=
an></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 286px;=
">14<span style=3D"display: none; height: 22px;" class=3D"ace_fold-widget a=
ce_start ace_open"></span></div><div class=3D"ace_gutter-cell " style=3D"he=
ight: 22px; top: 308px;">15<span style=3D"display: none; height: 22px;" cla=
ss=3D"ace_fold-widget ace_start ace_open"></span></div><div class=3D"ace_gu=
tter-cell " style=3D"height: 22px; top: 330px;">16<span style=3D"display: n=
one; height: 22px;" class=3D"ace_fold-widget ace_start ace_open"></span></d=
iv><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 352px;">17<s=
pan style=3D"display: none; height: 22px;" class=3D"ace_fold-widget ace_sta=
rt ace_open"></span></div><div class=3D"ace_gutter-cell " style=3D"height: =
22px; top: 374px;">18<span style=3D"display: inline-block; height: 22px;" c=
lass=3D"ace_fold-widget ace_start ace_open"></span></div><div class=3D"ace_=
gutter-cell " style=3D"height: 22px; top: 396px;">19<span style=3D"display:=
 inline-block; height: 22px;" class=3D"ace_fold-widget ace_start ace_open">=
</span></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 41=
8px;">20<span style=3D"display: none;"></span></div><div class=3D"ace_gutte=
r-cell " style=3D"height: 22px; top: 440px;">21<span style=3D"display: none=
;"></span></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top:=
 462px;">22<span style=3D"display: none;"></span></div><div class=3D"ace_gu=
tter-cell " style=3D"height: 22px; top: 484px;">23<span style=3D"display: n=
one;"></span></div><div class=3D"ace_gutter-cell ace_gutter-active-line " s=
tyle=3D"height: 22px; top: 506px;">24<span style=3D"display: none;"></span>=
</div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 528px;">2=
5<span style=3D"display: none;"></span></div><div class=3D"ace_gutter-cell =
" style=3D"height: 22px; top: 550px;">26<span style=3D"display: none;"></sp=
an></div><div class=3D"ace_gutter-cell " style=3D"height: 22px; top: 572px;=
">27<span style=3D"display: none; height: 22px;" class=3D"ace_fold-widget a=
ce_start ace_open"></span></div><div class=3D"ace_gutter-cell " style=3D"he=
ight: 22px; top: 594px;">28<span style=3D"display: none; height: 22px;" cla=
ss=3D"ace_fold-widget ace_start ace_open"></span></div></div></div><div cla=
ss=3D"ace_scroller" style=3D"line-height: 22px; left: 49.8047px; right: 17p=
x; bottom: 0px;"><div class=3D"ace_content" style=3D"top: -16px; left: 0px;=
 width: 672.195px; height: 577.2px;"><div class=3D"ace_layer ace_print-marg=
in-layer"><div class=3D"ace_print-margin" style=3D"left: 676px; visibility:=
 hidden;"></div></div><div class=3D"ace_layer ace_marker-layer"><div class=
=3D"ace_active-line" style=3D"height: 22px; top: 462px; left: 0px; right: 0=
px;"></div></div><div class=3D"ace_layer ace_text-layer" style=3D"height: 1=
e+06px; margin: 0px 4px; top: -44px; left: 0px;"><div class=3D"ace_line_gro=
up" style=3D"height: 22px; top: 44px;"><div class=3D"ace_line" style=3D"hei=
ght: 22px;"><span class=3D"ace_storage ace_type">int</span> <span class=3D"=
ace_identifier">main</span><span class=3D"ace_paren ace_lparen">(</span><sp=
an class=3D"ace_paren ace_rparen">)</span> <span class=3D"ace_paren ace_lpa=
ren">{</span></div></div><div class=3D"ace_line_group" style=3D"height: 22p=
x; top: 66px;"><div class=3D"ace_line" style=3D"height: 22px;">    <span cl=
ass=3D"ace_storage ace_type">int</span> <span class=3D"ace_identifier">max<=
/span><span class=3D"ace_punctuation ace_operator">,</span> <span class=3D"=
ace_identifier">maxi</span><span class=3D"ace_punctuation ace_operator">;</=
span></div></div><div class=3D"ace_line_group" style=3D"height: 22px; top: =
88px;"><div class=3D"ace_line" style=3D"height: 22px;">    <span class=3D"a=
ce_storage ace_type">int</span> <span class=3D"ace_identifier">arr</span><s=
pan class=3D"ace_paren ace_lparen">[</span><span class=3D"ace_paren ace_rpa=
ren">]</span> <span class=3D"ace_keyword ace_operator">=3D</span> <span cla=
ss=3D"ace_paren ace_lparen">{</span><span class=3D"ace_constant ace_numeric=
">44</span><span class=3D"ace_punctuation ace_operator">,</span> <span clas=
s=3D"ace_constant ace_numeric">56</span><span class=3D"ace_punctuation ace_=
operator">,</span> <span class=3D"ace_constant ace_numeric">78</span><span =
class=3D"ace_punctuation ace_operator">,</span> <span class=3D"ace_constant=
 ace_numeric">12</span><span class=3D"ace_punctuation ace_operator">,</span=
> <span class=3D"ace_constant ace_numeric">45</span><span class=3D"ace_pare=
n ace_rparen">}</span><span class=3D"ace_punctuation ace_operator">;</span>=
</div></div><div class=3D"ace_line_group" style=3D"height: 22px; top: 110px=
;"><div class=3D"ace_line" style=3D"height: 22px;">    <span class=3D"ace_s=
torage ace_type">char</span> <span class=3D"ace_keyword ace_operator">*</sp=
an><span class=3D"ace_identifier">a</span><span class=3D"ace_paren ace_lpar=
en">[</span><span class=3D"ace_paren ace_rparen">]</span> <span class=3D"ac=
e_keyword ace_operator">=3D</span> <span class=3D"ace_paren ace_lparen">{</=
span><span class=3D"ace_string ace_start">"</span><span class=3D"ace_string=
">manan1</span><span class=3D"ace_string ace_end">"</span><span class=3D"ac=
e_punctuation ace_operator">,</span> <span class=3D"ace_string ace_start">"=
</span><span class=3D"ace_string">manan2</span><span class=3D"ace_string ac=
e_end">"</span><span class=3D"ace_punctuation ace_operator">,</span><span c=
lass=3D"ace_string ace_start">"</span><span class=3D"ace_string">manan3</sp=
an><span class=3D"ace_string ace_end">"</span><span class=3D"ace_punctuatio=
n ace_operator">,</span><span class=3D"ace_string ace_start">"</span><span =
class=3D"ace_string">manan4</span><span class=3D"ace_string ace_end">"</spa=
n><span class=3D"ace_punctuation ace_operator">,</span><span class=3D"ace_s=
tring ace_start">"</span><span class=3D"ace_string">manan5</span><span clas=
s=3D"ace_string ace_end">"</span><span class=3D"ace_paren ace_rparen">}</sp=
an><span class=3D"ace_punctuation ace_operator">;</span></div></div><div cl=
ass=3D"ace_line_group" style=3D"height: 22px; top: 132px;"><div class=3D"ac=
e_line" style=3D"height: 22px;">    <span class=3D"ace_storage ace_type">in=
t</span> <span class=3D"ace_identifier">length</span> <span class=3D"ace_ke=
yword ace_operator">=3D</span> <span class=3D"ace_constant ace_numeric">4</=
span><span class=3D"ace_punctuation ace_operator">;</span></div></div><div =
class=3D"ace_line_group" style=3D"height: 22px; top: 154px;"><div class=3D"=
ace_line" style=3D"height: 22px;">   </div></div><div class=3D"ace_line_gro=
up" style=3D"height: 22px; top: 176px;"><div class=3D"ace_line" style=3D"he=
ight: 22px;">    </div></div><div class=3D"ace_line_group" style=3D"height:=
 22px; top: 198px;"><div class=3D"ace_line" style=3D"height: 22px;">    <sp=
an class=3D"ace_keyword ace_control">if</span> <span class=3D"ace_paren ace=
_lparen">(</span><span class=3D"ace_identifier">length</span> <span class=
=3D"ace_keyword ace_operator">=3D=3D</span> <span class=3D"ace_constant ace=
_numeric">0</span><span class=3D"ace_paren ace_rparen">)</span> <span class=
=3D"ace_paren ace_lparen">{</span></div></div><div class=3D"ace_line_group"=
 style=3D"height: 22px; top: 220px;"><div class=3D"ace_line" style=3D"heigh=
t: 22px;"><span class=3D"ace_indent-guide">    </span>    <span class=3D"ac=
e_support ace_function ace_C99 ace_c">printf</span><span class=3D"ace_paren=
 ace_lparen">(</span><span class=3D"ace_string ace_start">"</span><span cla=
ss=3D"ace_string">Array is empty.</span><span class=3D"ace_constant ace_lan=
guage ace_escape">\n</span><span class=3D"ace_string ace_end">"</span><span=
 class=3D"ace_paren ace_rparen">)</span><span class=3D"ace_punctuation ace_=
operator">;</span></div></div><div class=3D"ace_line_group" style=3D"height=
: 22px; top: 242px;"><div class=3D"ace_line" style=3D"height: 22px;"><span =
class=3D"ace_indent-guide">    </span>    <span class=3D"ace_keyword ace_co=
ntrol">return</span> <span class=3D"ace_constant ace_numeric">1</span><span=
 class=3D"ace_punctuation ace_operator">;</span></div></div><div class=3D"a=
ce_line_group" style=3D"height: 22px; top: 264px;"><div class=3D"ace_line" =
style=3D"height: 22px;">    <span class=3D"ace_paren ace_rparen">}</span></=
div></div><div class=3D"ace_line_group" style=3D"height: 22px; top: 286px;"=
><div class=3D"ace_line" style=3D"height: 22px;"></div></div><div class=3D"=
ace_line_group" style=3D"height: 22px; top: 308px;"><div class=3D"ace_line"=
 style=3D"height: 22px;">    <span class=3D"ace_identifier">max</span> <spa=
n class=3D"ace_keyword ace_operator">=3D</span> <span class=3D"ace_identifi=
er">arr</span><span class=3D"ace_paren ace_lparen">[</span><span class=3D"a=
ce_constant ace_numeric">0</span><span class=3D"ace_paren ace_rparen">]</sp=
an><span class=3D"ace_punctuation ace_operator">;</span></div></div><div cl=
ass=3D"ace_line_group" style=3D"height: 22px; top: 330px;"><div class=3D"ac=
e_line" style=3D"height: 22px;">    <span class=3D"ace_identifier">maxi</sp=
an> <span class=3D"ace_keyword ace_operator">=3D</span> <span class=3D"ace_=
constant ace_numeric">0</span><span class=3D"ace_punctuation ace_operator">=
;</span></div></div><div class=3D"ace_line_group" style=3D"height: 22px; to=
p: 352px;"><div class=3D"ace_line" style=3D"height: 22px;"></div></div><div=
 class=3D"ace_line_group" style=3D"height: 22px; top: 374px;"><div class=3D=
"ace_line" style=3D"height: 22px;">    <span class=3D"ace_keyword ace_contr=
ol">for</span> <span class=3D"ace_paren ace_lparen">(</span><span class=3D"=
ace_storage ace_type">int</span> <span class=3D"ace_identifier">i</span> <s=
pan class=3D"ace_keyword ace_operator">=3D</span> <span class=3D"ace_consta=
nt ace_numeric">1</span><span class=3D"ace_punctuation ace_operator">;</spa=
n> <span class=3D"ace_identifier">i</span> <span class=3D"ace_keyword ace_o=
perator">&lt;</span> <span class=3D"ace_identifier">length</span> <span cla=
ss=3D"ace_punctuation ace_operator">;</span> <span class=3D"ace_identifier"=
>i</span><span class=3D"ace_keyword ace_operator">++</span><span class=3D"a=
ce_paren ace_rparen">)</span> <span class=3D"ace_paren ace_lparen">{</span>=
</div></div><div class=3D"ace_line_group" style=3D"height: 22px; top: 396px=
;"><div class=3D"ace_line" style=3D"height: 22px;"><span class=3D"ace_inden=
t-guide">    </span>    <span class=3D"ace_keyword ace_control">if</span> <=
span class=3D"ace_paren ace_lparen">(</span><span class=3D"ace_identifier">=
arr</span><span class=3D"ace_paren ace_lparen">[</span><span class=3D"ace_i=
dentifier">i</span><span class=3D"ace_paren ace_rparen">]</span> <span clas=
s=3D"ace_keyword ace_operator">&gt;</span> <span class=3D"ace_identifier">m=
ax</span><span class=3D"ace_paren ace_rparen">)</span> <span class=3D"ace_p=
aren ace_lparen">{</span></div></div><div class=3D"ace_line_group" style=3D=
"height: 22px; top: 418px;"><div class=3D"ace_line" style=3D"height: 22px;"=
><span class=3D"ace_indent-guide">    </span><span class=3D"ace_indent-guid=
e">    </span>    <span class=3D"ace_identifier">max</span> <span class=3D"=
ace_keyword ace_operator">=3D</span> <span class=3D"ace_identifier">arr</sp=
an><span class=3D"ace_paren ace_lparen">[</span><span class=3D"ace_identifi=
er">i</span><span class=3D"ace_paren ace_rparen">]</span><span class=3D"ace=
_punctuation ace_operator">;</span></div></div><div class=3D"ace_line_group=
" style=3D"height: 22px; top: 440px;"><div class=3D"ace_line" style=3D"heig=
ht: 22px;"><span class=3D"ace_indent-guide">    </span><span class=3D"ace_i=
ndent-guide">    </span>    <span class=3D"ace_identifier">maxi</span> <spa=
n class=3D"ace_keyword ace_operator">=3D</span> <span class=3D"ace_identifi=
er">i</span><span class=3D"ace_punctuation ace_operator">;</span></div></di=
v><div class=3D"ace_line_group" style=3D"height: 22px; top: 462px;"><div cl=
ass=3D"ace_line" style=3D"height: 22px;"><span class=3D"ace_indent-guide"> =
   </span>    <span class=3D"ace_paren ace_rparen">}</span></div></div><div=
 class=3D"ace_line_group" style=3D"height: 22px; top: 484px;"><div class=3D=
"ace_line" style=3D"height: 22px;">    <span class=3D"ace_paren ace_rparen"=
>}</span></div></div><div class=3D"ace_line_group" style=3D"height: 22px; t=
op: 506px;"><div class=3D"ace_line" style=3D"height: 22px;">    <span class=
=3D"ace_support ace_function ace_C99 ace_c">printf</span><span class=3D"ace=
_paren ace_lparen">(</span><span class=3D"ace_string ace_start">"</span><sp=
an class=3D"ace_string">Maximum value: </span><span class=3D"ace_constant a=
ce_language ace_escape">%d\n</span><span class=3D"ace_string ace_end">"</sp=
an><span class=3D"ace_punctuation ace_operator">,</span> <span class=3D"ace=
_identifier">max</span><span class=3D"ace_paren ace_rparen">)</span><span c=
lass=3D"ace_punctuation ace_operator">;</span></div></div><div class=3D"ace=
_line_group" style=3D"height: 22px; top: 528px;"><div class=3D"ace_line" st=
yle=3D"height: 22px;">    <span class=3D"ace_support ace_function ace_C99 a=
ce_c">printf</span><span class=3D"ace_paren ace_lparen">(</span><span class=
=3D"ace_string ace_start">"</span><span class=3D"ace_constant ace_language =
ace_escape">%s\n</span><span class=3D"ace_string ace_end">"</span><span cla=
ss=3D"ace_punctuation ace_operator">,</span> <span class=3D"ace_identifier"=
>a</span><span class=3D"ace_paren ace_lparen">[</span><span class=3D"ace_id=
entifier">maxi</span><span class=3D"ace_paren ace_rparen">])</span><span cl=
ass=3D"ace_punctuation ace_operator">;</span></div></div><div class=3D"ace_=
line_group" style=3D"height: 22px; top: 550px;"><div class=3D"ace_line" sty=
le=3D"height: 22px;">    <span class=3D"ace_keyword ace_control">return</sp=
an> <span class=3D"ace_constant ace_numeric">0</span><span class=3D"ace_pun=
ctuation ace_operator">;</span></div></div><div class=3D"ace_line_group" st=
yle=3D"height: 22px; top: 572px;"><div class=3D"ace_line" style=3D"height: =
22px;"><span class=3D"ace_paren ace_rparen">}</span></div></div><div class=
=3D"ace_line_group" style=3D"height: 22px; top: 594px;"><div class=3D"ace_l=
ine" style=3D"height: 22px;"></div></div></div><div class=3D"ace_layer ace_=
marker-layer"></div><div class=3D"ace_layer ace_cursor-layer ace_hidden-cur=
sors"><div class=3D"ace_cursor" style=3D"display: block; top: 462px; left: =
332px; width: 8px; height: 22px; animation-duration: 1000ms;"></div></div><=
/div></div><div class=3D"ace_scrollbar ace_scrollbar-v" style=3D"width: 22p=
x; bottom: 0px;"><div class=3D"ace_scrollbar-inner" style=3D"width: 22px; h=
eight: 616px;">&nbsp;</div></div><div class=3D"ace_scrollbar ace_scrollbar-=
h" style=3D"display: none; height: 22px; left: 49.8047px; right: 17px;"><di=
v class=3D"ace_scrollbar-inner" style=3D"height: 22px; width: 689px;">&nbsp=
;</div></div><div style=3D"height: auto; width: auto; top: 0px; left: 0px; =
visibility: hidden; position: absolute; white-space: pre; font: inherit; ov=
erflow: hidden;"><div style=3D"height: auto; width: auto; top: 0px; left: 0=
px; visibility: hidden; position: absolute; white-space: pre; font: inherit=
; overflow: visible;">=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94</div><div styl=
e=3D"height: auto; width: auto; top: 0px; left: 0px; visibility: hidden; po=
sition: absolute; white-space: pre; font-style: inherit; font-variant: inhe=
rit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-=
family: inherit; font-optical-sizing: inherit; font-size-adjust: inherit; f=
ont-kerning: inherit; font-feature-settings: inherit; font-variation-settin=
gs: inherit; overflow: visible;">XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX</div></div=
></div>
      </div>

      <div class=3D"terminal-wrapper">
        <div class=3D"terminal-desktop-top-bar">
          <div class=3D"shell-name">
            Output          </div>
          <div class=3D"terminal-desktop-top-bar__btn-wrapper">
            <button class=3D"desktop-clear-button">
              &nbsp;Clear&nbsp;
            </button>
          </div>
        </div>
        <div id=3D"terminal" class=3D" ace_editor ace-tm ace_focus" style=
=3D"font-family: droid_sans_monoregular; font-size: 14px; line-height: 22px=
; height: 132px;"><textarea class=3D"ace_text-input" wrap=3D"off" autocorre=
ct=3D"off" autocapitalize=3D"off" spellcheck=3D"false" style=3D"opacity: 0;=
 font-size: 1px; height: 1px; width: 1px; top: 131px; left: 281px;"></texta=
rea><div class=3D"ace_gutter" aria-hidden=3D"true" style=3D"display: none; =
left: 0px; width: 42px;"><div class=3D"ace_layer ace_gutter-layer ace_foldi=
ng-enabled" style=3D"height: 1e+06px; top: 0px; left: 0px; width: 42px;"><d=
iv class=3D"ace_gutter-cell " style=3D"height: 22px; top: 0px;">1<span styl=
e=3D"display: none;"></span></div><div class=3D"ace_gutter-cell " style=3D"=
height: 22px; top: 22px;">2<span style=3D"display: none;"></span></div><div=
 class=3D"ace_gutter-cell " style=3D"height: 22px; top: 44px;">3<span style=
=3D"display: none;"></span></div><div class=3D"ace_gutter-cell " style=3D"h=
eight: 22px; top: 66px;">4<span style=3D"display: none;"></span></div><div =
class=3D"ace_gutter-cell " style=3D"height: 22px; top: 88px;">5<span style=
=3D"display: none;"></span></div><div class=3D"ace_gutter-cell ace_gutter-a=
ctive-line " style=3D"height: 22px; top: 110px;">6<span style=3D"display: n=
one;"></span></div></div></div><div class=3D"ace_scroller" style=3D"line-he=
ight: 22px; left: 0px; right: 0px; bottom: 0px;"><div class=3D"ace_content"=
 style=3D"top: 0px; left: 0px; width: 739px; height: 176px;"><div class=3D"=
ace_layer ace_print-margin-layer"><div class=3D"ace_print-margin" style=3D"=
left: 676px; visibility: hidden;"></div></div><div class=3D"ace_layer ace_m=
arker-layer"></div><div class=3D"ace_layer ace_text-layer" style=3D"height:=
 1e+06px; margin: 0px 4px; top: 0px; left: 0px;"><div class=3D"ace_line_gro=
up" style=3D"height: 22px; top: 0px;"><div class=3D"ace_line" style=3D"heig=
ht: 22px;"><span class=3D"ace_comment ace_line ace_colons ace_dosbatch">/tm=
p/fAEOxu91Lz.o</span></div></div><div class=3D"ace_line_group" style=3D"hei=
ght: 22px; top: 22px;"><div class=3D"ace_line" style=3D"height: 22px;">Maxi=
mum value: 78</div></div><div class=3D"ace_line_group" style=3D"height: 22p=
x; top: 44px;"><div class=3D"ace_line" style=3D"height: 22px;">manan3</div>=
</div><div class=3D"ace_line_group" style=3D"height: 22px; top: 66px;"><div=
 class=3D"ace_line" style=3D"height: 22px;"></div></div><div class=3D"ace_l=
ine_group" style=3D"height: 22px; top: 88px;"><div class=3D"ace_line" style=
=3D"height: 22px;"></div></div><div class=3D"ace_line_group" style=3D"heigh=
t: 22px; top: 110px;"><div class=3D"ace_line" style=3D"height: 22px;">=3D=
=3D=3D Code Execution Successful =3D=3D=3D</div></div></div><div class=3D"a=
ce_layer ace_marker-layer"></div><div class=3D"ace_layer ace_cursor-layer a=
ce_slim-cursors ace_animate-blinking"><div class=3D"ace_cursor" style=3D"di=
splay: block; top: 110px; left: 281px; width: 8px; height: 22px; animation-=
duration: 1000ms;"></div></div></div></div><div class=3D"ace_scrollbar ace_=
scrollbar-v" style=3D"width: 22px; bottom: 0px; display: none;"><div class=
=3D"ace_scrollbar-inner" style=3D"width: 22px; height: 132px;">&nbsp;</div>=
</div><div class=3D"ace_scrollbar ace_scrollbar-h" style=3D"display: none; =
height: 22px; left: 0px; right: 0px;"><div class=3D"ace_scrollbar-inner" st=
yle=3D"height: 22px; width: 722px;">&nbsp;</div></div><div style=3D"height:=
 auto; width: auto; top: 0px; left: 0px; visibility: hidden; position: abso=
lute; white-space: pre; font: inherit; overflow: hidden;"><div style=3D"hei=
ght: auto; width: auto; top: 0px; left: 0px; visibility: hidden; position: =
absolute; white-space: pre; font: inherit; overflow: visible;">=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=
=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=D7=94=
=D7=94=D7=94=D7=94=D7=94</div><div style=3D"height: auto; width: auto; top:=
 0px; left: 0px; visibility: hidden; position: absolute; white-space: pre; =
font-style: inherit; font-variant: inherit; font-stretch: inherit; font-siz=
e: inherit; line-height: inherit; font-family: inherit; font-optical-sizing=
: inherit; font-size-adjust: inherit; font-kerning: inherit; font-feature-s=
ettings: inherit; font-variation-settings: inherit; overflow: visible;">XXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=
XXXXXXXXXXXXXXXXXXXXXXXXXXXX</div></div></div>
      </div>
    </div>
  </div>

 =20
  <!-- The use of the cloudflare cdn for all external libraries is intentia=
l. We are trying to reduce the number
         of DNS lookups.
    -->
 =20
 =20

 =20
 =20
 =20

  <!-- Google Tag Manager (noscript) -->
 =20
  <!-- End Google Tag Manager (noscript) -->


<iframe name=3D"__tcfapiLocator" style=3D"display: none;"></iframe><iframe =
name=3D"__uspapiLocator" style=3D"display: none;"></iframe><iframe name=3D"=
__gppLocator" style=3D"display: none;"></iframe><img src=3D"https://ad.doub=
leclick.net/favicon.ico?ad=3D300x250&amp;ad_box_=3D1&amp;adnet=3D1&amp;show=
ad=3D1&amp;size=3D250x250" style=3D"display: none !important; width: 1px !i=
mportant; height: 1px !important;"><img src=3D"https://ad-delivery.net/px.g=
if?ch=3D2" style=3D"display: none !important; width: 1px !important; height=
: 1px !important;"><img src=3D"https://ad.doubleclick.net/favicon.ico?ad=3D=
300x250&amp;ad_box_=3D1&amp;adnet=3D1&amp;showad=3D1&amp;size=3D250x250" st=
yle=3D"display: none !important; width: 1px !important; height: 1px !import=
ant;"><img src=3D"https://ad-delivery.net/px.gif?ch=3D1&amp;e=3D0.659678270=
8559272" style=3D"display: none !important; width: 1px !important; height: =
1px !important;"><img width=3D"1" height=3D"1" src=3D"https://map.go.affec.=
tv/map/af/?gdpr=3D0&amp;gdpr_consent=3D" style=3D"display: none;"><iframe s=
rc=3D"cid:frame-1423F97FE772962D01A36045687ED1E7@mhtml.blink" style=3D"disp=
lay: none;"></iframe><div><iframe src=3D"cid:frame-F1FEE684B178B81817B4219D=
51A810FB@mhtml.blink" width=3D"0" height=3D"0" style=3D"display:none;"></if=
rame></div><img height=3D"1" width=3D"1" src=3D"https://ids.ad.gt/api/v1/ha=
lo_match?id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX&amp;halo_id=3D060ixdlj2g=
5ihhf7hh6hej6l96f97gdclcfuok0wsqyusso2ss0smw0060o62qki0" alt=3D"" style=3D"=
display: none;"><img height=3D"1" width=3D"1" src=3D"https://ids.ad.gt/api/=
v1/ip_match?id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX" alt=3D"" style=3D"di=
splay: none;"><img height=3D"1" width=3D"1" src=3D"https://secure.adnxs.com=
/getuid?https://ids.ad.gt/api/v1/match?id=3DAU1D-0100-001723735934-NMFNT6K9=
-3UFX&amp;adnxs_id=3D$UID&amp;gdpr=3D0" alt=3D"" style=3D"display: none;"><=
img height=3D"1" width=3D"1" src=3D"https://match.adsrvr.org/track/cmf/gene=
ric?ttd_pid=3D8gkxb6n&amp;ttd_tpi=3D1&amp;ttd_puid=3DAU1D-0100-001723735934=
-NMFNT6K9-3UFX&amp;gdpr=3D0" alt=3D"" style=3D"display: none;"><img height=
=3D"1" width=3D"1" src=3D"https://image2.pubmatic.com/AdServer/UCookieSetPu=
g?rd=3Dhttps%3A%2F%2Fids.ad.gt%2Fapi%2Fv1%2Fpbm_match%3Fpbm%3D%23PM_USER_ID=
%26id%3DAU1D-0100-001723735934-NMFNT6K9-3UFX" alt=3D"" style=3D"display: no=
ne;"><img height=3D"1" width=3D"1" src=3D"https://token.rubiconproject.com/=
token?pid=3D50242&amp;puid=3DAU1D-0100-001723735934-NMFNT6K9-3UFX&amp;gdpr=
=3D0" alt=3D"" style=3D"display: none;"><img height=3D"1" width=3D"1" src=
=3D"https://pixel.tapad.com/idsync/ex/receive?partner_id=3D3185&amp;partner=
_device_id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX&amp;partner_url=3Dhttps:/=
/ids.ad.gt%2Fapi%2Fv1%2Ftapad_match%3Fid%3DAU1D-0100-001723735934-NMFNT6K9-=
3UFX%26tapad_id%3D%24%7BTA_DEVICE_ID%7D" alt=3D"" style=3D"display: none;">=
<img height=3D"1" width=3D"1" src=3D"https://cm.g.doubleclick.net/pixel?goo=
gle_nid=3Daudigent_w_appnexus_3985&amp;google_cm&amp;google_sc&amp;google_u=
la=3D450542624&amp;id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX" alt=3D"" styl=
e=3D"display: none;"><img height=3D"1" width=3D"1" src=3D"https://ids.ad.gt=
/api/v1/g_hosted?id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX" alt=3D"" style=
=3D"display: none;"><img height=3D"1" width=3D"1" src=3D"https://sync.1rx.i=
o/usersync/audigent/0?dspret=3D1&amp;redir=3Dhttps%3A%2F%2Fids.ad.gt%2Fapi%=
2Fv1%2Funruly%3Fid%3DAU1D-0100-001723735934-NMFNT6K9-3UFX%26unruly_id%3D%5B=
RX_UUID%5D" alt=3D"" style=3D"display: none;"><img height=3D"1" width=3D"1"=
 src=3D"https://sync.smartadserver.com/getuid?url=3Dhttps%3A%2F%2Fids.ad.gt=
%2Fapi%2Fv1%2Fsmart_match%3Fid%3DAU1D-0100-001723735934-NMFNT6K9-3UFX%26sas=
_uid%3D%5bsas_uid%5d&amp;gdpr=3D0" alt=3D"" style=3D"display: none;"><img h=
eight=3D"1" width=3D"1" src=3D"https://bh.contextweb.com/bh/rtset?pid=3D562=
316&amp;ev=3D1&amp;rurl=3Dhttps://ids.ad.gt/api/v1/ppnt_match?uid=3D%%VGUID=
%%&amp;id=3DAU1D-0100-001723735934-NMFNT6K9-3UFX" alt=3D"" style=3D"display=
: none;"><iframe name=3D"google_ads_top_frame" id=3D"google_ads_top_frame" =
style=3D"display: none; position: fixed; left: -999px; top: -999px; width: =
0px; height: 0px;"></iframe><iframe src=3D"cid:frame-1827F13A7196CBF45504DF=
6212DCF96D@mhtml.blink" width=3D"0" height=3D"0" style=3D"display: none;"><=
/iframe><iframe src=3D"cid:frame-7BE298A433BBB81A21C07AA093855348@mhtml.bli=
nk" allow=3D"join-ad-interest-group; attribution-reporting" style=3D"displa=
y: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; displ=
ay:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?su=
b=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetu=
id%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UU=
ID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; hei=
ght:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439=
a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2=
Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_priv=
acy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-7707D9B67579AE0DF229B3885D02B8A6@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" mar=
ginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D=
"cid:frame-FEC3155B3327F31688570803CFCBB50E@mhtml.blink" style=3D"border: 0=
px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absol=
ute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2=
/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex=
.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%=
3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display=
:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f=
6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu=
.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D=
%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" ma=
rginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-9A555A3B66228A4F4AE527D1766F596A@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" widt=
h=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-BAD047985285C027D7D03E91260EB733@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"p=
osition:absolute; display:none; height:0; width:0;" src=3D"https://sync.1rx=
.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3=
A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%=
3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:abso=
lute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm=
?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dht=
tps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%=
7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" w=
idth=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborde=
r=3D"0" src=3D"cid:frame-9245089902055A37884624D460C9EFC7@mhtml.blink" styl=
e=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=
=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" fr=
ameborder=3D"0" src=3D"cid:frame-646822F8F73B28EF2B76EEA2DD6DD6A4@mhtml.bli=
nk" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" s=
tyle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https:/=
/sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=
=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26u=
s_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"pos=
ition:absolute; display:none; height:0; width:0;" src=3D"https://u.openx.ne=
t/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&=
amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt=
%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" heig=
ht=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" =
frameborder=3D"0" src=3D"cid:frame-992DBF9498E565D3EE9FB89234E96F63@mhtml.b=
link" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sy=
nc" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=
=3D"no" frameborder=3D"0" src=3D"cid:frame-29D06BD1E0CD6D8B93D2465339CD101C=
@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg=
-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---=
&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-=
pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" st=
yle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https://=
u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_priva=
cy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3D=
adg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-=
sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolli=
ng=3D"no" frameborder=3D"0" src=3D"cid:frame-F9D46392EE8615A81E0157AB3E5295=
CA@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=
=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"=
0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-DFD4BF3F67F331FE603B=
0D90606ABE2C@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><i=
mg id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_pri=
vacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%=
26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg=
-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&=
amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Do=
penx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe =
id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=
=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-837D4EFF4945DA15=
33A7C8865C27EFCC@mhtml.blink" style=3D"border: 0px; display: none;"></ifram=
e><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marg=
inheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-C224FCCF=
B9CDC3E75E48730D16AAE178@mhtml.blink" style=3D"border: 0px; display: none;"=
></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; =
height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagi=
o&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidd=
er%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><i=
mg id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6=
dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3=
Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1--=
-"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-D63248D=
9298BE0DF98413034754FF985@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-1B8D62A8070E79B5470FD683DD6A186A@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; dis=
play:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?=
sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fse=
tuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_=
UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; h=
eight:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-4=
39a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io=
%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_pr=
ivacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidt=
h=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fr=
ame-09C3D90B56B65A8B16C1E9E1F25516EF@mhtml.blink" style=3D"border: 0px; dis=
play: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" ma=
rginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-8C26ECD5FA4CADA440DEF981B0BAE4ED@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; disp=
lay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4=
b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%=
2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID=
%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0"=
 marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" sr=
c=3D"cid:frame-41C7EAF92BABB7AA8EF0A7BD35BEB3CF@mhtml.blink" style=3D"borde=
r: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" wid=
th=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-1C3954CD9B68408B0457A7DA8B78A2AB@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"p=
osition:absolute; display:none; height:0; width:0;" src=3D"https://sync.1rx=
.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3=
A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%=
3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:abso=
lute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm=
?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dht=
tps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%=
7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" w=
idth=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborde=
r=3D"0" src=3D"cid:frame-651D87D02EFD047D010CD4441D027A86@mhtml.blink" styl=
e=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=
=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" fr=
ameborder=3D"0" src=3D"cid:frame-5CF617ED8BE5042592D1C4A6EA962F4B@mhtml.bli=
nk" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" s=
tyle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https:/=
/sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=
=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26u=
s_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"pos=
ition:absolute; display:none; height:0; width:0;" src=3D"https://u.openx.ne=
t/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&=
amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt=
%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" heig=
ht=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" =
frameborder=3D"0" src=3D"cid:frame-11E5114EF9C61A82B789E1A92FCB42DC@mhtml.b=
link" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sy=
nc" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=
=3D"no" frameborder=3D"0" src=3D"cid:frame-62A9ACB843ABFFD32A1034004B08B1A5=
@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg=
-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---=
&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-=
pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" st=
yle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https://=
u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_priva=
cy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3D=
adg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-=
sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolli=
ng=3D"no" frameborder=3D"0" src=3D"cid:frame-B44845AD5AE6A428A5FAA7A44B1082=
B0@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=
=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"=
0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-C6CAB7880E7C630093C2=
494E37928EE0@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><i=
mg id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_pri=
vacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%=
26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg=
-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&=
amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Do=
penx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe =
id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=
=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-8E34079C2D279ED6=
931A5D2B69F63745@mhtml.blink" style=3D"border: 0px; display: none;"></ifram=
e><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marg=
inheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-9C5D8CB3=
F60704CB44277D520E8824A9@mhtml.blink" style=3D"border: 0px; display: none;"=
></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; =
height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagi=
o&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidd=
er%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><i=
mg id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6=
dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3=
Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1--=
-"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-D841530=
91AE9B95CD2E8D9547F64AC3B@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-FBCF4B98D4C1B580FB18F06523D6CA5F@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; dis=
play:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?=
sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fse=
tuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_=
UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; h=
eight:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-4=
39a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io=
%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_pr=
ivacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidt=
h=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fr=
ame-3F0A984BC9723CEE4CF36C47C068CEFC@mhtml.blink" style=3D"border: 0px; dis=
play: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" ma=
rginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-10671928BF77DF29433AA737F4F3EB49@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; disp=
lay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4=
b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%=
2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID=
%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0"=
 marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" sr=
c=3D"cid:frame-064FCFFCC483209633CFFF5EF232590D@mhtml.blink" style=3D"borde=
r: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" wid=
th=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-21A2CBAEFD763551C821C97F963A6EDE@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"p=
osition:absolute; display:none; height:0; width:0;" src=3D"https://sync.1rx=
.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3=
A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%=
3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:abso=
lute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm=
?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dht=
tps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%=
7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" w=
idth=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborde=
r=3D"0" src=3D"cid:frame-1C61D870FDCE9178D57332796CC11383@mhtml.blink" styl=
e=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=
=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" fr=
ameborder=3D"0" src=3D"cid:frame-06545DB342B29FC0AA043883F4E0B6D2@mhtml.bli=
nk" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" s=
tyle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https:/=
/sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=
=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26u=
s_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"pos=
ition:absolute; display:none; height:0; width:0;" src=3D"https://u.openx.ne=
t/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&=
amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt=
%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" heig=
ht=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" =
frameborder=3D"0" src=3D"cid:frame-383A329D2B6032FD3ADCA17581472074@mhtml.b=
link" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sy=
nc" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=
=3D"no" frameborder=3D"0" src=3D"cid:frame-BDCBD27C9A7784C6DBE73A2BD28E9DF1=
@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg=
-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---=
&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-=
pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" st=
yle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https://=
u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_priva=
cy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3D=
adg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-=
sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolli=
ng=3D"no" frameborder=3D"0" src=3D"cid:frame-E05161F22B8FA939F2B4703B12B8C8=
A9@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=
=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"=
0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-4278F4C50C422268BE84=
801EC0B1D4F6@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><i=
mg id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_pri=
vacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%=
26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg=
-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&=
amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Do=
penx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe =
id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=
=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-B24F105A63538E0C=
F966CF5F76C9D313@mhtml.blink" style=3D"border: 0px; display: none;"></ifram=
e><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marg=
inheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-5EB77234=
6610B23DF663AADE9801CE86@mhtml.blink" style=3D"border: 0px; display: none;"=
></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; =
height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagi=
o&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidd=
er%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><i=
mg id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6=
dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3=
Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1--=
-"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-833E3B7=
E05F904FF75330F32C4A79D0F@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-39290B827513EF85ED8D8FA2B324EE93@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; dis=
play:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?=
sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fse=
tuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_=
UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; h=
eight:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-4=
39a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io=
%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_pr=
ivacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidt=
h=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fr=
ame-109553C830007B4CBC1F6C8B712FA6B4@mhtml.blink" style=3D"border: 0px; dis=
play: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" ma=
rginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-6959FE2375ACABCE540A30A8CC1058EC@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; disp=
lay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4=
b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%=
2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID=
%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0"=
 marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" sr=
c=3D"cid:frame-987FCE8780539624B463C5AF458B84D7@mhtml.blink" style=3D"borde=
r: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" wid=
th=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-8F7C6CDAFE059994F3044C6778314DF1@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"p=
osition:absolute; display:none; height:0; width:0;" src=3D"https://sync.1rx=
.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3=
A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%=
3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:abso=
lute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm=
?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dht=
tps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%=
7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" w=
idth=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborde=
r=3D"0" src=3D"cid:frame-642A7BBA7F595DBEF76D1DC317544789@mhtml.blink" styl=
e=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=
=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" fr=
ameborder=3D"0" src=3D"cid:frame-14C0E7338B339EC24B87B44A4B301511@mhtml.bli=
nk" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" s=
tyle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https:/=
/sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=
=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26u=
s_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"pos=
ition:absolute; display:none; height:0; width:0;" src=3D"https://u.openx.ne=
t/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&=
amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt=
%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" heig=
ht=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" =
frameborder=3D"0" src=3D"cid:frame-3B192B0382788E5C7B3BC7490FEC5EA2@mhtml.b=
link" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sy=
nc" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=
=3D"no" frameborder=3D"0" src=3D"cid:frame-3036B8B3981CD5BB2C659EABBE315675=
@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg=
-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---=
&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-=
pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" st=
yle=3D"position:absolute; display:none; height:0; width:0;" src=3D"https://=
u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_priva=
cy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3D=
adg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-=
sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolli=
ng=3D"no" frameborder=3D"0" src=3D"cid:frame-5331F66FA34126401A452B76DF91BF=
69@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=
=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"=
0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-248016EF4C242365629F=
BB23471B3337@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><i=
mg id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_pri=
vacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%=
26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg=
-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" src=
=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&=
amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Do=
penx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe =
id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=
=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-6DC22295DE986E74=
4246ABE29A01165D@mhtml.blink" style=3D"border: 0px; display: none;"></ifram=
e><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marg=
inheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-4A287824=
CF980A23EDF459CF610B23E7@mhtml.blink" style=3D"border: 0px; display: none;"=
></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; =
height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagi=
o&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidd=
er%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><i=
mg id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; wi=
dth:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6=
dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3=
Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1--=
-"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-F6D7D1C=
13B8A2ACF2B244B1D872EE4EA@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-593DAE6B01DE859114FA58EDDBBFFC6D@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; dis=
play:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?=
sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fse=
tuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_=
UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; h=
eight:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-4=
39a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io=
%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_pr=
ivacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidt=
h=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fr=
ame-23385CB84452A6320F5E79C0BC2A38E4@mhtml.blink" style=3D"border: 0px; dis=
play: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" ma=
rginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-37C3850D826BD93C6243125DB1CCCB59@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><iframe allow=3D"join-ad-interest-group" da=
ta-tagging-id=3D"G-YJM03XN8Q2" data-load-time=3D"1723736789121" height=3D"0=
" width=3D"0" src=3D"cid:frame-DED42709B4A894C996852760271684AB@mhtml.blink=
" style=3D"display: none; visibility: hidden;"></iframe><img id=3D"adg-0-sy=
nc" style=3D"position:absolute; display:none; height:0; width:0;" src=3D"ht=
tps://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;r=
edir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt=
%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D=
"position:absolute; display:none; height:0; width:0;" src=3D"https://u.open=
x.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1=
---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb=
-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" =
height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"=
no" frameborder=3D"0" src=3D"cid:frame-F6218D32FFD35C25CC13A38C9ED05569@mht=
ml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-=
3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrol=
ling=3D"no" frameborder=3D"0" src=3D"cid:frame-B14F3A571315C9C5AE8F686C0E0E=
0754@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D=
"adg-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" =
src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1=
---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Da=
dg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync"=
 style=3D"position:absolute; display:none; height:0; width:0;" src=3D"https=
://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_pr=
ivacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it=
%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg=
-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scro=
lling=3D"no" frameborder=3D"0" src=3D"cid:frame-F88C6839BC41AE357A35DB2B7C5=
5CFB1@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe i=
d=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D=
"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-26AD215BCF1877F95A8=
897DA60D07C5C@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><=
iframe allow=3D"join-ad-interest-group" data-tagging-id=3D"G-YJM03XN8Q2" da=
ta-load-time=3D"1723736882774" height=3D"0" width=3D"0" src=3D"cid:frame-86=
7490AD7E2D1E4B31834579B2745D8A@mhtml.blink" style=3D"display: none; visibil=
ity: hidden;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; d=
isplay:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpss=
p?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2F=
setuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BR=
X_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none;=
 height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1=
-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.=
io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_=
privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwi=
dth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:=
frame-EBF13ED0D0FEA4ACE43576D485A8BAE3@mhtml.blink" style=3D"border: 0px; d=
isplay: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" =
marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-3B5E3E25FC149FFCF74571CE154E4C74@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; disp=
lay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4=
b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%=
2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID=
%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0"=
 marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" sr=
c=3D"cid:frame-B3691D86C16746DFA03BBE92F550E165@mhtml.blink" style=3D"borde=
r: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" wid=
th=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-FAFE28AEBE0FCE2EC556CC5B630EA18B@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"p=
osition:absolute; display:none; height:0; width:0;" src=3D"https://sync.1rx=
.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3=
A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%=
3D1---%26uid%3D%5BRX_UUID%5D"><iframe allow=3D"join-ad-interest-group" data=
-tagging-id=3D"G-YJM03XN8Q2" data-load-time=3D"1723736967474" height=3D"0" =
width=3D"0" src=3D"cid:frame-FE0723B838BDB0E6E56C48E92906C555@mhtml.blink" =
style=3D"display: none; visibility: hidden;"></iframe><img id=3D"adg-1-sync=
" style=3D"position:absolute; display:none; height:0; width:0;" src=3D"http=
s://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_p=
rivacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26i=
t%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"ad=
g-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scr=
olling=3D"no" frameborder=3D"0" src=3D"cid:frame-BE79E8A395D438618EDB2DD29F=
E2F47C@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe =
id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=
=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-CFAEC694EF2968C9=
2E21B2AB626D8690@mhtml.blink" style=3D"border: 0px; display: none;"></ifram=
e><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0=
; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us=
_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunr=
uly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D=
"adg-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" =
src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bca=
bf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%=
3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><ifra=
me id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheigh=
t=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-A9E5AB5B43801A4=
7EC6C2F3E4822B920@mhtml.blink" style=3D"border: 0px; display: none;"></ifra=
me><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-4FFCAD1=
6F6CC071408CC8B90F0A91933@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none;=
 height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadag=
io&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbid=
der%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><=
iframe allow=3D"join-ad-interest-group" data-tagging-id=3D"G-YJM03XN8Q2" da=
ta-load-time=3D"1723737031239" height=3D"0" width=3D"0" src=3D"cid:frame-9A=
0D43A67972D896112119643227B5D6@mhtml.blink" style=3D"display: none; visibil=
ity: hidden;"></iframe><img id=3D"adg-1-sync" style=3D"position:absolute; d=
isplay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3=
cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%=
2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX=
_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D=
"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0"=
 src=3D"cid:frame-B689B01E246F658BD4E23A16D30F2284@mhtml.blink" style=3D"bo=
rder: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" =
width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" framebord=
er=3D"0" src=3D"cid:frame-6982420D125C782AB78A65A107BA918E@mhtml.blink" sty=
le=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D=
"position:absolute; display:none; height:0; width:0;" src=3D"https://sync.1=
rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps=
%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privac=
y%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/=
cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3D=
https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3=
D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0"=
 width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" framebor=
der=3D"0" src=3D"cid:frame-80EC8C1CB5A4ACC6657B7677D9C349F9@mhtml.blink" st=
yle=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" heig=
ht=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" =
frameborder=3D"0" src=3D"cid:frame-85EEC758D7C2F8F8FD7AA7BE41825A9D@mhtml.b=
link" style=3D"border: 0px; display: none;"></iframe><iframe allow=3D"join-=
ad-interest-group" data-tagging-id=3D"G-YJM03XN8Q2" data-load-time=3D"17237=
37094303" height=3D"0" width=3D"0" src=3D"cid:frame-F1BC884DAFD9DEB9DE9A03E=
1A8119013@mhtml.blink" style=3D"display: none; visibility: hidden;"></ifram=
e><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0=
; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us=
_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunr=
uly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D=
"adg-1-sync" style=3D"position:absolute; display:none; height:0; width:0;" =
src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bca=
bf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%=
3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><ifra=
me id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheigh=
t=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-2B452CA18ED33C7=
D35CF2C081FC22B28@mhtml.blink" style=3D"border: 0px; display: none;"></ifra=
me><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" mar=
ginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-60A1520=
B77126F6B646EF6C673CFB34F@mhtml.blink" style=3D"border: 0px; display: none;=
"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; display:none;=
 height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadag=
io&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbid=
der%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><=
img id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; w=
idth:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b=
6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%=
3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1-=
--"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" ma=
rginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-00482D=
36E8EAED8497C7B8FA34DD3EC6@mhtml.blink" style=3D"border: 0px; display: none=
;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=
=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:fra=
me-7B4C22389397174D9E3A13883BFB795E@mhtml.blink" style=3D"border: 0px; disp=
lay: none;"></iframe><iframe allow=3D"join-ad-interest-group" data-tagging-=
id=3D"G-YJM03XN8Q2" data-load-time=3D"1723737157585" height=3D"0" width=3D"=
0" src=3D"cid:frame-9EFAFA7984FC0E0603A467A337EBCC27@mhtml.blink" style=3D"=
display: none; visibility: hidden;"></iframe><img id=3D"adg-0-sync" style=
=3D"position:absolute; display:none; height:0; width:0;" src=3D"https://syn=
c.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dht=
tps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_pri=
vacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position=
:absolute; display:none; height:0; width:0;" src=3D"https://u.openx.net/w/1=
.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=
=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26ui=
d%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D=
"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frame=
border=3D"0" src=3D"cid:frame-C8B37829CCF5C3F25B19C48193868C85@mhtml.blink"=
 style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" h=
eight=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"n=
o" frameborder=3D"0" src=3D"cid:frame-54C383E79948FA6802ED74DAB679AD56@mhtm=
l.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D"adg-0-sy=
nc" style=3D"position:absolute; display:none; height:0; width:0;" src=3D"ht=
tps://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;r=
edir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt=
%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D=
"position:absolute; display:none; height:0; width:0;" src=3D"https://u.open=
x.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1=
---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb=
-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" =
height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"=
no" frameborder=3D"0" src=3D"cid:frame-958A2AE0BF0A63428D8FEDD78EAD6D7E@mht=
ml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-=
3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrol=
ling=3D"no" frameborder=3D"0" src=3D"cid:frame-EDBEBDA4B9CB74E9A1D51443C441=
4AEC@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D=
"adg-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" =
src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1=
---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Da=
dg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><iframe allow=3D"join-=
ad-interest-group" data-tagging-id=3D"G-YJM03XN8Q2" data-load-time=3D"17237=
37221007" height=3D"0" width=3D"0" src=3D"cid:frame-34A35045A5FF0C348FD643A=
1BAA77DE5@mhtml.blink" style=3D"display: none; visibility: hidden;"></ifram=
e><img id=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0=
; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-817=
4-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetu=
id%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3=
D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0"=
 marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-B77=
C3317ED580BB8C07FEFB133EB8884@mhtml.blink" style=3D"border: 0px; display: n=
one;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwid=
th=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:f=
rame-F78A8A5BC417BBC7F7C51E0080F453E8@mhtml.blink" style=3D"border: 0px; di=
splay: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; d=
isplay:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpss=
p?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2F=
setuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BR=
X_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none;=
 height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1=
-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.=
io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_=
privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwi=
dth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:=
frame-BE8528ABFDB20056BC20C69F270BC595@mhtml.blink" style=3D"border: 0px; d=
isplay: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" =
marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-5195928FB0421BFE1B6D5C81884BF8BF@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><iframe allow=3D"join-ad-interest-group" data-tagging-i=
d=3D"G-YJM03XN8Q2" data-load-time=3D"1723737524718" height=3D"0" width=3D"0=
" src=3D"cid:frame-0831C6E34210E87B1C1F3E404CADF226@mhtml.blink" style=3D"d=
isplay: none; visibility: hidden;"></iframe><img id=3D"adg-1-sync" style=3D=
"position:absolute; display:none; height:0; width:0;" src=3D"https://u.open=
x.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1=
---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb=
-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" =
height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"=
no" frameborder=3D"0" src=3D"cid:frame-0448A905A7CB5843ACD272A31E548237@mht=
ml.blink" style=3D"border: 0px; display: none;"></iframe><iframe id=3D"adg-=
3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scrol=
ling=3D"no" frameborder=3D"0" src=3D"cid:frame-058A07727E6F9EEC856683DD836C=
8534@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><img id=3D=
"adg-0-sync" style=3D"position:absolute; display:none; height:0; width:0;" =
src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1=
---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Da=
dg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync"=
 style=3D"position:absolute; display:none; height:0; width:0;" src=3D"https=
://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_pr=
ivacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it=
%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D"adg=
-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" scro=
lling=3D"no" frameborder=3D"0" src=3D"cid:frame-5487979777C971E0E9D18C21D3B=
DDA71@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><iframe i=
d=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D=
"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-4DBDAE1290BBE28FCC4=
6083842F88220@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><=
iframe allow=3D"join-ad-interest-group" data-tagging-id=3D"G-YJM03XN8Q2" da=
ta-load-time=3D"1723737587620" height=3D"0" width=3D"0" src=3D"cid:frame-1A=
182482D386411C40F246542719C817@mhtml.blink" style=3D"display: none; visibil=
ity: hidden;"></iframe><img id=3D"adg-0-sync" style=3D"position:absolute; d=
isplay:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpss=
p?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2F=
setuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BR=
X_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; display:none;=
 height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1=
-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.=
io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_=
privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwi=
dth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:=
frame-1206C3BBBC711C08703CF42488ECBE93@mhtml.blink" style=3D"border: 0px; d=
isplay: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" =
marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=
=3D"cid:frame-2293872226C4D3A360CCEB8BD6AFFE72@mhtml.blink" style=3D"border=
: 0px; display: none;"></iframe><img id=3D"adg-0-sync" style=3D"position:ab=
solute; display:none; height:0; width:0;" src=3D"https://sync.1rx.io/usersy=
nc2/rmpssp?sub=3Dadagio&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4=
dex.io%2Fsetuid%3Fbidder%3Dunruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26u=
id%3D%5BRX_UUID%5D"><img id=3D"adg-1-sync" style=3D"position:absolute; disp=
lay:none; height:0; width:0;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4=
b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%=
2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID=
%7D%26us_privacy%3D1---"><iframe id=3D"adg-2-sync" height=3D"0" width=3D"0"=
 marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" sr=
c=3D"cid:frame-45C041B9E282111ED0297CB2EE558712@mhtml.blink" style=3D"borde=
r: 0px; display: none;"></iframe><iframe id=3D"adg-3-sync" height=3D"0" wid=
th=3D"0" marginwidth=3D"0" marginheight=3D"0" scrolling=3D"no" frameborder=
=3D"0" src=3D"cid:frame-106AFABFF718877C6F306B87A5D114E1@mhtml.blink" style=
=3D"border: 0px; display: none;"></iframe><iframe allow=3D"join-ad-interest=
-group" data-tagging-id=3D"G-YJM03XN8Q2" data-load-time=3D"1723737651004" h=
eight=3D"0" width=3D"0" src=3D"cid:frame-161F476BE524AC3777A977F755B7D63E@m=
html.blink" style=3D"display: none; visibility: hidden;"></iframe><img id=
=3D"adg-0-sync" style=3D"position:absolute; display:none; height:0; width:0=
;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;us_privacy=
=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dunruly%26it=
%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=3D"adg-1-s=
ync" style=3D"position:absolute; display:none; height:0; width:0;" src=3D"h=
ttps://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96bcabf&amp;u=
s_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dopenx%=
26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><iframe id=3D=
"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheight=3D"0" =
scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-EC3A0248064B77403A8B60B=
8D76B61F6@mhtml.blink" style=3D"border: 0px; display: none;"></iframe><ifra=
me id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginheigh=
t=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-B8DDD998B8EB922=
E28D7634588AB95DA@mhtml.blink" style=3D"border: 0px; display: none;"></ifra=
me><img id=3D"adg-0-sync" style=3D"position:absolute; display:none; height:=
0; width:0;" src=3D"https://sync.1rx.io/usersync2/rmpssp?sub=3Dadagio&amp;u=
s_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dun=
ruly%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D%5BRX_UUID%5D"><img id=
=3D"adg-1-sync" style=3D"position:absolute; display:none; height:0; width:0=
;" src=3D"https://u.openx.net/w/1.0/cm?id=3D3cc4b2f6-c7e1-439a-8174-b6dbb96=
bcabf&amp;us_privacy=3D1---&amp;r=3Dhttps%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidd=
er%3Dopenx%26it%3Dadg-pb-clt%26uid%3D%7BOPENX_ID%7D%26us_privacy%3D1---"><i=
frame id=3D"adg-2-sync" height=3D"0" width=3D"0" marginwidth=3D"0" marginhe=
ight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-A56E6EDD369F=
424DEA6A0A2C280FAF72@mhtml.blink" style=3D"border: 0px; display: none;"></i=
frame><iframe id=3D"adg-3-sync" height=3D"0" width=3D"0" marginwidth=3D"0" =
marginheight=3D"0" scrolling=3D"no" frameborder=3D"0" src=3D"cid:frame-32ED=
ED34D84F5788E610775E0E2D458E@mhtml.blink" style=3D"border: 0px; display: no=
ne;"></iframe></body><iframe name=3D"goog_topics_frame" src=3D"cid:frame-34=
EF3D17C72F4BEE9EB20CD7BD3453DB@mhtml.blink" style=3D"display: none;"></ifra=
me><iframe name=3D"ifrm_improvedigital" src=3D"cid:frame-99CF2FCA807332D454=
B252FF71234AB4@mhtml.blink" style=3D"display: none;"></iframe><iframe name=
=3D"ifrm_pubmatic" src=3D"cid:frame-A88B88DB10C2650DB029CDBE7AACD864@mhtml.=
blink" style=3D"display: none;"></iframe><iframe sandbox=3D"allow-scripts a=
llow-same-origin" id=3D"306884dacb4d6d8" frameborder=3D"0" allowtransparenc=
y=3D"true" marginheight=3D"0" marginwidth=3D"0" width=3D"0" hspace=3D"0" vs=
pace=3D"0" height=3D"0" style=3D"height:0px;width:0px;display:none;" scroll=
ing=3D"no" src=3D"cid:frame-DA0014676C190E975A99495C12CED1C7@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"3213=
cf196a80233" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
3C64C6EC12962B874F58CCBFD6BCE3E8@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"337d=
e3f1dde5099" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
D5F0A1A5D8F8E93397B90898082436B6@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"348c=
7aadff9cafe" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
65661AB2092DCCFAC6FF3B7BEE045F5A@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"35ff=
5c8b37a2451" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
E15B7F9A3811E8D1F7C0DC85C90FBB07@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"3651=
7ba244bb7a4" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
CB6E51A051D15D65D421FBC8634306EE@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"37fa=
d308a9e8edb" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
A7933880E1923E671DADE7CA34BD55F0@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"38af=
465409dd561" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
35476F854166569CD78D6388C5CA59BC@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"39f7=
ec3144f28e" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0"=
 marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" style=
=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-3=
5FA648E14294CDDD9C3654D436F5C04@mhtml.blink">
    </iframe><iframe sandbox=3D"allow-scripts allow-same-origin" id=3D"4065=
e1aa7a97c6b" frameborder=3D"0" allowtransparency=3D"true" marginheight=3D"0=
" marginwidth=3D"0" width=3D"0" hspace=3D"0" vspace=3D"0" height=3D"0" styl=
e=3D"height:0px;width:0px;display:none;" scrolling=3D"no" src=3D"cid:frame-=
769996090EF9131946D126AADA38C275@mhtml.blink">
    </iframe></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-01c3eafd-e4c8-4500-abfb-912cc72404f7@mhtml.blink

@charset "utf-8";

.error_widget_wrapper { background: inherit; color: inherit; border: none; =
}

.error_widget { border-top: 2px solid; border-bottom: 2px solid; margin: 5p=
x 0px; padding: 10px 40px; white-space: pre-wrap; }

.error_widget.ace_error, .error_widget_arrow.ace_error { border-color: rgb(=
255, 90, 90); }

.error_widget.ace_warning, .error_widget_arrow.ace_warning { border-color: =
rgb(241, 216, 23); }

.error_widget.ace_info, .error_widget_arrow.ace_info { border-color: rgb(90=
, 90, 90); }

.error_widget.ace_ok, .error_widget_arrow.ace_ok { border-color: rgb(90, 17=
0, 90); }

.error_widget_arrow { position: absolute; border-width: 5px; border-style: =
solid; border-bottom-color: initial; border-image: initial; top: -5px; bord=
er-top-color: transparent !important; border-right-color: transparent !impo=
rtant; border-left-color: transparent !important; }
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-facb9104-6360-414d-9a79-992940a2dbb2@mhtml.blink

@charset "utf-8";

.ace-tm .ace_gutter { background: rgb(240, 240, 240); color: rgb(51, 51, 51=
); }

.ace-tm .ace_print-margin { width: 1px; background: rgb(232, 232, 232); }

.ace-tm .ace_fold { background-color: rgb(107, 114, 230); }

.ace-tm { background-color: rgb(255, 255, 255); color: black; }

.ace-tm .ace_cursor { color: black; }

.ace-tm .ace_invisible { color: rgb(191, 191, 191); }

.ace-tm .ace_storage, .ace-tm .ace_keyword { color: blue; }

.ace-tm .ace_constant { color: rgb(197, 6, 11); }

.ace-tm .ace_constant.ace_buildin { color: rgb(88, 72, 246); }

.ace-tm .ace_constant.ace_language { color: rgb(88, 92, 246); }

.ace-tm .ace_constant.ace_library { color: rgb(6, 150, 14); }

.ace-tm .ace_invalid { background-color: rgba(255, 0, 0, 0.1); color: red; =
}

.ace-tm .ace_support.ace_function { color: rgb(60, 76, 114); }

.ace-tm .ace_support.ace_constant { color: rgb(6, 150, 14); }

.ace-tm .ace_support.ace_type, .ace-tm .ace_support.ace_class { color: rgb(=
109, 121, 222); }

.ace-tm .ace_keyword.ace_operator { color: rgb(104, 118, 135); }

.ace-tm .ace_string { color: rgb(3, 106, 7); }

.ace-tm .ace_comment { color: rgb(76, 136, 107); }

.ace-tm .ace_comment.ace_doc { color: rgb(0, 102, 255); }

.ace-tm .ace_comment.ace_doc.ace_tag { color: rgb(128, 159, 191); }

.ace-tm .ace_constant.ace_numeric { color: rgb(0, 0, 205); }

.ace-tm .ace_variable { color: rgb(49, 132, 149); }

.ace-tm .ace_xml-pe { color: rgb(104, 104, 91); }

.ace-tm .ace_entity.ace_name.ace_function { color: rgb(0, 0, 162); }

.ace-tm .ace_heading { color: rgb(12, 7, 255); }

.ace-tm .ace_list { color: rgb(185, 6, 144); }

.ace-tm .ace_meta.ace_tag { color: rgb(0, 22, 142); }

.ace-tm .ace_string.ace_regex { color: rgb(255, 0, 0); }

.ace-tm .ace_marker-layer .ace_selection { background: rgb(181, 213, 255); =
}

.ace-tm.ace_multiselect .ace_selection.ace_start { box-shadow: white 0px 0p=
x 3px 0px; }

.ace-tm .ace_marker-layer .ace_step { background: rgb(252, 255, 0); }

.ace-tm .ace_marker-layer .ace_stack { background: rgb(164, 229, 101); }

.ace-tm .ace_marker-layer .ace_bracket { margin: -1px 0px 0px -1px; border:=
 1px solid rgb(192, 192, 192); }

.ace-tm .ace_marker-layer .ace_active-line { background: rgba(0, 0, 0, 0.07=
); }

.ace-tm .ace_gutter-active-line { background-color: rgb(220, 220, 220); }

.ace-tm .ace_marker-layer .ace_selected-word { background: rgb(250, 250, 25=
5); border: 1px solid rgb(200, 200, 250); }

.ace-tm .ace_indent-guide { background: url("data:image/png;base64,iVBORw0K=
GgoAAAANSUhEUgAAAAEAAAACCAYAAACZgbYnAAAAE0lEQVQImWP4////f4bLly//BwAmVgd1/w1=
1/gAAAABJRU5ErkJggg=3D=3D") right center repeat-y; }
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-b9aede08-502b-44ca-871f-1c68723f81a1@mhtml.blink

@charset "utf-8";

.ace_br1 { border-top-left-radius: 3px; }

.ace_br2 { border-top-right-radius: 3px; }

.ace_br3 { border-top-left-radius: 3px; border-top-right-radius: 3px; }

.ace_br4 { border-bottom-right-radius: 3px; }

.ace_br5 { border-top-left-radius: 3px; border-bottom-right-radius: 3px; }

.ace_br6 { border-top-right-radius: 3px; border-bottom-right-radius: 3px; }

.ace_br7 { border-top-left-radius: 3px; border-top-right-radius: 3px; borde=
r-bottom-right-radius: 3px; }

.ace_br8 { border-bottom-left-radius: 3px; }

.ace_br9 { border-top-left-radius: 3px; border-bottom-left-radius: 3px; }

.ace_br10 { border-top-right-radius: 3px; border-bottom-left-radius: 3px; }

.ace_br11 { border-top-left-radius: 3px; border-top-right-radius: 3px; bord=
er-bottom-left-radius: 3px; }

.ace_br12 { border-bottom-right-radius: 3px; border-bottom-left-radius: 3px=
; }

.ace_br13 { border-top-left-radius: 3px; border-bottom-right-radius: 3px; b=
order-bottom-left-radius: 3px; }

.ace_br14 { border-top-right-radius: 3px; border-bottom-right-radius: 3px; =
border-bottom-left-radius: 3px; }

.ace_br15 { border-radius: 3px; }

.ace_editor { position: relative; overflow: hidden; padding: 0px; font: 12p=
x Monaco, Menlo, "Ubuntu Mono", Consolas, source-code-pro, monospace; direc=
tion: ltr; text-align: left; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);=
 }

.ace_scroller { position: absolute; overflow: hidden; top: 0px; bottom: 0px=
; background-color: inherit; user-select: none; cursor: text; }

.ace_content { position: absolute; box-sizing: border-box; min-width: 100%;=
 contain: size layout style; font-variant-ligatures: no-common-ligatures; }

.ace_dragging .ace_scroller::before { position: absolute; inset: 0px; conte=
nt: ""; background: rgba(250, 250, 250, 0.01); z-index: 1000; }

.ace_dragging.ace_dark .ace_scroller::before { background: rgba(0, 0, 0, 0.=
01); }

.ace_selecting, .ace_selecting * { cursor: text !important; }

.ace_gutter { position: absolute; overflow: hidden; width: auto; top: 0px; =
bottom: 0px; left: 0px; cursor: default; z-index: 4; user-select: none; con=
tain: size layout style; }

.ace_gutter-active-line { position: absolute; left: 0px; right: 0px; }

.ace_scroller.ace_scroll-left { box-shadow: rgba(0, 0, 0, 0.4) 17px 0px 16p=
x -16px inset; }

.ace_gutter-cell { position: absolute; top: 0px; left: 0px; right: 0px; pad=
ding-left: 19px; padding-right: 6px; background-repeat: no-repeat; }

.ace_gutter-cell.ace_error { background-image: url("data:image/png;base64,i=
VBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAABOFBMVEX/////////QRswFAb/Ui4w=
FAYwFAYwFAaWGAfDRymzOSH/PxswFAb/SiUwFAYwFAbUPRvjQiDllog5HhHdRybsTi3/Tyv9Tir=
+Syj/UC3////XurebMBIwFAb/RSHbPx/gUzfdwL3kzMivKBAwFAbbvbnhPx66NhowFAYwFAaZJg=
8wFAaxKBDZurf/RB6mMxb/SCMwFAYwFAbxQB3+RB4wFAb/Qhy4Oh+4QifbNRcwFAYwFAYwFAb/Q=
RzdNhgwFAYwFAbav7v/Uy7oaE68MBK5LxLewr/r2NXewLswFAaxJw4wFAbkPRy2PyYwFAaxKhLm=
1tMwFAazPiQwFAaUGAb/QBrfOx3bvrv/VC/maE4wFAbRPBq6MRO8Qynew8Dp2tjfwb0wFAbx6ej=
u5+by6uns4uH9/f36+vr/GkHjAAAAYnRSTlMAGt+64rnWu/bo8eAA4InH3+DwoN7j4eLi4xP99N=
fg4+b+/u9B/eDs1MD1mO7+4PHg2MXa347g7vDizMLN4eG+Pv7i5evs/v79yu7S3/DV7/498Yv24=
eH+4ufQ3Ozu/v7+y13sRqwAAADLSURBVHjaZc/XDsFgGIBhtDrshlitmk2IrbHFqL2pvXf/+78D=
Pokj7+Fz9qpU/9UXJIlhmPaTaQ6QPaz0mm+5gwkgovcV6GZzd5JtCQwgsxoHOvJO15kleRLAnMg=
HFIESUEPmawB9ngmelTtipwwfASilxOLyiV5UVUyVAfbG0cCPHig+GBkzAENHS0AstVF6bacZIO=
zgLmxsHbt2OecNgJC83JERmePUYq8ARGkJx6XtFsdddBQgZE2nPR6CICZhawjA4Fb/chv+399kf=
R+MMMDGOQAAAABJRU5ErkJggg=3D=3D"); background-repeat: no-repeat; background=
-position: 2px center; }

.ace_gutter-cell.ace_warning { background-image: url("data:image/png;base64=
,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAmVBMVEX///8AAAD///8AAAAAAA=
BPSzb/5sAAAAB/blH/73z/ulkAAAAAAAD85pkAAAAAAAACAgP/vGz/rkDerGbGrV7/pkQICAf//=
//e0IsAAAD/oED/qTvhrnUAAAD/yHD/njcAAADuv2r/nz//oTj/p064oGf/zHAAAAA9Nir/tFIA=
AAD/tlTiuWf/tkIAAACynXEAAAAAAAAtIRW7zBpBAAAAM3RSTlMAABR1m7RXO8Ln31Z36zT+neX=
e5OzooRDfn+TZ4p3h2hTf4t3k3ucyrN1K5+Xaks52Sfs9CXgrAAAAjklEQVR42o3PbQ+CIBQFYE=
wboPhSYgoYunIqqLn6/z8uYdH8Vmdnu9vz4WwXgN/xTPRD2+sgOcZjsge/whXZgUaYYvT8QnuJa=
UrjrHUQreGczuEafQCO/SJTufTbroWsPgsllVhq3wJEk2jUSzX3CUEDJC84707djRc5MTAQxoLg=
upWRwW6UB5fS++NV8AbOZgnsC7BpEAAAAABJRU5ErkJggg=3D=3D"); background-position=
: 2px center; }

.ace_gutter-cell.ace_info { background-image: url("data:image/png;base64,iV=
BORw0KGgoAAAANSUhEUgAAABAAAAAQCAAAAAA6mKC9AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJb=
WFnZVJlYWR5ccllPAAAAAJ0Uk5TAAB2k804AAAAPklEQVQY02NgIB68QuO3tiLznjAwpKTgNyDb=
MegwisCHZUETUZV0ZqOquBpXj2rtnpSJT1AEnnRmL2OgGgAAIKkRQap2htgAAAAASUVORK5CYII=
=3D"); background-position: 2px center; }

.ace_dark .ace_gutter-cell.ace_info { background-image: url("data:image/png=
;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAAJFBMVEUAAAChoaGAgIA=
qKiq+vr6tra1ZWVmUlJSbm5s8PDxubm56enrdgzg3AAAAAXRSTlMAQObYZgAAAClJREFUeNpjYM=
APdsMYHegyJZFQBlsUlMFVCWUYKkAZMxZAGdxlDMQBAG+TBP4B6RyJAAAAAElFTkSuQmCC"); }

.ace_scrollbar { contain: strict; position: absolute; right: 0px; bottom: 0=
px; z-index: 6; }

.ace_scrollbar-inner { position: absolute; cursor: text; left: 0px; top: 0p=
x; }

.ace_scrollbar-v { overflow: hidden scroll; top: 0px; }

.ace_scrollbar-h { overflow: scroll hidden; left: 0px; }

.ace_print-margin { position: absolute; height: 100%; }

.ace_text-input { position: absolute; z-index: 0; width: 0.5em; height: 1em=
; opacity: 0; background: transparent; appearance: none; border: none; resi=
ze: none; outline: none; overflow: hidden; font: inherit; padding: 0px 1px;=
 margin: 0px -1px; contain: strict; user-select: text; white-space: pre !im=
portant; }

.ace_text-input.ace_composition { background: transparent; color: inherit; =
z-index: 1000; opacity: 1; }

.ace_composition_placeholder { color: transparent; }

.ace_composition_marker { border-bottom: 1px solid; position: absolute; bor=
der-radius: 0px; margin-top: 1px; }

[ace_nocontext=3D"true"] { z-index: auto; transform: none !important; filte=
r: none !important; clip-path: none !important; mask: none !important; cont=
ain: none !important; perspective: none !important; mix-blend-mode: initial=
 !important; }

.ace_layer { z-index: 1; position: absolute; overflow: hidden; overflow-wra=
p: normal; white-space: pre; height: 100%; width: 100%; box-sizing: border-=
box; pointer-events: none; }

.ace_gutter-layer { position: relative; width: auto; text-align: right; poi=
nter-events: auto; height: 1e+06px; contain: size layout style; }

.ace_text-layer { position: absolute; height: 1e+06px; width: 1e+06px; cont=
ain: size layout style; font: inherit !important; }

.ace_text-layer > .ace_line, .ace_text-layer > .ace_line_group { contain: s=
ize layout style; position: absolute; top: 0px; left: 0px; right: 0px; }

.ace_hidpi .ace_text-layer, .ace_hidpi .ace_gutter-layer, .ace_hidpi .ace_c=
ontent, .ace_hidpi .ace_gutter { contain: strict; will-change: transform; }

.ace_hidpi .ace_text-layer > .ace_line, .ace_hidpi .ace_text-layer > .ace_l=
ine_group { contain: strict; }

.ace_cjk { display: inline-block; text-align: center; }

.ace_cursor-layer { z-index: 4; }

.ace_cursor { z-index: 4; position: absolute; box-sizing: border-box; borde=
r-left: 2px solid; transform: translateZ(0px); }

.ace_multiselect .ace_cursor { border-left-width: 1px; }

.ace_slim-cursors .ace_cursor { border-left-width: 1px; }

.ace_overwrite-cursors .ace_cursor { border-left-width: 0px; border-bottom:=
 1px solid; }

.ace_hidden-cursors .ace_cursor { opacity: 0.2; }

.ace_hasPlaceholder .ace_hidden-cursors .ace_cursor { opacity: 0; }

.ace_smooth-blinking .ace_cursor { transition: opacity 0.18s; }

.ace_animate-blinking .ace_cursor { animation-duration: 1000ms; animation-t=
iming-function: step-end; animation-name: blink-ace-animate; animation-iter=
ation-count: infinite; }

.ace_animate-blinking.ace_smooth-blinking .ace_cursor { animation-duration:=
 1000ms; animation-timing-function: ease-in-out; animation-name: blink-ace-=
animate-smooth; }

@keyframes blink-ace-animate {=20
  0%, 100% { opacity: 1; }
  60% { opacity: 0; }
}

@keyframes blink-ace-animate-smooth {=20
  0%, 100% { opacity: 1; }
  45% { opacity: 1; }
  60% { opacity: 0; }
  85% { opacity: 0; }
}

.ace_marker-layer .ace_step, .ace_marker-layer .ace_stack { position: absol=
ute; z-index: 3; }

.ace_marker-layer .ace_selection { position: absolute; z-index: 5; }

.ace_marker-layer .ace_bracket { position: absolute; z-index: 6; }

.ace_marker-layer .ace_error_bracket { position: absolute; border-bottom: 1=
px solid rgb(222, 85, 85); border-radius: 0px; }

.ace_marker-layer .ace_active-line { position: absolute; z-index: 2; }

.ace_marker-layer .ace_selected-word { position: absolute; z-index: 4; box-=
sizing: border-box; }

.ace_line .ace_fold { box-sizing: border-box; display: inline-block; height=
: 11px; margin-top: -2px; vertical-align: middle; background-image: url("da=
ta:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAAJCAYAAADU6McMAAAAGXRFWHR=
Tb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAJpJREFUeNpi/P//PwOlgAXGYGRklAVSok=
D8GmjwY1wasKljQpYACtpCFeADcHVQfQyMQAwzwAZI3wJKvCLkfKBaMSClBlR7BOQikCFGQEErI=
H0VqkabiGCAqwUadAzZJRxQr/0gwiXIal8zQQPnNVTgJ1TdawL0T5gBIP1MUJNhBv2HKoQHHjqN=
rA4WO4zY0glyNKLT2KIfIMAAQsdgGiXvgnYAAAAASUVORK5CYII=3D"), url("data:image/p=
ng;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAA3CAYAAADNNiA5AAAAGXRFWHRTb2Z0d2FyZ=
QBBZG9iZSBJbWFnZVJlYWR5ccllPAAAACJJREFUeNpi+P//fxgTAwPDBxDxD078RSX+YeEyDFMC=
IMAAI3INmXiwf2YAAAAASUVORK5CYII=3D"); background-repeat: no-repeat, repeat-=
x; background-position: center center, left top; color: transparent; border=
: 1px solid black; border-radius: 2px; cursor: pointer; pointer-events: aut=
o; }

.ace_dark .ace_fold { }

.ace_fold:hover { background-image: url("data:image/png;base64,iVBORw0KGgoA=
AAANSUhEUgAAABEAAAAJCAYAAADU6McMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR=
5ccllPAAAAJpJREFUeNpi/P//PwOlgAXGYGRklAVSokD8GmjwY1wasKljQpYACtpCFeADcHVQfQ=
yMQAwzwAZI3wJKvCLkfKBaMSClBlR7BOQikCFGQEErIH0VqkabiGCAqwUadAzZJRxQr/0gwiXIa=
l8zQQPnNVTgJ1TdawL0T5gBIP1MUJNhBv2HKoQHHjqNrA4WO4zY0glyNKLT2KIfIMAAQsdgGiXv=
gnYAAAAASUVORK5CYII=3D"), url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=
AAAAEAAAA3CAYAAADNNiA5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA=
CBJREFUeNpi+P//fz4TAwPDZxDxD5X4i5fLMEwJgAADAEPVDbjNw87ZAAAAAElFTkSuQmCC"); =
}

.ace_tooltip { background-color: rgb(255, 255, 255); background-image: line=
ar-gradient(transparent, rgba(0, 0, 0, 0.1)); border: 1px solid gray; borde=
r-radius: 1px; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px; color: black; ma=
x-width: 100%; padding: 3px 4px; position: fixed; z-index: 999999; box-sizi=
ng: border-box; cursor: default; white-space: pre; overflow-wrap: break-wor=
d; line-height: normal; font-style: normal; font-weight: normal; letter-spa=
cing: normal; pointer-events: none; }

.ace_folding-enabled > .ace_gutter-cell { padding-right: 13px; }

.ace_fold-widget { box-sizing: border-box; margin: 0px -12px 0px 1px; displ=
ay: none; width: 11px; vertical-align: top; background-image: url("data:ima=
ge/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAANElEQVR42mWKs=
Q0AMAzC8ixLlrzQjzmBiEjp0A6WwBCSPgKAXoLkqSot7nN3yMwR7pZ32NzpKkVoDBUxKAAAAABJ=
RU5ErkJggg=3D=3D"); background-repeat: no-repeat; background-position: cent=
er center; border-radius: 3px; border: 1px solid transparent; cursor: point=
er; }

.ace_folding-enabled .ace_fold-widget { display: inline-block; }

.ace_fold-widget.ace_end { background-image: url("data:image/png;base64,iVB=
ORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAANElEQVR42m3HwQkAMAhD0YzsRchFKI=
7sAikeWkrxwScEB0nh5e7KTPWimZki4tYfVbX+MNl4pyZXejUO1QAAAABJRU5ErkJggg=3D=3D"=
); }

.ace_fold-widget.ace_closed { background-image: url("data:image/png;base64,=
iVBORw0KGgoAAAANSUhEUgAAAAMAAAAGCAYAAAAG5SQMAAAAOUlEQVR42jXKwQkAMAgDwKwqKD4=
EwQ26sSOkVWjgIIHAzPiCgaqiqnJHZnKICBERHN194O5b9vbLuAVRL+l0YWnZAAAAAElFTkSuQm=
CCXA=3D=3D"); }

.ace_fold-widget:hover { border: 1px solid rgba(0, 0, 0, 0.3); background-c=
olor: rgba(255, 255, 255, 0.2); box-shadow: rgba(255, 255, 255, 0.7) 0px 1p=
x 1px; }

.ace_fold-widget:active { border: 1px solid rgba(0, 0, 0, 0.4); background-=
color: rgba(0, 0, 0, 0.05); box-shadow: rgba(255, 255, 255, 0.8) 0px 1px 1p=
x; }

.ace_dark .ace_fold-widget { background-image: url("data:image/png;base64,i=
VBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHklEQVQIW2P4//8/AzoGEQ7oGCaL=
LAhWiSwB146BAQCSTPYocqT0AAAAAElFTkSuQmCC"); }

.ace_dark .ace_fold-widget.ace_end { background-image: url("data:image/png;=
base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAH0lEQVQIW2P4//8/AxQ7=
wNjIAjDMgC4AxjCVKBirIAAF0kz2rlhxpAAAAABJRU5ErkJggg=3D=3D"); }

.ace_dark .ace_fold-widget.ace_closed { background-image: url("data:image/p=
ng;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAFCAYAAACAcVaiAAAAHElEQVQIW2P4//+/A=
xAzgDADlOOAznHAKgPWAwARji8UIDTfQQAAAABJRU5ErkJggg=3D=3D"); }

.ace_dark .ace_fold-widget:hover { box-shadow: rgba(255, 255, 255, 0.2) 0px=
 1px 1px; background-color: rgba(255, 255, 255, 0.1); }

.ace_dark .ace_fold-widget:active { box-shadow: rgba(255, 255, 255, 0.2) 0p=
x 1px 1px; }

.ace_inline_button { border: 1px solid lightgray; display: inline-block; ma=
rgin: -1px 8px; padding: 0px 5px; pointer-events: auto; cursor: pointer; }

.ace_inline_button:hover { border-color: gray; background: rgba(200, 200, 2=
00, 0.2); display: inline-block; pointer-events: auto; }

.ace_fold-widget.ace_invalid { background-color: rgb(255, 180, 180); border=
-color: rgb(222, 85, 85); }

.ace_fade-fold-widgets .ace_fold-widget { transition: opacity 0.4s 0.05s; o=
pacity: 0; }

.ace_fade-fold-widgets:hover .ace_fold-widget { transition: opacity 0.05s 0=
.05s; opacity: 1; }

.ace_underline { text-decoration: underline; }

.ace_bold { font-weight: bold; }

.ace_nobold .ace_bold { font-weight: normal; }

.ace_italic { font-style: italic; }

.ace_error-marker { background-color: rgba(255, 0, 0, 0.2); position: absol=
ute; z-index: 9; }

.ace_highlight-marker { background-color: rgba(255, 255, 0, 0.2); position:=
 absolute; z-index: 8; }

.ace_mobile-menu { position: absolute; line-height: 1.5; border-radius: 4px=
; user-select: none; background: white; box-shadow: grey 1px 3px 2px; borde=
r: 1px solid rgb(220, 220, 220); color: black; }

.ace_dark > .ace_mobile-menu { background: rgb(51, 51, 51); color: rgb(204,=
 204, 204); box-shadow: grey 1px 3px 2px; border: 1px solid rgb(68, 68, 68)=
; }

.ace_mobile-button { padding: 2px; cursor: pointer; overflow: hidden; }

.ace_mobile-button:hover { background-color: rgb(238, 238, 238); opacity: 1=
; }

.ace_mobile-button:active { background-color: rgb(221, 221, 221); }

.ace_placeholder { font-family: arial; transform: scale(0.9); transform-ori=
gin: left center; white-space: pre; opacity: 0.7; margin: 0px 10px; }
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-f87a3247-f892-4244-94a7-45597da84181@mhtml.blink

@charset "utf-8";

.pgAdWrapper { min-height: 0px !important; }

#carbonads { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Ro=
boto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", Helvetica, Arial, s=
ans-serif; --width: 728px; --font-size: 22px; }

#carbonads { display: block; overflow: hidden; max-width: var(--width); pos=
ition: relative; background-color: rgb(252, 252, 252); border: 1px solid rg=
b(238, 238, 238); font-size: var(--font-size); box-sizing: border-box; marg=
in: 36px 0px; max-height: 90px; }

.detail #carbonads { margin-top: 12px; }

#carbonads a { color: inherit; text-decoration: none; }

#carbonads a:hover { color: inherit; }

.carbon-wrap { display: flex; align-items: center; }

carbon-img { display: block; float: left; margin: 0px; max-width: var(--wid=
th); line-height: 1; }

.carbon-img img { display: block; margin: 0px; height: 90px; width: auto; }

.carbon-text { display: block; float: left; padding: 0px 1em; line-height: =
1.35; max-width: calc(100% - 2em - 130px); text-align: left; }

.carbon-poweredby { display: block; position: absolute; bottom: 0px; right:=
 0px; padding: 6px 10px; background: repeating-linear-gradient(-45deg, tran=
sparent, transparent 5px, rgba(0, 0, 0, 0.024) 5px, rgba(0, 0, 0, 0.024) 10=
px) rgba(241, 243, 244, 0.8); text-align: center; text-transform: uppercase=
; letter-spacing: 0.5px; font-weight: 601; font-size: 8px; border-top-left-=
radius: 4px; line-height: 1; }

@media only screen and (min-width: 320px) and (max-width: 759px) {
  .carbon-text { font-size: 14px; }
}
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-f006c9d3-7ffb-4592-856d-35bfe338443d@mhtml.blink

@charset "utf-8";

.unic { -webkit-font-smoothing: antialiased; line-height: 1.15; text-size-a=
djust: 100%; box-sizing: border-box; font-family: sans-serif; }

.unic main { display: block; }

.unic h1 { font-size: 2em; margin: 0.67em 0px; }

.unic hr { box-sizing: content-box; height: 0px; overflow: visible; }

.unic pre { font-family: monospace, monospace; font-size: 1em; }

.unic a { background-color: transparent; }

.unic abbr[title] { border-bottom: none; text-decoration: underline dotted;=
 }

.unic b, .unic strong { font-weight: bolder; }

.unic code, .unic kbd, .unic samp { font-family: monospace, monospace; font=
-size: 1em; }

.unic small { font-size: 80%; }

.unic sub, .unic sup { font-size: 75%; line-height: 0; position: relative; =
vertical-align: baseline; }

.unic sub { bottom: -0.25em; }

.unic sup { top: -0.5em; }

.unic img { border-style: none; }

.unic button, .unic input, .unic optgroup, .unic select, .unic textarea { f=
ont-family: inherit; font-size: 100%; line-height: 1.15; margin: 0px; }

.unic button, .unic input { overflow: visible; }

.unic button, .unic select { text-transform: none; }

.unic [type=3D"button"], .unic [type=3D"reset"], .unic [type=3D"submit"], .=
unic button { appearance: button; }

.unic fieldset { padding: 0.35em 0.75em 0.625em; }

.unic legend { box-sizing: border-box; color: inherit; display: table; max-=
width: 100%; padding: 0px; white-space: normal; }

.unic progress { vertical-align: baseline; }

.unic textarea { overflow: auto; }

.unic [type=3D"checkbox"], .unic [type=3D"radio"] { box-sizing: border-box;=
 padding: 0px; }

.unic [type=3D"number"]::-webkit-inner-spin-button, .unic [type=3D"number"]=
::-webkit-outer-spin-button { height: auto; }

.unic [type=3D"search"] { appearance: textfield; outline-offset: -2px; }

.unic [type=3D"search"]::-webkit-search-decoration { appearance: none; }

.unic ::-webkit-file-upload-button { appearance: button; font: inherit; }

.unic details { display: block; }

.unic summary { display: list-item; }

.unic [hidden], .unic template { display: none; }

.unic *, .unic ::after, .unic ::before { box-sizing: inherit; }

.unic blockquote, .unic dd, .unic dl, .unic figure, .unic h1, .unic h2, .un=
ic h3, .unic h4, .unic h5, .unic h6, .unic hr, .unic p, .unic pre { margin:=
 0px; }

.unic button { background: transparent; padding: 0px; white-space: normal; =
}

.unic button:focus { outline: -webkit-focus-ring-color auto 5px; }

.unic fieldset, .unic ol, .unic ul { margin: 0px; padding: 0px; }

.unic ol, .unic ul { list-style: none; }

.unic * { line-height: 1.5; font-weight: 400; height: auto; font-family: -a=
pple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Aria=
l, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe U=
I Symbol", "Noto Color Emoji" !important; }

.unic *, .unic ::after, .unic ::before { border: 0px solid rgb(226, 232, 24=
0); }

.unic hr { border-top-width: 1px; }

.unic img { border-style: solid; }

.unic textarea { resize: vertical; }

.unic input::-webkit-input-placeholder, .unic textarea::-webkit-input-place=
holder { color: rgb(160, 174, 192); }

.unic input::placeholder, .unic textarea::placeholder { color: rgb(160, 174=
, 192); }

.unic [role=3D"button"], .unic button { cursor: pointer; }

.unic table { border-collapse: collapse; }

.unic h1, .unic h2, .unic h3, .unic h4, .unic h5, .unic h6 { font-size: inh=
erit; font-weight: inherit; }

.unic a { color: inherit; text-decoration: inherit; }

.unic button, .unic input, .unic optgroup, .unic select, .unic textarea { p=
adding: 0px; line-height: inherit; color: inherit; }

.unic code, .unic kbd, .unic pre, .unic samp { font-family: Menlo, Monaco, =
Consolas, "Liberation Mono", "Courier New", monospace; }

.unic audio, .unic canvas, .unic embed, .unic iframe, .unic img, .unic obje=
ct, .unic svg, .unic video { display: block; vertical-align: middle; }

.unic img, .unic video { max-width: 100%; height: auto; }

.unic .container { width: 100%; }

@media (min-width: 640px) {
  .unic .container { max-width: 640px; }
}

@media (min-width: 768px) {
  .unic .container { max-width: 768px; }
}

@media (min-width: 1024px) {
  .unic .container { max-width: 1024px; }
}

@media (min-width: 1280px) {
  .unic .container { max-width: 1280px; }
}

.unic .bg-white { background-color: rgb(255, 255, 255); }

.unic .bg-gray-200 { background-color: rgb(237, 242, 247); }

.unic .bg-gray-300 { background-color: rgb(226, 232, 240); }

.unic .bg-gray-400, .unic .hover\:bg-gray-400:hover { background-color: rgb=
(203, 213, 224); }

.unic .hover\:bg-gray-600:hover { background-color: rgb(113, 128, 150); }

.unic .border-gray-300 { border-color: rgb(226, 232, 240); }

.unic .rounded { border-radius: 4px; }

.unic .rounded-full { border-radius: 9999px; }

.unic .rounded-t-lg { border-top-left-radius: 8px; border-top-right-radius:=
 8px; }

.unic .rounded-b-lg { border-bottom-right-radius: 8px; border-bottom-left-r=
adius: 8px; }

.unic .border-solid { border-style: solid; }

.unic .border { border-width: 1px; }

.unic .border-t { border-top-width: 1px; }

.unic .border-r { border-right-width: 1px; }

.unic .border-b { border-bottom-width: 1px; }

.unic .border-l { border-left-width: 1px; }

.unic .cursor-pointer { cursor: pointer; }

.unic .block { display: block; }

.unic .inline { display: inline; }

.unic .flex { display: flex; }

.unic .hidden { display: none; }

.unic .flex-row { -webkit-box-orient: horizontal; -webkit-box-direction: no=
rmal; flex-direction: row; }

.unic .flex-col { -webkit-box-orient: vertical; -webkit-box-direction: norm=
al; flex-direction: column; }

.unic .flex-wrap { flex-wrap: wrap; }

.unic .items-start { -webkit-box-align: start; align-items: flex-start; }

.unic .items-center { -webkit-box-align: center; align-items: center; }

.unic .justify-start { -webkit-box-pack: start; justify-content: flex-start=
; }

.unic .justify-center { -webkit-box-pack: center; justify-content: center; =
}

.unic .justify-between { -webkit-box-pack: justify; justify-content: space-=
between; }

.unic .flex-1 { -webkit-box-flex: 1; flex: 1 1 0%; }

.unic .flex-auto { -webkit-box-flex: 1; flex: 1 1 auto; }

.unic .font-sans { font-family: -apple-system, BlinkMacSystemFont, "Segoe U=
I", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color =
Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; }

.unic .font-bold { font-weight: 700; }

.unic .h-3 { height: 12px; }

.unic .h-4 { height: 16px; }

.unic .h-5 { height: 20px; }

.unic .h-32 { height: 128px; }

.unic .h-40 { height: 160px; }

.unic .h-64 { height: 256px; }

.unic .h-full { height: 100%; }

.unic .m-2 { margin: 8px; }

.unic .m-auto { margin: auto; }

.unic .mx-0 { margin-left: 0px; margin-right: 0px; }

.unic .mx-1 { margin-left: 4px; margin-right: 4px; }

.unic .mx-2 { margin-left: 8px; margin-right: 8px; }

.unic .mt-2 { margin-top: 8px; }

.unic .mb-2 { margin-bottom: 8px; }

.unic .ml-4 { margin-left: 16px; }

.unic .mt-auto { margin-top: auto; }

.unic .ml-auto { margin-left: auto; }

.unic .max-h-full { max-height: 100%; }

.unic .max-w-xl { max-width: 576px; }

.unic .max-w-2xl { max-width: 672px; }

.unic .object-scale-down { object-fit: scale-down; }

.unic .outline-none { outline: 0px; }

.unic .overflow-scroll { overflow: scroll; }

.unic .overflow-x-hidden { overflow-x: hidden; }

.unic .p-1 { padding: 4px; }

.unic .p-2 { padding: 8px; }

.unic .p-4 { padding: 16px; }

.unic .p-6 { padding: 24px; }

.unic .py-1 { padding-top: 4px; padding-bottom: 4px; }

.unic .py-2 { padding-top: 8px; padding-bottom: 8px; }

.unic .px-2 { padding-left: 8px; padding-right: 8px; }

.unic .px-4 { padding-left: 16px; padding-right: 16px; }

.unic .py-6 { padding-top: 24px; padding-bottom: 24px; }

.unic .pb-0 { padding-bottom: 0px; }

.unic .pr-1 { padding-right: 4px; }

.unic .pr-2 { padding-right: 8px; }

.unic .pb-2 { padding-bottom: 8px; }

.unic .pt-4 { padding-top: 16px; }

.unic .static { position: static; }

.unic .fixed { position: fixed; }

.unic .absolute { position: absolute; }

.unic .relative { position: relative; }

.unic .inset-y-0 { top: 0px; bottom: 0px; }

.unic .inset-x-0 { right: 0px; left: 0px; }

.unic .top-0 { top: 0px; }

.unic .right-0 { right: 0px; }

.unic .bottom-0 { bottom: 0px; }

.unic .left-0 { left: 0px; }

.unic .shadow { box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, =
0, 0.06) 0px 1px 2px 0px; }

.unic .shadow-md { box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0,=
 0, 0, 0.06) 0px 2px 4px -1px; }

.unic .shadow-inner { box-shadow: rgba(0, 0, 0, 0.06) 0px 2px 4px 0px inset=
; }

.unic .text-center { text-align: center; }

.unic .text-black { color: rgb(0, 0, 0); }

.unic .text-gray-700 { color: rgb(74, 85, 104); }

.unic .text-gray-800 { color: rgb(45, 55, 72); }

.unic .text-blue-600 { color: rgb(49, 130, 206); }

.unic .hover\:text-white:hover { color: rgb(255, 255, 255); }

.unic .text-xs { font-size: 12px; }

.unic .text-sm { font-size: 14px; }

.unic .text-lg { font-size: 18px; }

.unic .text-xl { font-size: 20px; }

.unic .underline { text-decoration: underline; }

.unic .hover\:no-underline:hover { text-decoration: none; }

.unic .antialiased { -webkit-font-smoothing: antialiased; }

.unic .align-middle { vertical-align: middle; }

.unic .w-5 { width: 20px; }

.unic .w-10 { width: 40px; }

.unic .w-32 { width: 128px; }

.unic .w-1\/2 { width: 50%; }

.unic .w-full { width: 100%; }

.unic .z-40 { z-index: 40; }

.unic .z-50 { z-index: 50; }

@media (min-width: 768px) {
  .unic .md\:flex-row { -webkit-box-orient: horizontal; -webkit-box-directi=
on: normal; flex-direction: row; }
  .unic .md\:flex-1 { -webkit-box-flex: 1; flex: 1 1 0%; }
  .unic .md\:h-64 { height: 256px; }
  .unic .md\:h-auto { height: auto; }
  .unic .md\:mx-2 { margin-left: 8px; margin-right: 8px; }
  .unic .md\:mx-3 { margin-left: 12px; margin-right: 12px; }
  .unic .md\:pl-4 { padding-left: 16px; }
  .unic .md\:text-base { font-size: 16px; }
  .unic .md\:text-xl { font-size: 20px; }
  .unic .md\:w-1\/2 { width: 50%; }
  .unic .md\:w-1\/4 { width: 25%; }
}

div.unic ::-webkit-scrollbar { display: none; }

.unic { color: rgba(0, 0, 0, 0.76); overflow: auto; }

.unic, .unic li, .unic p { font-size: 14px; }

.unic .h24 { height: 24px; }

.unic label { width: auto; }

.unic .svg { height: 100%; }

.unic .logo, .unic .uniclogo { max-height: 40px; font-weight: 700; margin-t=
op: -2px; }

.unic .unic-mh { max-height: 30vh; }

.unic :focus { outline: dotted thin; }

.unic-bg { background-color: rgba(105, 104, 104, 0.75); }

.unic .toggle__dot { top: -4px; left: -4px; transition: 0.3s ease-in-out; }

.unic input:checked ~ .toggle__dot { transform: translateX(120%); backgroun=
d-color: rgb(72, 187, 120) !important; }

.unic input:checked:disabled ~ .toggle__dot { transform: translateX(120%); =
background-color: rgb(157, 219, 182) !important; }

#uniccmp { z-index: 2147483639; }

#uniccmp-badge, .unic-badge { z-index: 2147483638; }

.unic-badge { width: 30px; height: 30px; padding: 5px; display: block; outl=
ine: none; position: fixed; left: 10px; bottom: 10px; border-radius: 4px; b=
ackground-image: linear-gradient(37deg, rgb(199, 199, 199), rgb(224, 224, 2=
24)); cursor: pointer; }
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: cid:css-e0468f17-4aff-495a-a888-fef7d9c708c2@mhtml.blink

@charset "utf-8";

.up-show + .adSpinner { display: none; }

@keyframes ad-slot__label__letters {=20
  0% { opacity: 1; }
  15% { opacity: 0.65; }
  30% { opacity: 1; }
}

.adSpinner.ad-slot__label { width: 50px; height: 50px; position: absolute; =
padding: 5px; border-radius: 100%; }

.adSpinner.ad-slot__label .az_logo_group { transform: translate(60px, 120px=
); }

.adSpinner.ad-slot__label .letter { animation: 3s ease 0s infinite normal n=
one running ad-slot__label__letters; }

.adSpinner.ad-slot__label .letter__1 { animation-delay: 0.2s; }

.adSpinner.ad-slot__label .letter__2 { animation-delay: 0.4s; }

.adSpinner.ad-slot__label .letter__3 { animation-delay: 0.6s; }

.adSpinner.ad-slot__label .letter__4 { animation-delay: 0.8s; }

.adSpinner.ad-slot__label .letter__5 { animation-delay: 1s; }

.adSpinner.ad-slot__label .letter__6 { animation-delay: 1.2s; }

.adSpinner.ad-slot__label .letter__7 { animation-delay: 1.4s; }
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/css
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/playground.css?v=1fsaf

@charset "utf-8";

@font-face { font-family: droid_sans_monoregular; src: url("assets/fonts/dr=
oidsansmono-webfont.woff2") format("woff2"), url("assets/fonts/droidsansmon=
o-webfont.woff") format("woff"); font-weight: normal; font-style: normal; f=
ont-display: swap; }

@font-face { font-family: euclid_circular; src: url("assets/fonts/euclidcir=
culara-regular-webfont.woff2") format("woff2"), url("assets/fonts/euclidcir=
culara-regular-webfont.woff") format("woff"); font-weight: normal; font-sty=
le: normal; font-display: swap; }

@font-face { font-family: euclid_circular; src: url("assets/fonts/euclidcir=
culara-medium-webfont.woff2") format("woff2"), url("assets/fonts/euclidcirc=
ulara-medium-webfont.woff") format("woff"); font-weight: 500; font-style: n=
ormal; font-display: swap; }

@font-face { font-family: euclid_circular; src: url("./assets/fonts/euclidc=
irculara-bold-webfont.woff2") format("woff2"), url("./assets//fonts/euclidc=
irculara-bold-webfont.woff") format("woff"); font-weight: 700; font-style: =
normal; font-display: swap; }

html, body { margin: 0px; padding: 0px; width: 100%; height: 100%; overflow=
: hidden; }

button { outline: none; }

.clearfix::before, .clearfix::after { content: " "; display: table; }

.clearfix::after { clear: both; }

.container { width: 100vw; height: 100vh; overflow: hidden; }

.wrapper { display: none; }

.svg path { opacity: 1; fill-opacity: 1; stroke-opacity: 1; }

.svg-grey { height: 15px; }

.svg-grey path { opacity: 0.3; fill-opacity: 1; stroke-opacity: 1; }

.ace_mobile-menu { display: none !important; }

.compiler-header-ad { padding: 4px 0px; margin: auto; display: none; }

#carbonads { margin: 6px 0px !important; }

#feedback-desktop { display: none; }

#feedback-mobile svg, #feedback-desktop svg { transform: rotateY(-180deg); =
width: 20px; height: 20px; }

#feedback-mobile svg path, #feedback-desktop svg path { stroke: rgb(5, 86, =
243); }

#editor, #terminal { width: 100%; height: 100% !important; }

.mobile-top-bar { display: flex; align-items: center; position: relative; p=
adding: 8px 16px; border-bottom: 1px solid rgb(211, 220, 230); }

.options-wrapper, .pills-wrapper, .other-options-wrapper { float: left; }

.options-wrapper { display: flex; gap: 12px; }

.pills-wrapper { display: flex; flex-grow: 1; width: 50%; }

.other-options-wrapper { float: right; }

.other-options-wrapper .options-item-wrapper { float: right; }

.options-item-wrapper { font-size: 20px; }

.options-item { width: 20px; height: 20px; float: left; }

#back-button path { fill: rgba(37, 38, 94, 0.4); }

#back-button:hover path { fill: rgb(5, 86, 243); }

.editor-wrapper, .terminal-wrapper, .ace_editor, .ace_scroller, .ace_gutter=
, .ace_gutter-active-line, .ace_gutter-cell { background: rgb(245, 245, 245=
); }

.ace_scrollbar-v { scrollbar-width: thin; scrollbar-color: rgb(193, 193, 19=
3) transparent; }

.ace_comment { font-style: normal !important; }

.terminal-wrapper { display: none; position: relative; }

.editor-desktop-top-bar, .terminal-desktop-top-bar { background: rgb(251, 2=
51, 251); height: 48px; }

.editor-desktop-top-bar, .terminal-desktop-top-bar { display: none; }

.header { display: flex; justify-content: space-between; background-color: =
rgb(255, 255, 255); height: 51px; border-bottom: 1px solid rgb(211, 220, 23=
0); }

.logo-wrapper, .mobile-top-bar { background: rgb(255, 255, 255); }

.logo-wrapper { display: flex; align-items: center; color: rgba(37, 38, 94,=
 0.7); font-family: euclid_circular, sans-serif; }

.logo-title-wrapper { margin: 0px; display: inline-block; }

.logo-title-wrapper .logo-sub-title-wrapper { font-size: 14px; vertical-ali=
gn: middle; font-weight: normal; }

.logo-link { display: flex; flex-direction: column; margin-left: 16px; }

#mobile-ad { display: grid; align-items: center; justify-content: center; b=
ackground: rgb(241, 241, 241); padding-top: 5px; padding-bottom: 2px; }

.editor-wrapper { height: calc(-102px + 100vh); }

.terminal-wrapper { height: calc(-102px + 100vh); }

.sidebar-wrapper { width: 0px; display: none; }

#toggle-dark-mode-desktop, #toggle-expanded-mode-desktop { display: none; }

#toggle-dark-mode-mobile { background: none; cursor: pointer; }

.toggle-dark-mode-mobile-icon.sun { display: none; }

.toggle-dark-mode-mobile-icon.sun path, .toggle-dark-mode-mobile-icon.sun c=
ircle, .toggle-dark-mode-mobile-icon.sun line { stroke: rgb(255, 255, 255);=
 }

.toggle-dark-mode-mobile-icon.moon { display: block; }

.toggle-dark-mode-mobile-icon.moon path { stroke: rgba(37, 38, 94, 0.4); }

.toggle-expanded-mode-mobile-icon path, .change-lang-btn-icon path { fill: =
rgba(37, 38, 94, 0.4); }

.dark-mode .toggle-expanded-mode-mobile-icon path, .dark-mode .change-lang-=
btn-icon path { fill: rgb(255, 255, 255); }

.dark-mode #editor, .dark-mode #terminal { color: rgb(238, 238, 238); }

.dark-mode .ace_scrollbar-v { scrollbar-color: rgba(193, 193, 193, 0.643) t=
ransparent; }

.change-lang-btn-icon { height: 22px; width: 22px; }

#add-replacement { display: none; width: 728px; }

#logo { width: 53px; }

#nav-logo { width: 68px; height: 23px; }

.logo-title-wrapper { text-align: left; transform: translateX(0px); left: 0=
px; }

.logo-title-wrapper .logo-sub-title-wrapper { font-size: 10px; line-height:=
 15px; vertical-align: middle; margin-top: 5px; }

#feedback-mobile { font-family: euclid_circular, sans-serif; display: block=
; }

#feedback-mobile a { text-decoration: none; border: 1px solid rgb(5, 86, 24=
3); color: rgb(5, 86, 243); font-size: 12px; box-sizing: border-box; border=
-radius: 4px; padding: 6px 16px; float: right; margin-right: 16px; margin-t=
op: 12px; background-color: rgb(245, 248, 255); font-weight: 500; line-heig=
ht: 16px; }

.burger-menu-btn { padding: 0px 0px 0px 16px; border: none; background-colo=
r: transparent; }

.burger-menu { display: flex; align-items: center; }

.header-wrapper { display: flex; }

.visible .nav-backdrop, .visible .nav-menu { left: 0px; }

.mobile-nav-drawer { display: none; position: relative; }

.show.mobile-nav-drawer { display: block; position: relative; }

.nav-header-wrapper { display: flex; justify-content: space-between; }

.close-nav-btn { margin: 0px 20px 0px 0px; border: none; background: transp=
arent; }

.close-nav-btn svg path { stroke: rgba(37, 38, 94, 0.7); }

.nav-backdrop { position: absolute; background-color: rgba(0, 0, 0, 0.6); z=
-index: 999; top: 0px; left: -999px; width: 100vw; height: 1000px; }

.nav-menu { font-family: euclid_circular, sans-serif; z-index: 1000; width:=
 calc(-52px + 100vw); height: 1000px; position: absolute; left: -999px; top=
: 0px; background-color: rgb(255, 255, 255); box-sizing: border-box; paddin=
g: 26px 0px 26px 24px; transition: 300ms; overflow: hidden; scrollbar-width=
: none; }

.nav-menu::-webkit-scrollbar { display: none; }

.change-lang-row .change-lang-btn { display: flex; text-align: center; back=
ground: transparent; border-radius: 2px; border: 1px solid rgb(211, 220, 23=
0); padding: 7px; }

.nav-menu-list { padding-top: 40px; overflow-y: scroll; height: calc(-90px =
+ 100dvh); }

.change-lang-row { display: inline-flex; align-items: center; margin-bottom=
: 16px; width: 100%; box-sizing: border-box; }

.change-lang-row:link, .change-lang-row:visited { text-decoration: inherit;=
 color: inherit; }

.nav-menu-text { margin-left: 16px; font-weight: 500; font-size: 14px; line=
-height: 20px; }

.active .nav-menu-text { color: rgb(5, 86, 243); }

.change-lang-btn path { }

.active .change-lang-btn { background: rgb(5, 86, 243); border: 1px solid r=
gb(5, 86, 243); }

.active .change-lang-btn path { fill: rgb(255, 255, 255); }

.active.change-lang-row { border-right: 2px solid rgb(5, 86, 243); }

#div-gpt-ad-Programizcom36417 { width: 320px; margin: 0px auto; }

@media screen and (min-width: 800px) {
  .header { height: 102px; display: grid; grid-template-columns: 2fr 5fr 2f=
r; background: rgb(255, 255, 255); }
  .compiler-header-ad { padding: 0px; }
  .logo-wrapper { background: none; }
  .logo-link { display: flex; flex-direction: column; margin-left: 56px; }
  .logo-title-wrapper { text-align: left; transform: translateX(0px); margi=
n-left: 0px; left: 0px; }
  .logo-title-wrapper .logo-sub-title-wrapper { font-size: 14px; line-heigh=
t: 20px; vertical-align: middle; }
  .logo-sub-title-wrapper .logo-sub-title { display: block; }
  #logo { width: 100.8px; height: 33.6px; }
  #feedback-desktop { font-family: euclid_circular, sans-serif; display: fl=
ex; align-items: center; justify-content: flex-end; }
  #feedback-desktop a { text-decoration: none; border: 1px solid rgb(5, 86,=
 243); color: rgb(5, 86, 243); font-size: 14px; box-sizing: border-box; bor=
der-radius: 4px; padding: 10px 16px; float: right; margin-right: 48px; back=
ground-color: rgb(245, 248, 255); font-weight: 500; }
  .sidebar-wrapper { display: block; box-sizing: border-box; width: 56px; b=
ackground: rgb(239, 242, 247); float: left; padding: 8px; height: calc(-102=
px + 100vh); border-top: 1px solid rgb(211, 220, 230); border-right: 1px so=
lid rgb(211, 220, 230); overflow: scroll; scrollbar-width: none; }
  .sidebar-wrapper::-webkit-scrollbar { display: none; }
  .editor-wrapper { height: calc(-102px + 100vh); }
  .editor-wrapper #toggle-dark-mode-desktop, .editor-wrapper #toggle-expand=
ed-mode-desktop { padding: 6px; margin-left: 16px; }
  .sidebar-wrapper .change-lang-btn { padding: 7px; margin-bottom: 12px; }
  .editor-wrapper #toggle-dark-mode-desktop, .editor-wrapper #toggle-expand=
ed-mode-desktop, .sidebar-wrapper .change-lang-btn { display: flex; text-al=
ign: center; background: transparent; border-radius: 2px; border: 1px solid=
 rgb(211, 220, 230); }
  .change-lang-btn path { }
  .change-lang-btn.active { background: rgb(5, 86, 243); border: 1px solid =
rgb(5, 86, 243); }
  .change-lang-btn.active path { fill: rgb(255, 255, 255); }
  .terminal-desktop-top-bar { display: block; }
  .editor-desktop-top-bar { display: flex; justify-content: space-between; =
}
  .mobile-top-bar { display: none; }
  .mobile-run-button { display: none; }
  .editor-wrapper, .terminal-wrapper { width: calc(50% - 29px); float: left=
; }
  .editor-wrapper { border-right: 1px solid rgb(211, 220, 230); }
  .terminal-wrapper { display: block; }
  .editor-desktop-top-bar { display: flex; justify-content: space-between; =
}
  .desktop-top-bar__btn-wrapper { display: flex; flex: 1 1 0%; align-items:=
 center; justify-content: flex-end; border-top: 1px solid rgb(211, 220, 230=
); border-bottom: 1px solid rgb(211, 220, 230); }
  .terminal-desktop-top-bar { display: flex; justify-content: space-between=
; }
  .terminal-desktop-top-bar__btn-wrapper { display: flex; flex: 1 1 0%; ali=
gn-items: center; justify-content: flex-end; border-top: 1px solid rgb(211,=
 220, 230); border-bottom: 1px solid rgb(211, 220, 230); font-family: eucli=
d_circular; }
  .toggle-expanded-mode-mobile-icon.minimize { display: none; }
  .maximized .toggle-expanded-mode-mobile-icon.expand { display: none; }
  .maximized .toggle-expanded-mode-mobile-icon.minimize { display: block; }
  .maximized .logo-link { margin-left: 24px; flex-direction: row; }
  .dark-mode.maximized .logo-link { align-items: center; }
  .maximized .compiler-header-ad { display: none; }
  .maximized #add-replacement { display: block; }
  .maximized #feedback-desktop a { margin-right: 25px; }
  .maximized .header { height: 49px; }
  .maximized .logo-sub-title-wrapper { margin-left: 11px; }
  .maximized #logo { width: 66px; height: 22px; }
  .maximized .editor-wrapper { width: calc(50% - 1px); height: calc(-49px +=
 100vh); }
  .maximized .terminal-wrapper { width: calc(50% - 1px); }
  .maximized .sidebar-wrapper { display: none; }
  .maximized .header { grid-template-columns: 5fr 1fr 4fr; }
  .maximized #add-replacement { width: 0px; }
}

@media screen and (min-width: 1150px) {
  #div-gpt-ad-Programizcom36416 { width: 720px; padding-top: 30px; margin: =
0px auto; }
}

.pill { background: rgb(255, 255, 255); color: rgba(51, 51, 51, 0.6); paddi=
ng: 4px 15px; font-size: 14px; line-height: 20px; box-shadow: none; font-fa=
mily: euclid_circular; width: 50%; border-width: 1px; border-style: solid; =
border-color: rgba(0, 0, 0, 0.12) rgb(255, 255, 255); border-image: initial=
; box-sizing: border-box; float: left; }

.pill:first-child { border-radius: 2px 0px 0px 2px; border-left-color: rgba=
(0, 0, 0, 0.12); border-right-color: rgb(255, 255, 255); }

.pill:last-child { border-radius: 0px 2px 2px 0px; border-left-color: rgb(2=
55, 255, 255); border-right-color: rgba(0, 0, 0, 0.12); }

.pill.active { border: 1px solid rgb(5, 86, 243); color: rgb(5, 86, 243); }

.run { cursor: pointer; padding: 6px 16px; background: rgb(5, 86, 243); fon=
t-size: 14px; line-height: 20px; color: rgb(255, 255, 255); border: none; o=
utline: none; border-radius: 2px; z-index: 109; font-weight: bold; }

.run:hover { background: rgb(0, 71, 209); }

.desktop-run-button { display: flex; min-width: 67px; min-height: 32px; mar=
gin: 0px 20px 0px 16px; justify-content: center; font-family: euclid_circul=
ar; }

.desktop-save-button { display: flex; min-width: 67px; min-height: 32px; ma=
rgin: 0px 0px 0px 16px; padding: 6px 16px; justify-content: center; cursor:=
 pointer; font-size: 14px; line-height: 20px; color: rgba(37, 38, 94, 0.7);=
 border: none; outline: none; border-radius: 2px; z-index: 109; font-weight=
: bold; font-family: euclid_circular; }

.desktop-get-started-anchor { margin: 0px; float: right; padding: 16px; tex=
t-align: center; font-family: euclid_circular; }

.desktop-clear-button { cursor: pointer; padding: 6px 16px; background: non=
e; font-size: 14px; line-height: 20px; color: rgba(37, 38, 94, 0.7); outlin=
e: none; z-index: 109; margin: 0px 20px 0px 16px; border: 1px solid rgb(211=
, 220, 230); box-sizing: border-box; border-radius: 2px; font-family: eucli=
d_circular; }

.mobile-run-button { position: fixed; bottom: 20px; right: 20px; }

.mobile-top-bar-run-button { display: flex; padding: 6px 16px; width: fit-c=
ontent; margin-left: 12px; }

.wrapper { height: 100%; background: rgb(245, 245, 245); }

.sidebar { height: 100%; background: rgb(238, 242, 247); border-right: 1px =
solid rgb(211, 220, 230); }

ul.option-buttons { list-style: none; padding: 0px 10px; }

li.option-button { margin-bottom: 16px; }

li.option-button button { height: 36px; width: 36px; border-radius: 2px; ba=
ckground: white; border: 1px solid rgb(211, 220, 230); margin: 0px auto; }

.code-editor-wrapper { position: relative; }

.pane-separator-vertical, .pane-separator-horizontal { background: rgb(211,=
 220, 230); position: relative; z-index: 10000; }

.pane-separator-vertical { height: 100%; }

.pane-separator img { position: absolute; left: 50%; top: 50%; transform: t=
ranslate(-50%, -50%); }

.code-editor-top-bar { height: 56px; background: rgb(251, 251, 251); border=
-bottom: 1px solid rgb(211, 220, 230); z-index: 1000; display: block; }

.file-name, .shell-name { color: rgba(37, 38, 94, 0.7); }

.file-name { display: inline-flex; align-items: center; background: rgb(245=
, 245, 245); line-height: 24px; padding: 12px 24px; border-right: 1px solid=
 rgb(211, 220, 230); border-top: 1px solid rgb(211, 220, 230); border-botto=
m: 1px solid rgb(245, 245, 245); font-family: euclid_circular; font-weight:=
 500; font-size: 16px; }

.shell { width: 120px; line-height: 24px; padding: 16px 20px; border-right:=
 1px solid rgb(211, 220, 230); border-top: 1px solid rgb(211, 220, 230); fo=
nt-family: Arial; float: left; background: rgb(5, 86, 243); color: white; c=
ursor: pointer; }

.shell-name { font-weight: 500; line-height: 24px; padding: 11px 18px; font=
-family: euclid_circular; border-top: 1px solid rgb(211, 220, 230); border-=
bottom: 1px solid rgb(211, 220, 230); }

.run-icon { margin-right: 4px; }

.spinner { height: 100%; width: 100%; display: flex; justify-content: cente=
r; align-items: center; }

.loader { opacity: 0.8; color: rgb(5, 86, 243); font-size: 20vh; font-weigh=
t: bold; font-family: Consolas, Menlo, Monaco, monospace; }

.loader span { display: inline-block; animation: 0.4s ease-in-out 0s infini=
te alternate none running pulse; }

.loader span:nth-child(2n+1) { animation-delay: 0.4s; }

.back-button, .extra-options { display: grid; align-items: center; justify-=
content: center; cursor: pointer; }

.orientation { border: none; }

.pills { max-width: 200px; min-width: 175px; text-align: center; }

button { cursor: pointer; }

.logo-link:link, .logo-link:visited { text-decoration: inherit; color: inhe=
rit; }

@keyframes pulse {=20
  100% { transform: scale(0.8); opacity: 0.5; }
}

.dark-mode, .dark-mode .header { background: rgb(31, 32, 35); }

.dark-mode .logo-wrapper { color: rgb(255, 255, 255); }

.dark-mode .file-name { background: rgb(28, 33, 48); color: rgb(255, 255, 2=
55); border-right: 1px solid rgba(255, 255, 255, 0.2); border-top: 1px soli=
d rgba(255, 255, 255, 0.2); border-bottom: 1px solid rgb(28, 33, 48); }

.dark-mode .shell-name { color: rgb(255, 255, 255); border-top: 1px solid r=
gba(255, 255, 255, 0.2); border-bottom: 1px solid rgba(255, 255, 255, 0.2);=
 }

.dark-mode .wrapper, .dark-mode .editor-wrapper, .dark-mode .ace_editor, .d=
ark-mode .ace_gutter, .dark-mode .ace_scroller, .dark-mode .ace_gutter-acti=
ve-line, .dark-mode .ace_gutter-cell, .dark-mode .terminal-wrapper { backgr=
ound: rgb(28, 33, 48); }

.dark-mode .editor-wrapper { border-right: none; }

.dark-mode .editor-desktop-top-bar, .dark-mode .terminal-desktop-top-bar { =
background: rgb(45, 47, 52); color: rgb(255, 255, 255); }

.dark-mode #feedback-desktop a { color: rgb(255, 255, 255); border: 1px sol=
id rgb(255, 255, 255); background-color: transparent; }

.dark-mode #feedback-mobile a { color: rgb(255, 255, 255); border: 1px soli=
d rgb(255, 255, 255); background-color: transparent; }

.dark-mode #feedback-mobile svg path, .dark-mode #feedback-desktop svg path=
 { stroke: rgb(255, 255, 255); fill: none; }

.dark-mode .logo-wrapper { background: rgb(31, 32, 35); }

.dark-mode .mobile-top-bar { background: rgb(45, 47, 52); border-bottom: 1p=
x solid rgba(255, 255, 255, 0.2); }

.dark-mode .pill { background: transparent; border: 1px solid rgba(255, 255=
, 255, 0.2); color: rgb(255, 255, 255); }

.dark-mode .pill.active { background: rgb(5, 86, 243); border-color: rgb(5,=
 86, 243); }

.dark-mode .spinner .loader { color: rgb(255, 255, 255); }

.dark-mode #back-button path { fill: rgb(255, 255, 255); }

.dark-mode #back-button:hover path { fill: rgb(5, 86, 243); }

.dark-mode .toggle-dark-mode-mobile-icon.sun { display: block; }

.dark-mode .toggle-dark-mode-mobile-icon.moon { display: none; }

.dark-mode #toggle-dark-mode-desktop, .dark-mode #toggle-expanded-mode-desk=
top, .dark-mode .change-lang-btn { border: 1px solid rgba(255, 255, 255, 0.=
2); }

.dark-mode .active .change-lang-btn { border: 1px solid rgb(5, 86, 243); }

.dark-mode .close-nav-btn svg path { stroke: rgba(255, 255, 255, 0.87); }

.dark-mode .desktop-top-bar__btn-wrapper, .dark-mode .terminal-desktop-top-=
bar__btn-wrapper { border-top: 1px solid rgba(255, 255, 255, 0.2); border-b=
ottom: 1px solid rgba(255, 255, 255, 0.2); }

.dark-mode .desktop-clear-button { color: rgb(255, 255, 255); }

.dark-mode .burger-menu-btn svg path { stroke: rgba(255, 255, 255, 0.87); }

.dark-mode .active .nav-menu-text svg path { stroke: rgb(255, 255, 255); }

.dark-mode .nav-menu { background: rgb(56, 59, 64); }

.dark-mode .nav-menu-text { color: rgba(255, 255, 255, 0.67); }

.dark-mode .active .nav-menu-text { color: rgb(255, 255, 255); }

.dark-mode .active.change-lang-row { border-right: 2px solid rgb(255, 255, =
255); }

@media screen and (min-width: 800px) {
  .dark-mode .logo-wrapper { background: none; }
  .dark-mode .editor-wrapper { border-right: 1px solid rgba(255, 255, 255, =
0.2); }
  .dark-mode .sidebar-wrapper { background: rgb(56, 59, 64); border-top: 1p=
x solid rgba(255, 255, 255, 0.2); border-right: 1px solid rgba(255, 255, 25=
5, 0.2); }
  .dark-mode .editor-wrapper #toggle-dark-mode-desktop { background: transp=
arent; }
  .header { height: 102px; border-bottom: none; }
  .compiler-header-ad { display: block; }
  #feedback-mobile { display: none; }
  .burger-menu { display: none; }
  .show.mobile-nav-drawer { display: none; }
}

.adSpinner { display: none; }

@keyframes spin {=20
  0% { transform: rotate(0deg); }
  100% { transform: rotate(359deg); }
}

#loader, #mobile-top-bar-run-button-loader { animation: 2s linear 0s infini=
te normal none running spin; }

.d-flex { display: flex; }

.d-none { display: none !important; }

.message-description { gap: 3px; display: flex; color: rgb(255, 255, 255); =
font-size: 20px; font-weight: 500; line-height: 30px; font-style: normal; a=
lign-items: center; }

.message-description--link-underlined__cyber-monday { color: rgb(160, 252, =
254); }

.emoji { font-family: "Segoe UI Emoji"; }

.share-button { display: flex; justify-content: center; gap: 8px; font-weig=
ht: 500; font-size: 14px; line-height: 20px; align-items: center; margin-le=
ft: 16px; width: 85px; height: 32px; border-radius: 2px; border: 1px solid =
rgb(211, 220, 230); background: none; color: rgba(37, 38, 94, 0.67); cursor=
: pointer; padding: 6px; font-family: euclid_circular; }

.tablet-share { width: 32px; }

.share-link-generating-modal { display: none; position: relative; }

.modal-content { background: rgb(255, 255, 255); border: none; border-radiu=
s: 0.3rem; opacity: 1; position: fixed; left: 50%; top: 50%; transform: tra=
nslate(-50%, -50%) scale(1); z-index: 1000; font-family: euclid_circular; a=
nimation: 0.3s ease 0s 1 normal forwards running modalFadeIn; width: 312px;=
 }

.modal-content.hidden { animation: 0.3s ease 0s 1 normal forwards running m=
odalFadeOut; }

.modal-backdrop-share { top: 0px; left: 0px; width: 100%; z-index: 500; hei=
ght: 100vh; position: fixed; background: rgba(0, 0, 0, 0.5); opacity: 1; }

.modal-backdrop-share.hidden { animation: 0.3s ease 0s 1 normal forwards ru=
nning modalBackdropFadeOut; }

.modal-header { display: flex; justify-content: space-between; padding: 24p=
x 24px 16px; color: rgb(37, 38, 94); align-items: center; }

.modal-title { margin: 0px; font-size: 24px; font-weight: 500; line-height:=
 36px; display: none; }

.modal-title-mob { display: block; }

.close-modal { cursor: pointer; outline: none; background: none; border: no=
ne; }

.button:disabled, button[disabled] { cursor: not-allowed; }

.close-modal path { stroke-width: 2.667; }

.modal-body { padding: 0px 24px 24px; }

.social-icon { width: 30px; height: 30px; display: flex; justify-content: c=
enter; align-items: center; border: 1px solid rgb(5, 86, 243); border-radiu=
s: 50%; cursor: pointer; }

.social-icon a { display: flex; justify-content: center; align-items: cente=
r; }

.social-icons-container { display: flex; justify-content: center; gap: 8px;=
 margin: 0px; padding: 0px; }

.social-icon:hover path { fill: rgb(0, 163, 255); stroke: none; }

.social-icon:hover { border-color: rgb(0, 163, 255); }

.social-wrapper { display: flex; flex-direction: column; margin-top: 24px; =
gap: 16px; align-items: center; }

.social-wrapper li { list-style: none; }

.social-wrapper span { font-size: 14px; font-weight: 500; line-height: 20px=
; font-family: euclid_circular; color: rgb(37, 38, 94); }

.progress-bar { width: 100%; background: rgb(211, 220, 230); border-radius:=
 4px; }

.progress { width: 0px; height: 8px; background: rgb(5, 86, 243); border-ra=
dius: 4px; }

.share-link-modal { display: none; }

.share-code-container { display: flex; align-items: center; justify-content=
: space-between; background-color: rgb(248, 250, 255); border: 1px solid rg=
b(211, 220, 230); border-radius: 4px; padding: 12px 16px; font-size: 16px; =
line-height: 24px; }

.share-code-value {
  display: flex; flex-grow: 1; border: none; background: none; width: 100%;=
 color: rgb(37, 38, 94); font-weight: 400; font-size: 14px; line-height: 20=
px; font-family: euclid_circular; padding: 0px;
  &:focus-visible { outline: none; }
}

.share-code-copy-btn {
  width: 100%; padding: 8px 0px; font-size: 14px; line-height: 20px; margin=
-top: 16px; background: rgb(5, 86, 243); color: white; border: none; border=
-radius: 4px; font-weight: 700; font-family: euclid_circular;
  &:hover { background: rgb(0, 71, 209); }
}

.code-copied-success {
  background: rgb(86, 189, 91); align-items: center; justify-content: cente=
r; gap: 8px; display: none;
  &:hover { background: rgb(86, 189, 91); }
  & svg {
  & path { stroke: white; }
}
}

@keyframes modalFadeIn {=20
  0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
  100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
}

@keyframes modalFadeOut {=20
  0% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
}

@keyframes modalBackdropFadeIn {=20
  0% { opacity: 0; }
  100% { opacity: 1; }
}

@keyframes modalBackdropFadeOut {=20
  0% { opacity: 1; }
  100% { opacity: 0; }
}

.check-icon-wrapper { background-color: rgb(227, 76, 76); display: flex; al=
ign-items: center; justify-content: center; padding: 14px 8px; border-right=
: 1px solid rgb(86, 189, 91); }

.check-icon-wrapper--error { background-color: rgb(253, 232, 232); border-r=
ight: 1px solid rgb(227, 76, 76); }

.close-modal-notification {
  cursor: pointer; outline: none; background: none; border: none; display: =
flex; align-items: center; padding: 10px 8px 10px 12px;
  & svg { width: 20px; height: 20px; }
}

.share-icon { width: 20px; height: 20px; }

.share-icon path { fill: none; stroke: rgba(37, 38, 94, 0.4); }

.share-button-mob { display: flex; align-items: center; cursor: pointer; pa=
dding: 0px; background: none; border: none; }

.notification { display: none; position: fixed; align-items: center; overfl=
ow: hidden; left: 50%; bottom: 30px; transform: translate(-50%, 200%) scale=
(1); background: rgb(255, 255, 255); border: 1px solid rgb(86, 189, 91); bo=
rder-radius: 5px; box-shadow: rgba(0, 10, 1, 0.06) 0px 4px 12px 0px; cursor=
: pointer; z-index: 1000; font-family: euclid_circular; color: rgb(37, 38, =
94); }

.notification-error { border: 1px solid rgb(227, 76, 76); }

.notification-message-wrapper { display: flex; align-items: center; height:=
 100%; width: max-content; }

.notification-show { display: flex; transform: translate(-50%, 0%) scale(1)=
; opacity: 1; animation: 0.3s ease 0s 1 normal forwards running notificatio=
nFadeIn; }

.notification-message { font-size: 16px; line-height: 24px; font-weight: 50=
0; padding: 12px 0px 12px 8px; margin: 0px; }

.notification-close { display: flex; animation: 0.3s ease 0s 1 normal backw=
ards running notificationFadeOut; }

@keyframes notificationFadeIn {=20
  0% { opacity: 0; transform: translate(-50%, 200%) scale(1); }
  100% { opacity: 1; transform: translate(-50%, 0%) scale(1); }
}

@keyframes notificationFadeOut {=20
  0% { opacity: 1; transform: translate(-50%, 0%) scale(1); }
  100% { opacity: 0; transform: translate(-50%, 200%) scale(1); }
}

.dark-mode .share-button { border: 1px solid rgba(255, 255, 255, 0.2); back=
ground: none; color: rgb(255, 255, 255); }

.dark-mode .share-icon path { fill: none; stroke: white; }

.dark-mode .modal-content { background: rgb(45, 47, 52); }

.dark-mode .modal-header { color: rgba(255, 255, 255, 0.87); }

.dark-mode .close-modal path { stroke: rgb(255, 255, 255); }

.dark-mode .share-code-container { background: none; border: 1px solid rgba=
(255, 255, 255, 0.2); }

.dark-mode .share-code-value { color: rgba(255, 255, 255, 0.87); }

.dark-mode .progress-bar { background: rgba(255, 255, 255, 0.2); }

.dark-mode .notification { background: rgb(28, 33, 48); color: rgb(255, 255=
, 255); }

.dark-mode .check-icon-wrapper { background-color: rgba(255, 255, 255, 0.2)=
; }

.dark-mode .close-modal-notification path { stroke: rgb(255, 255, 255); }

.dark-mode .header { border-bottom: 1px solid rgba(255, 255, 255, 0.2); }

.dark-mode .social-wrapper span { color: rgba(255, 255, 255, 0.87); }

.dark-mode .social-icon svg { fill: transparent; }

.dark-mode .social-icon path { stroke: rgba(255, 255, 255, 0.7); }

.dark-mode .social-icon { border-color: rgba(255, 255, 255, 0.7); }

.dark-mode .social-icon path { stroke: none; fill: rgba(255, 255, 255, 0.7)=
; }

.dark-mode .social-icon:hover path { fill: rgba(255, 255, 255, 0.87); }

.dark-mode .social-icon:hover { border-color: rgba(255, 255, 255, 0.87); }

@media screen and (min-width: 800px) {
  .share-button { display: none; }
  .tablet-share { display: flex; }
  .modal-body { padding: 0px 32px 32px; }
  .modal-header { padding: 32px 32px 24px; }
  .share-code-copy-btn { margin-top: 24px; }
  .notification-message { padding: 8px 0px 8px 8px; }
  .check-icon-wrapper { padding: 10px 8px; }
  .modal-title { display: block; }
  .modal-title-mob { display: none; }
  .modal-content { width: 420px; }
}

@media screen and (min-width: 1200px) {
  .share-button { display: flex; }
  .tablet-share { display: none; }
}
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/svg+xml
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/assets/logos/logo.svg

<svg width=3D"67" height=3D"23" viewBox=3D"0 0 67 23" fill=3D"none" xmlns=
=3D"http://www.w3.org/2000/svg">
  <path d=3D"M1.22266 9.23052C1.22266 9.0635 1.31152 8.90909 1.45594 8.8251=
8L4.52074 7.04445C4.677 6.95366 4.87289 7.0664 4.87289 7.24712V20.1429C4.87=
289 20.2325 4.80026 20.3052 4.71066 20.3052H1.38489C1.29529 20.3052 1.22266=
 20.2325 1.22266 20.1429V9.23052Z" fill=3D"url(#paint0_linear)"/>
  <path d=3D"M1.22266 8.69978C1.22266 8.64185 1.25355 8.58832 1.3037 8.5593=
3L4.62947 6.63681C4.73762 6.57429 4.87289 6.65234 4.87289 6.77726L4.87289 1=
3.41C4.87289 13.5444 4.76394 13.6534 4.62954 13.6534H1.46601C1.33161 13.653=
4 1.22266 13.5444 1.22266 13.41V8.69978Z" fill=3D"url(#paint1_linear)"/>
  <path d=3D"M10.4456 6.44008L1.54846 11.5486C1.34693 11.6643 1.22266 11.87=
89 1.22266 12.1113V15.9043L10.8502 10.3457C11.0509 10.2298 11.1746 10.0156 =
11.1746 9.78376V6.86215C11.1746 6.48801 10.77 6.25378 10.4456 6.44008Z" fil=
l=3D"url(#paint2_linear)"/>
  <path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M1.61523 15.6775C1=
.38174 15.8033 1.22305 16.0501 1.22305 16.3339C1.22305 16.3357 1.22306 16.3=
376 1.22307 16.3394L1.22305 16.3394V15.4551L1.61523 15.6775Z" fill=3D"#6501=
E5"/>
  <path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M10.8282 10.3607C1=
0.8605 10.2836 10.8784 10.1989 10.8784 10.11C10.8784 9.97192 10.8352 9.8439=
1 10.7617 9.73871L11.1766 9.50391V9.78483C11.1766 10.0165 11.0531 10.2306 1=
0.8525 10.3466L10.8282 10.3607Z" fill=3D"#9327FE"/>
  <path d=3D"M10.7672 9.7484C10.656 9.4064 4.95061 5.57376 1.02363 2.91872C=
0.891136 2.82914 0.9553 2.62274 1.11523 2.62274L5.79227 2.62271C5.82518 2.6=
2271 5.85731 2.63271 5.8844 2.6514L10.8964 6.10918C11.072 6.23032 11.1768 6=
.43001 11.1768 6.64333L11.1768 9.51035L10.7672 9.7484Z" fill=3D"#9327FE"/>
  <path d=3D"M13.5151 13.2919C13.3789 13.2507 13.1746 13.2232 12.9703 13.22=
32C12.4254 13.2232 11.5673 13.4429 11.2132 14.2116V13.2919H9.21094V20.1147H=
11.2813V17.1357C11.2813 15.7766 12.0304 15.2824 12.8613 15.2824C13.0656 15.=
2824 13.2835 15.2962 13.5151 15.3511V13.2919Z" fill=3D"#0556F3"/>
  <path d=3D"M17.7967 18.3987C17.0203 18.3987 16.2712 17.8358 16.2712 16.69=
64C16.2712 15.5433 17.0203 15.0079 17.7967 15.0079C18.5867 15.0079 19.3222 =
15.5433 19.3222 16.6964C19.3222 17.8496 18.5867 18.3987 17.7967 18.3987ZM17=
.7967 13.0859C15.7808 13.0859 14.2008 14.5823 14.2008 16.6964C14.2008 18.81=
05 15.7808 20.3206 17.7967 20.3206C19.8262 20.3206 21.3926 18.8105 21.3926 =
16.6964C21.3926 14.5823 19.8262 13.0859 17.7967 13.0859Z" fill=3D"#0556F3"/=
>
  <path d=3D"M22.2485 20.4991C22.4392 21.7209 23.6787 22.9289 25.6265 22.92=
89C28.1599 22.9289 29.2496 21.2267 29.2496 19.2636V13.2919H27.2746V14.0194C=
27.0839 13.6625 26.4982 13.1683 25.3949 13.1683C23.5425 13.1683 22.2485 14.=
7058 22.2485 16.5042C22.2485 18.3987 23.597 19.8264 25.3949 19.8264C26.3756=
 19.8264 26.9613 19.4283 27.2065 19.0576V19.3734C27.2065 20.6089 26.5663 21=
.1168 25.5311 21.1168C24.7547 21.1168 24.2099 20.6364 24.0737 19.9774L22.24=
85 20.4991ZM25.7763 18.0143C24.9454 18.0143 24.3189 17.4377 24.3189 16.5042=
C24.3189 15.5707 24.9999 14.9941 25.7763 14.9941C26.5527 14.9941 27.2201 15=
.5707 27.2201 16.5042C27.2201 17.4377 26.6208 18.0143 25.7763 18.0143Z" fil=
l=3D"#0556F3"/>
  <path d=3D"M35.3029 13.2919C35.1667 13.2507 34.9624 13.2232 34.7581 13.22=
32C34.2133 13.2232 33.3552 13.4429 33.001 14.2116V13.2919H30.9988V20.1147H3=
3.0691V17.1357C33.0691 15.7766 33.8183 15.2824 34.6491 15.2824C34.8534 15.2=
824 35.0714 15.2962 35.3029 15.3511V13.2919Z" fill=3D"#0556F3"/>
  <path d=3D"M36.2034 18.234C36.2034 19.3185 37.0615 20.3069 38.5462 20.306=
9C39.4451 20.3069 40.0989 19.9225 40.4531 19.3459C40.4531 19.8127 40.5075 2=
0.0598 40.5212 20.1147H42.3872C42.3736 20.0461 42.3055 19.593 42.3055 19.05=
76V15.7217C42.3055 14.3215 41.5019 13.0859 39.3089 13.0859C37.3203 13.0859 =
36.4213 14.3764 36.3396 15.3511L38.1375 15.7217C38.1784 15.2138 38.5734 14.=
7196 39.2953 14.7196C39.9491 14.7196 40.2896 15.0628 40.2896 15.4609C40.289=
6 15.6943 40.167 15.8727 39.7993 15.9276L38.2056 16.1747C37.0887 16.3395 36=
.2034 17.0259 36.2034 18.234ZM39.0501 18.7968C38.4781 18.7968 38.2465 18.45=
36 38.2465 18.0967C38.2465 17.6162 38.5734 17.4103 39.0093 17.3416L40.2896 =
17.1357V17.4377C40.2896 18.4948 39.6631 18.7968 39.0501 18.7968Z" fill=3D"#=
0556F3"/>
  <path d=3D"M46.1179 20.1147V16.1885C46.1179 15.5707 46.5129 15.0079 47.23=
48 15.0079C47.9839 15.0079 48.3245 15.5158 48.3245 16.161V20.1147H50.3676V1=
6.1747C50.3676 15.5707 50.7626 15.0079 51.4981 15.0079C52.2336 15.0079 52.5=
741 15.5158 52.5741 16.161V20.1147H54.5764V15.6943C54.5764 13.841 53.3505 1=
3.0859 52.0702 13.0859C51.1576 13.0859 50.5038 13.388 49.9726 14.1567C49.63=
2 13.4841 48.9374 13.0859 47.9703 13.0859C47.2348 13.0859 46.3631 13.4703 4=
6.0226 14.0744V13.2919H44.0475V20.1147H46.1179Z" fill=3D"#0556F3"/>
  <path d=3D"M66.8048 20.1147V18.3163H63.6312L66.7503 15.0079V13.2919H61.20=
67V15.0765H64.1079L61.125 18.2751V20.1147H66.8048Z" fill=3D"#0556F3"/>
  <path d=3D"M58.8258 20.1006H56.4453L57.1456 15.6276H56.4453V13.1348H59.52=
19V15.6276L58.8258 20.1006Z" fill=3D"#065AFF"/>
  <path d=3D"M59.5219 8.63086H56.4453V11.5804H59.5219V8.63086Z" fill=3D"#06=
5AFF"/>
  <defs>
  <linearGradient id=3D"paint0_linear" x1=3D"3.04777" y1=3D"18.906" x2=3D"3=
.04777" y2=3D"12.7476" gradientUnits=3D"userSpaceOnUse">
  <stop stop-color=3D"#00A3FF"/>
  <stop offset=3D"1" stop-color=3D"#0597EA"/>
  </linearGradient>
  <linearGradient id=3D"paint1_linear" x1=3D"3.04777" y1=3D"12.9454" x2=3D"=
3.04777" y2=3D"9.82901" gradientUnits=3D"userSpaceOnUse">
  <stop stop-color=3D"#00A3FF"/>
  <stop offset=3D"1" stop-color=3D"#0597EA"/>
  </linearGradient>
  <linearGradient id=3D"paint2_linear" x1=3D"4.36325" y1=3D"11.8282" x2=3D"=
11.8543" y2=3D"7.6255" gradientUnits=3D"userSpaceOnUse">
  <stop stop-color=3D"#6501E5"/>
  <stop offset=3D"1" stop-color=3D"#5F01D8"/>
  </linearGradient>
  </defs>
</svg>=0A
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/svg+xml
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/assets/icons/check.svg

<svg width=3D"20" height=3D"20" viewBox=3D"0 0 20 20" fill=3D"none" xmlns=
=3D"http://www.w3.org/2000/svg">
<g clip-path=3D"url(#clip0_13050_2098)">
<path d=3D"M18.3334 9.2333V9.99997C18.3323 11.797 17.7504 13.5455 16.6745 1=
4.9848C15.5985 16.4241 14.0861 17.477 12.3628 17.9866C10.6395 18.4961 8.797=
74 18.4349 7.11208 17.8121C5.42642 17.1894 3.98723 16.0384 3.00915 14.5309C=
2.03108 13.0233 1.56651 11.24 1.68475 9.4469C1.80299 7.65377 2.49769 5.9469=
1 3.66525 4.58086C4.83281 3.21482 6.41068 2.26279 8.16351 1.86676C9.91635 1=
.47073 11.7502 1.65192 13.3917 2.3833" stroke=3D"#56BD5B" stroke-width=3D"2=
" stroke-linecap=3D"round" stroke-linejoin=3D"round"/>
<path d=3D"M18.3333 3.33337L10 11.675L7.5 9.17504" stroke=3D"#56BD5B" strok=
e-width=3D"2" stroke-linecap=3D"round" stroke-linejoin=3D"round"/>
</g>
<defs>
<clipPath id=3D"clip0_13050_2098">
<rect width=3D"20" height=3D"20" fill=3D"white"/>
</clipPath>
</defs>
</svg>

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/svg+xml
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/assets/icons/play.svg

<svg width=3D"18" height=3D"18" viewBox=3D"0 0 14 14" fill=3D"none" xmlns=
=3D"http://www.w3.org/2000/svg">
<path fill-rule=3D"evenodd" clip-rule=3D"evenodd" d=3D"M2.91675 1.75L11.083=
4 7L2.91675 12.25V1.75Z" stroke=3D"#fff" stroke-width=3D"1.4" stroke-lineca=
p=3D"round" stroke-linejoin=3D"round"/>
</svg>=0A
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/x-icon
Content-Transfer-Encoding: base64
Content-Location: https://ad.doubleclick.net/favicon.ico?ad=300x250&ad_box_=1&adnet=1&showad=1&size=250x250

AAABAAIAEBAQAAAAAAAoAQAAJgAAACAgEAAAAAAA6AIAAE4BAAAoAAAAEAAAACAAAAABAAQAAAAA
AMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgAAAAgAAAA
QAAAAAEABAAAAAAAgAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAA////AAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERER
EREREREREREREREREREREREREREREREREREREREREREREREREREAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://ad-delivery.net/px.gif?ch=2

R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://ad-delivery.net/px.gif?ch=1&e=0.6596782708559272

R0lGODlhAQABAIABAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://map.go.affec.tv/map/af/?gdpr=0&gdpr_consent=

R0lGODlhAQABAIEAAAAAAP///wAAAAAAACH/C05FVFNDQVBFMi4wAwEBAAAh+QQBAAAAACwAAAAA
AQABAAAIBAABBAQAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://ids.ad.gt/api/v1/halo_match?id=AU1D-0100-001723735934-NMFNT6K9-3UFX&halo_id=060ixdlj2g5ihhf7hh6hej6l96f97gdclcfuok0wsqyusso2ss0smw0060o62qki0

R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://secure.adnxs.com/getuid?https://ids.ad.gt/api/v1/match?id=AU1D-0100-001723735934-NMFNT6K9-3UFX&adnxs_id=$UID&gdpr=0

R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://match.adsrvr.org/track/cmf/generic?ttd_pid=8gkxb6n&ttd_tpi=1&ttd_puid=AU1D-0100-001723735934-NMFNT6K9-3UFX&gdpr=0

R0lGODlhAQABAIEAAAAAAP///wAAAAAAACH/C05FVFNDQVBFMi4wAwEBAAAh+QQBAAAAACwAAAAA
AQABAAAIBAABBAQAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://pixel.tapad.com/idsync/ex/receive?partner_id=3185&partner_device_id=AU1D-0100-001723735934-NMFNT6K9-3UFX&partner_url=https://ids.ad.gt%2Fapi%2Fv1%2Ftapad_match%3Fid%3DAU1D-0100-001723735934-NMFNT6K9-3UFX%26tapad_id%3D%24%7BTA_DEVICE_ID%7D

R0lGODlhAQABAIEAAAAAAP///wAAAAAAACH/C05FVFNDQVBFMi4wAwEBAAAh+QQBAAAAACwAAAAA
AQABAAAIBAABBAQAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://cm.g.doubleclick.net/pixel?google_nid=audigent_w_appnexus_3985&google_cm&google_sc&google_ula=450542624&id=AU1D-0100-001723735934-NMFNT6K9-3UFX

R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://ids.ad.gt/api/v1/g_hosted?id=AU1D-0100-001723735934-NMFNT6K9-3UFX

R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://bh.contextweb.com/bh/rtset?pid=562316&ev=1&rurl=https://ids.ad.gt/api/v1/ppnt_match?uid=%%VGUID%%&id=AU1D-0100-001723735934-NMFNT6K9-3UFX

R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-40C86FC232A058D88E8088940EB9A412@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7E5C96CC321A17378436B990F7358ABE@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-753A90125A6A4804D3FF17CF90B1D9AA@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-34EF3D17C72F4BEE9EB20CD7BD3453DB@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://securepubads.g.doubleclick.net/static/topics/topics_frame.html

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8">
   =20
    <title>Topics Frame</title>
    <meta http-equiv=3D"origin-trial" content=3D"Avh5Ny0XEFCyQ7+oNieXskUrqY=
8edUzL5/XrwKlGjARQHW4TFRK+jVd5HnDIpY20n5OLHfgU4ku7x48N3uhG/A0AAABxeyJvcmlna=
W4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRi=
b3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=3D">
   =20
  </head>
  <body>

</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1423F97FE772962D01A36045687ED1E7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://s.amazon-adsystem.com/iu3?cm3ppd=1&d=dtb-pub&csif=t&gdpr=0&dl=gg_n-mediagrid_n-index_n-Ogury_rx_n-MediaNet_n-Beeswax_ox-db5_smrt_n-inmobi_n-smaato_n-sharethrough_n-onetag_pm-db5_ym_rbd_n-baidu_n-nativo_an-db5_3lift_n-Outbrain&dcc=t

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body style=3D"background-color:transparent">
</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F1FEE684B178B81817B4219D51A810FB@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://google-bidout-d.openx.net/w/1.0/pd?cc=1&plm=5

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"><title>Pixels</title></head>
<body>






</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-ABBD622202A0505868D8DA373100903B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1827F13A7196CBF45504DF6212DCF96D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.google.com/recaptcha/api2/aframe

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8"></head><body><img src=3D"https://pagead2.googlesyn=
dication.com/pagead/sodar?id=3Dsodar2&amp;v=3D225&amp;li=3Dgpt_m20240812010=
1&amp;jk=3D947972206008144&amp;rc=3D"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7BE298A433BBB81A21C07AA093855348@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://proton.ad.gt/join-ad-interest-groups.html

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8">
   =20
    <meta name=3D"viewport" content=3D"width=3Ddevice-width,initial-scale=
=3D1">
    <meta http-equiv=3D"origin-trial" content=3D"A7EJXd+QZ2JL/N8k85e+yMFGsI=
kETopEYjLMJjZMUYg51sgbRqLKdhW9nOiyEdVwWCOq8YRHOx+w9GQ8D9HqeAoAAACCeyJvcmlna=
W4iOiJodHRwczovL2F1ZGlnZW50LmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hB=
ZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFB=
hcnR5Ijp0cnVlfQ=3D=3D">
    <title>Audigent Proton</title>
   =20
</head>

<body>


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-99CF2FCA807332D454B252FF71234AB4@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://hb.360yield.com/privacy-sandbox/topics.html?bidder=improvedigital

<!DOCTYPE html><html lang=3D"en"><head><meta http-equiv=3D"Content-Type" co=
ntent=3D"text/html; charset=3DUTF-8">
  <title>ImproveDigital Topics API</title>
 =20
 =20
</head>

<body>



</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A88B88DB10C2650DB029CDBE7AACD864@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/topics/topics_frame.html?bidder=pubmatic

<!DOCTYPE html><html lang=3D"en"><head><meta http-equiv=3D"Content-Type" co=
ntent=3D"text/html; charset=3DUTF-8">
  <title>Topics demo</title>
 =20
  <meta http-equiv=3D"X-UA-Compatible" content=3D"IE=3Dedge">
  <meta name=3D"viewport" content=3D"width=3Ddevice-width, initial-scale=3D=
1">
  <meta http-equiv=3D"origin-trial" content=3D"AseYc2DtZGb//W5XVWgcoP6UF3L+=
dzpvN5W30ZfyW0aY9GPRVT9CgZXlFz8KHt25ohltfnkuImnAY3JETFGc+AgAAABfeyJvcmlnaW4=
iOiJodHRwczovL2Fkcy5wdWJtYXRpYy5jb206NDQzIiwiZmVhdHVyZSI6IlByaXZhY3lTYW5kYm=
94QWRzQVBJcyIsImV4cGlyeSI6MTY4ODA4MzE5OX0=3D">
  <link href=3D"https://ads.pubmatic.com/AdServer/js/topics/favicon.ico" re=
l=3D"shortcut icon">
 =20
</head>

<body>


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-DA0014676C190E975A99495C12CED1C7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-3C64C6EC12962B874F58CCBFD6BCE3E8@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://onetag-sys.com/usync/?redir=https%3A%2F%2Fpbs.360yield.com%2Fsetuid%3Fbidder%3Donetag%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26gpp%3D%26gpp_sid%3D%26f%3Db%26uid%3D%24%7BUSER_TOKEN%7D&gdpr=0&gdpr_consent=&us_privacy=1---

<!DOCTYPE html><html lang=3D"en"><head><meta http-equiv=3D"Content-Type" co=
ntent=3D"text/html; charset=3DUTF-8">
   =20
    <title>Sync Pixels</title>
</head>
<body marginwidth=3D"0" marginheight=3D"0">




</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7707D9B67579AE0DF229B3885D02B8A6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-D5F0A1A5D8F8E93397B90898082436B6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ssum-sec.casalemedia.com/usermatch?cb=https%3A%2F%2Fpbs.360yield.com%2Fsetuid%3Fgpp%3D%26gpp_sid%3D%26bidder%3Dix%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26gpp%3D%26gpp_sid%3D%26f%3Db%26uid%3D&gdpr=0&gdpr_consent=&gpp=&gpp_sid=&s=184674&us_privacy=1---&C=1

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"><title></title></head><body marginwidth=3D"0" marginheight=
=3D"0"><img src=3D"https://pbs.360yield.com/setuid?gpp=3D&amp;gpp_sid=3D&am=
p;gpp=3D&amp;gpp_sid=3D&amp;bidder=3Dix&amp;gdpr=3D0&amp;gdpr_consent=3D&am=
p;us_privacy=3D1---&amp;gpp=3D&amp;gpp_sid=3D&amp;f=3Db&amp;uid=3D0" style=
=3D"display:none" width=3D"0" height=3D"0" alt=3D"" border=3D"0"></body></h=
tml>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-FEC3155B3327F31688570803CFCBB50E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-65661AB2092DCCFAC6FF3B7BEE045F5A@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://contextual.media.net/checksync.php?vsSync=1&cs=8&cv=31&https=1&cid=8CUQ257TE&prvid=2034%2C2033%2C2031%2C2030%2C590%2C233%2C2028%2C2027%2C236%2C313%2C237%2C117%2C319%2C97%2C55%2C99%2C3012%2C3010%2C244%2C201%2C2039%2C3007%2C246%2C4%2C203%2C9%2C2012%2C2055%2C172%2C3020%2C251%2C175%2C450%2C2009%2C178%2C3018%2C3017%2C214%2C459%2C70%2C77%2C20000%2C38%2C2023%2C2022%2C261%2C141%2C262%2C460%2C461%2C462%2C222%2C10000%2C80%2C108&itype=PREBID&purpose1=1&gdprconsent=1&gdpr=0&coppa=0&usp_status=0&usp_consent=1&uspstring=1---

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head> <body marginwidth=3D"0" marginheight=3D"0"> </body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-E15B7F9A3811E8D1F7C0DC85C90FBB07@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://eus.rubiconproject.com/usync.html?gdpr=0&us_privacy=1---

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.=
w3.org/TR/html4/loose.dtd"><!-- Copyright Magnite 2024 --><html><head><meta=
 http-equiv=3D"Content-Type" content=3D"text/html; charset=3DUTF-8">
    <title>User-Sync</title>
</head>
<body marginwidth=3D"0" marginheight=3D"0">
   =20


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-CB6E51A051D15D65D421FBC8634306EE@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://js-sec.indexww.com/um/ixmatch.html

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0">=
</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A7933880E1923E671DADE7CA34BD55F0@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://acdn.adnxs.com/dmp/async_usersync.html

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3Dwindows-1252">
</head>
<body marginwidth=3D"0" marginheight=3D"0">


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-35476F854166569CD78D6388C5CA59BC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://cs.seedtag.com/cs.html?pt=8390-3245-01&pc=IN&cmp=true&us=1---&uid=8bdc5393-56c6-413b-8265-2a315757dd7b

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=
=3D"0">  <img width=3D"1" height=3D"1" src=3D"https://s.seedtag.com/cs/st/s=
"><img width=3D"1" height=3D"1" src=3D"https://secure.adnxs.com/getuid?http=
s%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fappnexus%3Fchanneluid%3D%24UID"=
><img width=3D"1" height=3D"1" src=3D"https://sync.smartadserver.com/getuid=
?gdpr_consent=3D&amp;us_privacy=3D1---&amp;nwid=3D3050&amp;url=3Dhttps%3A%2=
F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fsmart%3Fchanneluid%3D%5Bsas_uid%5D"><=
img width=3D"1" height=3D"1" src=3D"https://b1sync.zemanta.com/usersync/see=
dtag?puid=3D8bdc5393-56c6-413b-8265-2a315757dd7b&amp;gdpr=3D0&amp;gdpr_cons=
ent=3D&amp;us_privacy=3D1---&amp;cb=3Dhttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fco=
okiesync%2Foutbrain%3Fchanneluid%3D__ZUID__"><img width=3D"1" height=3D"1" =
src=3D"https://match.adsrvr.org/track/cmf/generic?ttd_pid=3D5jrh0rv&amp;ttd=
_tpi=3D1&amp;gdpr=3D0&amp;gdpr_consent=3D&amp;us_privacy=3D1---"><iframe sr=
c=3D"cid:frame-03A216DC1E3FEE2C88015B0E64D722B6@mhtml.blink" scrolling=3D"n=
o" frameborder=3D"0" width=3D"0" height=3D"0" style=3D"margin: 0px; padding=
: 0px; display: none; width: 0px; height: 0px;"></iframe><img width=3D"1" h=
eight=3D"1" src=3D"https://x.bidswitch.net/sync?ssp=3Dseedtag&amp;user_id=
=3D8bdc5393-56c6-413b-8265-2a315757dd7b&amp;gdpr=3D0&amp;gdpr_consent=3D&am=
p;us_privacy=3D1---"><iframe src=3D"cid:frame-CD9CE534A494EDE420FBB3C308E65=
58D@mhtml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0=
" style=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0p=
x;"></iframe><iframe src=3D"cid:frame-16A1475035ABAE428ACF8E198AD4669B@mhtm=
l.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" style=
=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;"></i=
frame><img width=3D"1" height=3D"1" src=3D"https://sync.richaudience.com/f7=
872c90c5d3791e2b51f7edce1a0a5d/?p=3Dns9qrKJLKD&amp;consentString=3D&amp;r=
=3Dhttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Frichaudience%3Fchannelui=
d%3D%5BPDID%5D"><iframe src=3D"cid:frame-B9DFCD084E23FB77884C45C86187A269@m=
html.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" sty=
le=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;"><=
/iframe><img width=3D"1" height=3D"1" src=3D"https://ad.360yield.com/server=
_match?partner_id=3D1680&amp;r=3Dhttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookies=
ync%2Fimprovedigital%3Fchanneluid%3D%7BPUB_USER_ID%7D"><img width=3D"1" hei=
ght=3D"1" src=3D"https://ssum-sec.casalemedia.com/usermatchredir?s=3D191730=
&amp;cb=3Dhttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Findexexchange%3Fc=
hanneluid%3D"><iframe src=3D"cid:frame-1F927622FAF42D253C8D6A6A6EBFA345@mht=
ml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" style=
=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;"></i=
frame><iframe src=3D"cid:frame-7D4A94A5BF2582648BC296D4D3CED912@mhtml.blink=
" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" style=3D"marg=
in: 0px; padding: 0px; display: none; width: 0px; height: 0px;"></iframe><i=
mg width=3D"1" height=3D"1" src=3D"https://cm.adform.net/cookie?redirect_ur=
l=3Dhttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fadform%3Fchanneluid%3D%=
24UID"><img width=3D"1" height=3D"1" src=3D"https://ap.lijit.com/pixel?gdpr=
=3D0&amp;gdpr_consent=3D&amp;us_privacy=3D1---&amp;redir=3Dhttps%3A%2F%2Fs.=
seedtag.com%2Fcs%2Fcookiesync%2Fsovrn%3Fchanneluid%3D%24UID"><iframe src=3D=
"cid:frame-94E743DEFC9006B44877629AC34D4644@mhtml.blink" scrolling=3D"no" f=
rameborder=3D"0" width=3D"0" height=3D"0" style=3D"margin: 0px; padding: 0p=
x; display: none; width: 0px; height: 0px;"></iframe><img width=3D"1" heigh=
t=3D"1" src=3D"https://u.openx.net/w/1.0/cm?id=3De297ef35-c932-4587-9b44-38=
38020a33e7&amp;gdpr=3D0&amp;gdpr_consent=3D&amp;us_privacy=3D1---&amp;r=3Dh=
ttps%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fopenx%3Fchanneluid%3D%7BOPEN=
X_ID%7D"><img width=3D"1" height=3D"1" src=3D"https://creativecdn.com/cm-no=
tify?pi=3Dseedtag"><iframe src=3D"cid:frame-97BB4A7B9D400C120D2124352F72D08=
4@mhtml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" =
style=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;=
"></iframe><img width=3D"1" height=3D"1" src=3D"https://t.adx.opera.com/pub=
/sync?pubid=3Dpub9283744565120"><iframe src=3D"cid:frame-C96B4FB2B000EE5192=
91C75CEBA1E7CA@mhtml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" =
height=3D"0" style=3D"margin: 0px; padding: 0px; display: none; width: 0px;=
 height: 0px;"></iframe><iframe src=3D"cid:frame-08106324CBA18E2F03F0082997=
2CABCE@mhtml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=
=3D"0" style=3D"margin: 0px; padding: 0px; display: none; width: 0px; heigh=
t: 0px;"></iframe><iframe src=3D"cid:frame-37B91C19A024614E65799007253AF571=
@mhtml.blink" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" s=
tyle=3D"margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;"=
></iframe><iframe src=3D"cid:frame-35B7E4867095D21706C7D5B98C1E7544@mhtml.b=
link" scrolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" style=3D"=
margin: 0px; padding: 0px; display: none; width: 0px; height: 0px;"></ifram=
e><iframe src=3D"cid:frame-20B65E073520220D12DB665E6A13A372@mhtml.blink" sc=
rolling=3D"no" frameborder=3D"0" width=3D"0" height=3D"0" style=3D"margin: =
0px; padding: 0px; display: none; width: 0px; height: 0px;"></iframe></body=
></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://b1sync.zemanta.com/usersync/seedtag?puid=8bdc5393-56c6-413b-8265-2a315757dd7b&gdpr=0&gdpr_consent=&us_privacy=1---&cb=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Foutbrain%3Fchanneluid%3D__ZUID__

R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://match.adsrvr.org/track/cmf/generic?ttd_pid=5jrh0rv&ttd_tpi=1&gdpr=0&gdpr_consent=&us_privacy=1---

R0lGODlhAQABAIEAAAAAAP///wAAAAAAACH/C05FVFNDQVBFMi4wAwEBAAAh+QQBAAAAACwAAAAA
AQABAAAIBAABBAQAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://x.bidswitch.net/sync?ssp=seedtag&user_id=8bdc5393-56c6-413b-8265-2a315757dd7b&gdpr=0&gdpr_consent=&us_privacy=1---

R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://ad.360yield.com/server_match?partner_id=1680&r=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fimprovedigital%3Fchanneluid%3D%7BPUB_USER_ID%7D

R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://cm.adform.net/cookie?redirect_url=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fadform%3Fchanneluid%3D%24UID

R0lGODlhAQABAID/AP///wAAACwAAAAAAQABAAACAkQBADs=

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-Transfer-Encoding: base64
Content-Location: https://creativecdn.com/cm-notify?pi=seedtag

R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-35FA648E14294CDDD9C3654D436F5C04@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://eb2.3lift.com/sync?us_privacy=1---&&ld=1

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-769996090EF9131946D126AADA38C275@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://cookies.nextmillmedia.com/sync?gdpr=0&gdpr_consent=&us_privacy=1---&gpp=&gpp_sid=&type=iframe

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"><iframe =
width=3D"1" height=3D"1" src=3D"cid:frame-E3D4CF2BD8C9FBB31FF681B5D895413A@=
mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-A81B6AF1E6E306B3494CA3D4D=
4C63DD3@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-E83CA299C8F36B52AA0A7CB8B=
6459E49@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-A4E0DADD1999BF1EBA55E9152=
D230BD7@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-8053950A21E3548872E5BB87F=
B37685B@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-11D2A7D62CE0DF2AEE4E3D0F0=
582827D@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-57F2AB50BE1E880E73721C8D8=
820BF9C@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-D826CBEF07E6ED4C16794EF11=
BBCDCFC@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-732E8870E44D2DB4CCB7AAE65=
8FC1279@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-4CFAE9391EFA35B60BB12B905=
FE71035@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-17C2E5790FB4D824A129FE644=
1EBF1B1@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-F126C0FAF0F66BE156B54198B=
58EFEED@mhtml.blink"></iframe>

<iframe width=3D"1" height=3D"1" src=3D"cid:frame-9818D5E81D03B69CD972BF2A1=
A9DDC39@mhtml.blink"></iframe>

</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9A555A3B66228A4F4AE527D1766F596A@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-BAD047985285C027D7D03E91260EB733@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9245089902055A37884624D460C9EFC7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-646822F8F73B28EF2B76EEA2DD6DD6A4@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-992DBF9498E565D3EE9FB89234E96F63@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-29D06BD1E0CD6D8B93D2465339CD101C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F9D46392EE8615A81E0157AB3E5295CA@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-DFD4BF3F67F331FE603B0D90606ABE2C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-837D4EFF4945DA1533A7C8865C27EFCC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-C224FCCFB9CDC3E75E48730D16AAE178@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-D63248D9298BE0DF98413034754FF985@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1B8D62A8070E79B5470FD683DD6A186A@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-09C3D90B56B65A8B16C1E9E1F25516EF@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-8C26ECD5FA4CADA440DEF981B0BAE4ED@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-41C7EAF92BABB7AA8EF0A7BD35BEB3CF@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1C3954CD9B68408B0457A7DA8B78A2AB@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-651D87D02EFD047D010CD4441D027A86@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-5CF617ED8BE5042592D1C4A6EA962F4B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-11E5114EF9C61A82B789E1A92FCB42DC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-62A9ACB843ABFFD32A1034004B08B1A5@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B44845AD5AE6A428A5FAA7A44B1082B0@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-C6CAB7880E7C630093C2494E37928EE0@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-8E34079C2D279ED6931A5D2B69F63745@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9C5D8CB3F60704CB44277D520E8824A9@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-D84153091AE9B95CD2E8D9547F64AC3B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-FBCF4B98D4C1B580FB18F06523D6CA5F@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-3F0A984BC9723CEE4CF36C47C068CEFC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-10671928BF77DF29433AA737F4F3EB49@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-064FCFFCC483209633CFFF5EF232590D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-21A2CBAEFD763551C821C97F963A6EDE@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1C61D870FDCE9178D57332796CC11383@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-06545DB342B29FC0AA043883F4E0B6D2@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-383A329D2B6032FD3ADCA17581472074@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-BDCBD27C9A7784C6DBE73A2BD28E9DF1@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-E05161F22B8FA939F2B4703B12B8C8A9@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-4278F4C50C422268BE84801EC0B1D4F6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B24F105A63538E0CF966CF5F76C9D313@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-5EB772346610B23DF663AADE9801CE86@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-833E3B7E05F904FF75330F32C4A79D0F@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-39290B827513EF85ED8D8FA2B324EE93@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-109553C830007B4CBC1F6C8B712FA6B4@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-6959FE2375ACABCE540A30A8CC1058EC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-987FCE8780539624B463C5AF458B84D7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-8F7C6CDAFE059994F3044C6778314DF1@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-642A7BBA7F595DBEF76D1DC317544789@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-14C0E7338B339EC24B87B44A4B301511@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-3B192B0382788E5C7B3BC7490FEC5EA2@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-3036B8B3981CD5BB2C659EABBE315675@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-5331F66FA34126401A452B76DF91BF69@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-248016EF4C242365629FBB23471B3337@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-6DC22295DE986E744246ABE29A01165D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-4A287824CF980A23EDF459CF610B23E7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F6D7D1C13B8A2ACF2B244B1D872EE4EA@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-593DAE6B01DE859114FA58EDDBBFFC6D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-23385CB84452A6320F5E79C0BC2A38E4@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-37C3850D826BD93C6243125DB1CCCB59@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-DED42709B4A894C996852760271684AB@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=1168525670

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F6218D32FFD35C25CC13A38C9ED05569@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B14F3A571315C9C5AE8F686C0E0E0754@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F88C6839BC41AE357A35DB2B7C55CFB1@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-26AD215BCF1877F95A8897DA60D07C5C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-867490AD7E2D1E4B31834579B2745D8A@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=666436434

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-EBF13ED0D0FEA4ACE43576D485A8BAE3@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-3B5E3E25FC149FFCF74571CE154E4C74@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B3691D86C16746DFA03BBE92F550E165@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-FAFE28AEBE0FCE2EC556CC5B630EA18B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-FE0723B838BDB0E6E56C48E92906C555@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=1999914151

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-BE79E8A395D438618EDB2DD29FE2F47C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-CFAEC694EF2968C92E21B2AB626D8690@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A9E5AB5B43801A47EC6C2F3E4822B920@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-4FFCAD16F6CC071408CC8B90F0A91933@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9A0D43A67972D896112119643227B5D6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=713935804

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B689B01E246F658BD4E23A16D30F2284@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-6982420D125C782AB78A65A107BA918E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-80EC8C1CB5A4ACC6657B7677D9C349F9@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-85EEC758D7C2F8F8FD7AA7BE41825A9D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F1BC884DAFD9DEB9DE9A03E1A8119013@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=112773018

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-2B452CA18ED33C7D35CF2C081FC22B28@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-60A1520B77126F6B646EF6C673CFB34F@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-00482D36E8EAED8497C7B8FA34DD3EC6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7B4C22389397174D9E3A13883BFB795E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9EFAFA7984FC0E0603A467A337EBCC27@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=1224555171

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-C8B37829CCF5C3F25B19C48193868C85@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-54C383E79948FA6802ED74DAB679AD56@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-958A2AE0BF0A63428D8FEDD78EAD6D7E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-EDBEBDA4B9CB74E9A1D51443C4414AEC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-34A35045A5FF0C348FD643A1BAA77DE5@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=1688164941

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B77C3317ED580BB8C07FEFB133EB8884@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-F78A8A5BC417BBC7F7C51E0080F453E8@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-BE8528ABFDB20056BC20C69F270BC595@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-5195928FB0421BFE1B6D5C81884BF8BF@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-0831C6E34210E87B1C1F3E404CADF226@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=344974852

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-0448A905A7CB5843ACD272A31E548237@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-058A07727E6F9EEC856683DD836C8534@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-5487979777C971E0E9D18C21D3BDDA71@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-4DBDAE1290BBE28FCC46083842F88220@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1A182482D386411C40F246542719C817@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=496647450

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1206C3BBBC711C08703CF42488ECBE93@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-2293872226C4D3A360CCEB8BD6AFFE72@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-45C041B9E282111ED0297CB2EE558712@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-106AFABFF718877C6F306B87A5D114E1@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-161F476BE524AC3777A977F755B7D63E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://td.doubleclick.net/td/ga/rul?tid=G-YJM03XN8Q2&gacid=1524554209.1723735931&gtm=45je48e0v877263288za200zb77144609&dma=0&gcs=G111&gcd=13n3n3n3n5&npa=0&pscdl=noapi&aip=1&fledge=1&frm=0&tag_exp=0&z=1653645543

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-EC3A0248064B77403A8B60B8D76B61F6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B8DDD998B8EB922E28D7634588AB95DA@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9DFB3369089204A4EBD29685AF3148F8@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.programiz.com/c-programming/online-compiler/

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3DUTF-8"><meta http-equiv=3D"origin-trial" content=3D"AxjhR=
adLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDG=
j9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZ=
lYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydH=
kiOnRydWV9"><meta http-equiv=3D"origin-trial" content=3D"AxjhRadLCARYRJawRj=
Mjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABve=
yJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJG=
ZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><=
/head><body leftmargin=3D"0" topmargin=3D"0" marginwidth=3D"0" marginheight=
=3D"0"><div class=3D"GoogleActiveViewInnerContainer" id=3D"avic_CJLIvKOv94c=
DFbdynQkdBiI9pQ" style=3D"left:0px;top:0px;width:100%;height:100%;position:=
fixed;pointer-events:none;z-index:-9999;"></div><div style=3D"display:inlin=
e" class=3D"GoogleActiveViewElement" data-google-av-cxn=3D"https://pagead2.=
googlesyndication.com/pcs/activeview?xai=3DAKAOjsu_xXGiry0PuMrXQ4h-2G8BZDde=
hy7NNz8DW1d_G0NIdMBMzsKGsRBf_Dh1T9qfuVeIaViI2t-Sps5JcjzeoYQ3OQZXOsaeY4xSMWJ=
_xv0H-m7HWXBFOf1yCpl1nYs5gBwRRkoJy-Hr-7Oqb6aKkrcoIFE9b3h4bXU&amp;sig=3DCg0A=
rKJSzEFBIiHMjQ0mEAE" data-google-av-adk=3D"3278645191" data-google-av-metad=
ata=3D"la=3D0&amp;xdi=3D0&amp;" data-google-av-ufs-integrator-metadata=3D"C=
pMBCkNtb2RlbF9wZXJzb25fY291bnRyeV9jb2RlX0lOX3BlcnNvbl9yZWdpb25fY29kZV80Nzc1=
NmE2MTcyNjE3NC5qc29uEhpDSkxJdktPdjk0Y0RGYmR5blFrZEJpSTlwURgBIhcItBIQ6Z8BIOj=
XtwQoAjACOAFdzcxMPyifvtPX-f____8BMJ--09cBOANAAUgAEocCCvwBaHR0cHM6Ly9wYWdlYW=
QyLmdvb2dsZXN5bmRpY2F0aW9uLmNvbS9wY3MvYWN0aXZldmlldz94YWk9QUtBT2pzdV94WEdpc=
nkwUHVNclhRNGgtMkc4QlpEZGVoeTdOTno4RFcxZF9HME5JZE1CTXpzS0dzUkJmX0RoMVQ5cWZ1=
VmVJYVZpSTJ0LVNwczVKY2p6ZW9ZUTNPUVpYT3NhZVk0eFNNV0pfeHYwSC1tN0hXWEJGT2YxeUN=
wbDFuWXM1Z0J3UlJrb0p5LUhyLTdPcWI2YUtrcmNvSUZFOWIzaDRiWFUmc2lnPUNnMEFyS0pTek=
VGQklpSE1qUTBtRUFFEgAaACABKAA" data-google-av-override=3D"-1" data-google-a=
v-dm=3D"2" data-google-av-aid=3D"0" data-google-av-naid=3D"1" data-google-a=
v-slift=3D"" data-google-av-cpmav=3D"" data-google-av-btr=3D"https://secure=
pubads.g.doubleclick.net/pcs/view?xai=3DAKAOjsu30WRtdK9sS1uS8c4UWBPCA_JUULk=
TKWGwPhZLxE1AY2zvRcVB0N2C5gASkxAleK-Gbu7___VtxB2wuCJ7sKwil6xWPGVkzy-jZPCzoi=
d8UDeQLpay7iY1HL45Y4szfFd0CMLGXyElB3Fi5sSk8WBm2C9i_WrsqBPvzTOwnlGddMwhYB-9O=
4pgqfwtPZ0XPagMEZg2ujpH1SHCEb6wqGlOeKd_0DskfblCW_jH7abWEdOHndf7r5JdyYquLzhS=
TFSId3pk4eHoBRu-h2uUFuNlPBbj0zuHi-9ESDJdVawv_b9Sj-qeAZgkxvVuqVfWAcXn7WwEhyV=
hYRS2aH7P_dWdQH9tTCDhh_PNq2aNk4FnpbhiiqXe2kN5G_0OeV4xlkXR-l8hFU29ZwSIYg&amp=
;sai=3DAMfl-YQmPSlOnidsmz1LqmuUYVWnh3HG7w2of_IMtLcxbA24yPSAa1NbfwZbE9N-Bm1l=
hFuo9qLngPMlwUtf9g6v2cJwxIzuC8V0zRtt6H6tQXi20c2N-COaxpx5HJ_7YYASTFrTmZ47DRH=
mDItQ5SVHsUdjlMp3XEplzJ3DXBFYuEy32eV__DxFWzT8w06B7nge4tB60PfYDzqUCFmzuB6yMI=
CnEsLvBc2IJc3dYSuA2T_MRg&amp;sig=3DCg0ArKJSzMMB901ue2sCEAE&amp;uach_m=3D%5B=
UACH%5D&amp;urlfix=3D1&amp;adurl=3D" data-google-av-itpl=3D"19" data-google=
-av-rs=3D"4" data-google-av-flags=3D"[&quot;x%278440'9efotm(&amp;753374%2be=
jvf/%27844>'9wuvb$&amp;56533>!=3D|vqc)!273794&amp;<qqvb/%<1735020!=3Dnehu`/=
!364=3D5051!9abk{a($160210:3&amp;<cbotf+*0150034:%2bejvf/%72;17613!=3Defdwa=
*'76463;21$?ebkpb$&amp;0366717>*>bgipf+!3=3D712363%9aihwc)!7202<217'9efotm(=
&amp;20061;48&amp;>`dopb/%<1707200!=3D8(&amp;2005575?&amp;>`dopb/%<170642?!=
=3D|vqc)!7201;=3D50'9wuvb$&amp;03641654*>bgipf+!3=3D731103%9aihwc)!7200?073=
'9efotm(&amp;2004?51;&amp;>`dopb/%<17>474>!=3Dnehu`/!36406412!9abk{a($16774=
5;=3D&amp;<cbotf+*01254133%2pvs`/!36383624!9abk{a($167574>7&amp;<qqvb/%<104=
=3D460!=3Dnehu`/!363;42>7!9abk{a($1656;3?<&amp;<cbotf+*01011776%2bejvf~&quo=
t;]" data-creative-load-listener=3D""> <a href=3D"https://www.programiz.com=
/learn-python?utm_campaign=3Dpubgalaxy-backfill&amp;utm_source=3Dprogramiz-=
unsold-ad&amp;utm_medium=3D728_90_v1_0" target=3D"_blank"><img src=3D"https=
://tpc.googlesyndication.com/simgad/17844661392096460358?" border=3D"0" wid=
th=3D"728" height=3D"90"></a>
 </div><div style=3D"bottom:0;right:0;width:728px;height:90px;background:in=
itial !important;position:absolute !important;max-width:100% !important;max=
-height:100% !important;pointer-events:none !important;image-rendering:pixe=
lated !important;z-index:2147483647;background-image:url('data:image/png;ba=
se64,iVBORw0KGgoAAAANSUhEUgAAACsAAAAWBAMAAACrl3iAAAAABlBMVEUAAAD+AciWmZzWAA=
AAAnRSTlMAApidrBQAAACBSURBVBjTbZGJDcMwDANPG3D/aVs9pq2iSuBYCEOdGfhf0UXk3h2o3=
uYq3a4UPNd8qa9KtdZ+OqvDT7Y3T3dJYpG4pB9urMTeOVqNfYwlE9CWdh7mA1y3sCTNZ9wGmREr=
QeLIYp1rEuxwnhSK5uxuguAkWXnz8PhoDdPg61+2POsDI2oFq2t620cAAAAASUVORK5CYII=3D'=
) !important;"></div><iframe src=3D"cid:frame-0AEAD1453CC5020344FFDE60352E6=
550@mhtml.blink" style=3D"display: none;"></iframe></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/png
Content-Transfer-Encoding: base64
Content-Location: https://tpc.googlesyndication.com/simgad/17844661392096460358?

iVBORw0KGgoAAAANSUhEUgAAAtgAAABaCAYAAACCNCH/AAAAAXNSR0IArs4c6QAAQABJREFUeAHt
XQWYE9cWPknWFZbFbXG3UloKbaFQb6m9upe695Uaj1dXaq/u7i600BaKU6xocfdFlt1l3ZN3/sne
3cnsTDJJJtnscs/3JTNz5+o/9t9zzz3XtmSP00Vhlq7NbJQaG+ZCZXESAYmAbwRytnGcsL8SfNer
UcSwEaV1ahQtkY2QCEgEJAKNDYH8MqJN2dZ9/+zhBiiKS0yR5DrcsMvyJALmEIhNMhdPxvIfAYmt
/5jJFBIBiYBEIEwIlFRaW1DYCXZago1YjyNFIiARiEQEJAkM3VWR2IYOW5mzREAiIBEIEoGSCuu0
16hK+Al2fJAIyOQSAYlA6BCI4gfUHhW6/A/XnIEpsJUiEZAISAQkAhGJQGmlterfsBLshBgbJUZH
JK6yUhIBiYBAQGpaBRLWbSWm1mEpc5IISAQkAhYjAN11g9ZgN0+wVv1uMb4yO4mARAAIxKZIHKxG
QGJqNaIyP4mAREAiYBkC5VVEVrv8CNtYcJTDRmlyhNSym0FmJBEIGQIwZ4hNJiorCFkRh1XGwFKa
3RxWl1w2ViLQmBEoLi6n2fPW0tp1e+hgdj65WHfaplUT6tO7PR07rCfFxoaNWloGc5nFExxRsbCh
kJ7A3xhrzVssA1ZmJBGQCGgQiG8qCbYGkoAPgaUUiYBEQCLQwBGoqKii9z6aQZ98NodKSst1W5OU
FEcXXzCMxl55AiUkxOjGicTA0hAQbFu4/GD3a2mjGEckwirrJBGQCOgiUHSASXah7ikZaBIB2F4n
tjAZWUaTCEgEJAKRiUB5eSXdMe4jWrh4k6kKtmyRSk8/fgkdMbBh+P7flU90oNBaM+awTHJsEkeS
XJu6JWUkiUAEIQDNq00OOwV8RYCd1F4HDJ9MKBGQCEQOAm+8M9U0uUat9x/Io+tveYcm/748chrh
pSalFrvoQ1FhIdgtkuRH2st1lackApGJgJ1d/sQ1icy6NYRaATtgKEUiIBGQCDRgBGBz/flXf/nd
gqoqJz346Dc0Y/Yav9OGO0EoTERCTrAT2TVfcsMxwwn3NZXlSQQiGwGFJIZtqkZkY+FP7TCpUXZO
/EFMxpUISAQiFIFlK7ZRRUVgRspOJ0j215SZmRuhrXN7D4EXEasl5AS7lVx52eprJvOTCIQPAZg5
JKaHr7zGUhIwk+Y1jeVqynZIBA5rBPILSoJqf1FRGb302pSg8ghl4qKK0OQeUtVUHOeeyvbXUiQC
EoEGjEA0uwCKSyUqzWvAjQhj1YEVMJMiEZAISAQaAQJNmyQG3QqYiWzYmEkVlVVUwIS9stLJ7v1c
VFXl4q2TEhPjKL1ZMqWlJZEV5flT4YIyayc3irJD6kUko6mNmknf1wJruZUINGwE8vcQVZY17DaE
uvZRsUQpbUNdisxfIiARkAiEDQF4EDnpzCcpL684LGVGRzmoc+eW1K9PezpueC/2rd2DHA7vBheb
t+yj9RsyaXdmjlLHpMRY6tG9rZJHXJz3uTAbs4lCQbJDRrBjomzUl71TyemNYbkfZSESgdAjUMXj
aCDZrG2QooOAjT8AINcO7y9znZQySCIgEZAIRDQC8AYy4eGv6qWObVo3pUf/ewENObKLR/mYRPnt
Dwvpm+8X0tZt+z3OiYNEJtqnnzKIrrtmFMF1oFagu16xj+2wrV7GkfN13DDu4Ue0BVpx3CbZRkly
cqMVUMo8JAKRgYCdHdlDQ1sufWPrXpDkVm58dE/KQImAREAi0HAR6N61NcXERNGivzeHvREFhaX0
29QV1LZNGnXv1lopfwsT6lvu/IB+/mUJ5R4qMqwTFsdZu243/ThpMTVrmkQ9e3iOMBbxejkHi0Jj
IhISgh3FipxObB4i5/gYXnN5QiLQMBGAdhYeMirCM1TYYEBKbM7O/oO3U2ww7ZUVlQhIBA47BAbx
ojEw3Vi0eDOVsdlIOAUa5plsxw07bezfeNu7tKfaHMRMPUC0Z81dS9HRUR6L3xzkT1mh/qKUZrL1
GickJiJtUmzUWnoP8Qq8PCkRaNAIYMJjMRuuSSFKaOaeBCqxkAhIBCQChwECOTmF9OmXc9k0YwHB
Q0g4BVr0+PiYoOzBX5x4BY0a2Vep9uoDLioLUV/BcoJtZ6NrLIsOLbY/IsxfkF6KREAi0AAQKOHJ
JCWHGkBFQ1jFeF5MJj4thAXIrCUCEgGJQGQiAG8gX307nyZPmk/b9zYc00F4Kfn1h/vJFhNL67JC
Yx6CK2a5m77miebINdTyf2xmlf92F23ADM5SpzIhslWynQa1ttFp3YiGt7eRJNyR+WDJWkkEFGJp
Y7vsw1WTLTXX8iGQCEgEDmMEkpPj6eKT2tHwWAfll6TQut2VtGlfJe086KQDeU7KKXISe+WLOIHN
9qTJS+i4U4eHtG6WarBhcw3tdbQX7XVRuYteXUz0xt8u2lXIEaGxVjslwDHS86pBx2c4aMKxRCd3
lWrtkN4FMnOJQDAIlBUQFWUFk0PDSwub69jkhldvWWOJgERAImAhAlsnv0elhw4Y5sjurqmKTRRA
tKv499yvRbRlX/2z7v79OtI9T95MbJodMrFUgw2f197I9WYeUb76Jxf9tZcZNGxenBVeGmajOTtt
NP9LJz00gmj8seY0414ylKckAhKBUCAAoomJj4XsJqmxu/CDK76klvyikw7+Q3EryTwlAhKBhoNA
eX62V3KNlsBcOIpNEWKr2WZhSehMMvxBbuOmTCqvcJEthGYS0BVbJq3YNZ+RgFyf9nkV/ZXJRZYz
sXb6sCrnFX5ibZWUnminD9ba6KFZLhJ22kZlyHCJgESgnhAA4YQPaLjxa6wiFpGR5LqxXmHZLomA
RMAPBPJ3rvcjtjuq2mDB78QWJigtraDi4uCWgPdVHcsIdlP+vrIZjq7ABcrl31fS5jyOUFGttUYn
Brs6P5iaNEtyUKsUB8VF8TKaPEn1yw02em9Z3Z4P+xmn1xdXEVbigewtcNETs6vowZkuenwWL8nJ
ZSPOC/NdtHC3O/2CXS56ZA7Rw7OI/trJNkJ8/pVFTtqV56Istg3HfqkP/q8UJv8UBKp43CcrK4tK
S0stQ6SwsJCys7OVpVQty7SBZgR8Dx48yK6JIuXVpA9kYUkZZVfEkSs2RT9CQw7F8udyEZmIvYKh
eAc1lOcuYi9KI6oYvkf5+fkBtQjLgefk5AScPqBCw5SoaP8Ov0tKiDFWxPqdWZAJHFjbIYRimYlI
qyRj0F5Z6KRFB7goQa7Z5qVbcxs9ONKT3/OS9LSFNd1/brPRDvYCBuF7E//kqrTRy38Tje5M1KUp
wtwCcvzUXCe15smR3ZvZaCene2y2i+4c6qKU6gmXf2510X3TnTSyA9H0qxw8udJJn64iGjvITuew
Ccovl9noMSbjX/xjo0e4Tk8yQb+iv53JvSilcWyXLFlCL7/8skdjrrjiCjr55JM9wswcLF++nH75
5RdauHChB/lLSUmhXr160ZlnnkknnHACxcXFmcmODh06RL///rvy27p1K/cs3X6Wo6KiqFWrVjRy
5EgaM2YMdenSxTA/vfZdf/31dPzxx9dJ8/PPP9N3333nEd6nTx+6//77aenSpT5xmjBhAu3cubMm
/VVXXUUnnnhizbF656effqLvv/9eHUQTJ06kNm3aeISpD9CWX3/9lRYtWqR0NECuY2NjlfZ3796d
evbsSWeccQa7KzJnqjBz5kz64IMP1EWY3h8+fDjddNNNdeJ7u2YZbVvQKccOptEnjKAOHfjBC0BW
r15Nn376qUfKs846i1AfX6KX1leaZs2a0X333ecZDaYvielsEpKghH/44Yc0Y8YMjziXX345nXLK
KR5h2gPt/aI937p1a+rRo4fyw7VNT+cydUSbj9X3nbpIbVnqc9gPtM6B5qNNZ/U7CPkH+tzpvXvU
9cV7sGvXrjXXF/t4t5kVq+6722+/nY466ihTxU6aNIm+/fbbmrhIh/RCtPeHlXnr4an9VmnLt/JZ
ACHG9+iPP/6gbdu21XyPWrZsSXj/4lk95phjaMCAAQIOj21mZiYBvz///JN2795NlZVujR3ug44d
O9K5556rfCPNfh89Mo+gA5iI+Csd0h20IyuEhs8mK5SckkhxCaEdcTX/hHupdEqcjRIMVgeGt5DX
FjvdNtciDybNrZOJrhjgSbDF6Ts5zd1TXTRtC2vFRQ3ZPqSYZ0S+v9xFT43yJPPxHCehOl40d0ii
7S7alGvnlSSdhHPPz3fS1f1tNGObk/7OJEqOZXsgh0vxUAINOXJrzt/P/cV2uuN3l7ICpV2/aqKK
DXKLXvi6des86o4XiT9y4MABeuihh5QPkV469PJBCvFr0aIFPfroozRkyBC9qDVhIKAvvPAClZTU
Ha7BiwkvqM8++0z5nXPOOXTPPffoEne99oEEagUvvSeffNJDI5yRkaGQSBsPn+jlo8UJnYBNmzbV
ZP3II49Q27Ztlc5FTWD1DrTPWtzLy/U92+/du5cefPBBWrFihTYbKisro7Vr1yo/nPziiy/oqaee
Ush2nciagNzc3Dp10EQxPAQ2WvF1zTbvyKQt/Pv8u0n0rzNG09hrrlE6CNp8vB2jk7VlC78EVJKX
V93zVoXp7eql1YunDhOdOiUMw2hx7IIPP+yz4PzHH3+s3B9KQPUfOi6+CLb2flGnxz7uD0HccQ/e
csstdA1jphVtPlbdd9pycKwtSxsn0DoHmo9IF4p3ULDPnd47Q9RXbNEhENK5c2f63//+p7wzRJjR
1sr77plnnqGvv/6aF9sw+GBXVwLvTdSvoIAnMFeLViGgvT+szFsPz3C9g7/55ht65ZVXdEdk9+/f
T/jNnTuX3n//fQLpx7Oq7ixBcfPSSy/ppsco74YNGwhY4Zv23nvvGXamBe6RunVVVVJlif+u+Tq3
sNPiTTY6qls0tUix08F8Jy3cVMG+qN0WBuFqb/fenUJelCU0smWiMTBTtzhpbymzXKeqx8Lfq0Ns
TbA000X/7CdazRNQsd2S625vOpPd50+yUTseaYZWW4iTOcmiPTYqglmJSso462/WutgziZO2M5+C
rfbAFk5qzgur/bLBRYvYNCSHuVtyvIMmzq2kEk5fzBrx39lNILTevdghwKFSG71yKo8Cx7joQFHj
n6ulgs/07vr16+niiy82JNfajPAhxMsHRNBIQBCeeOIJXXKtlwbE7rLLLiMQxkAEGncQWLW5BTTk
r7/+OjVpwmQqQMGL8+6771a0+QFmQatWraJLLrlEl1zr5QkNOkiYN3z10gUbZvaa4dE9VGajj3+a
TreNe4AXBjBHjoOtX9DpY3mVrNR27N+6aQ25Rp7QSOHDrxV0AnBfWSUYUsb9iPu0Qoz6GWRuxX1n
kLVfwf7U2VvGvvIJxTuoPp47kFNoXJctW+YNDuWclfcd3hnoJPqS1157zYNc+4qP86HM20z5VjwL
48ePp2effVaXHGvrgHv1k08+oeuuu46gsYZ8+eWXCnlGXXwJFEdQFjVUKS/IDciEs1fbaHro/ES6
+aR4+tfRsXQjb1+6Opk6twituYYW5+NP8q7408YP5Dhogg3NdQprhI1k9nadM1zq2oNEp3/horO/
dtFZX/GWfyd+4qKPV7oZdQsmxzAHKa/m5SDNTVmbH8/lgUQLcXBe44Y5qGm8nTZnuwieTO4dblds
rzPZZCqbZ6y+caaDfrzYTpMvJhrS1k59W7BZyQlEP3PYCZ3sCrkeN8yunPvuoiiacDzbfnvv4Ivi
D5stCC1eBkZ2aNBuqHvxAhi8hNCb/+uvv0RQzfajjz5SzCBqAlQ7CQkJ1Lw593x0ZMeOHcpQvhh2
04miG/TPP/8obVCTFpBqfEww9BeswA593LhxZKSd9pY/tNz33nuvLoGDRhP46nUAYCcK0xFfYuch
GcRT//S0WLiG6jjYV1/XQK5ZpdNGyzfuofuffp0qHeZMWny1J5DzMF/CqIrRL6Ep3wNN2JwlkV8Q
ds8XAO7jr776yrDYzz//3PCc3glc06SkJOVnNEz822+/KVpEvfTqsGDuO3U+vvatqnOg+YTiHRTK
5w7PjrjGeP60Ai3xrbfeqsxf0Z4Tx1bfd8gX5iZ79uwRRdTZrlmzhmBCpxXUxZeEMm9fZeN8MM/C
W2+9RdOmTdMtBt8jmHY4HHVJIL5DeIaxhSmeVjIyMmjUqFG6mmqYsmGuUUMUZ6X+KKyvtnRIt1Mn
DZlOTbDRuDGJircRX+mtON+5ewfqe0QPK7LymgerloMTb55DkPMmJr1sQu0hSXF2SmVCDFoOH4Q4
jf0ivl6zdxBdVW3W1JJJNp5pkOtU5hBtWaPt4O8eFgzqU8294ALmrqHi5eW++Uew/2w9aZ9qo/vZ
3Z9a/jvCnfYeJuVCHjiudl+EHe5bkOR9+/Z5wBATE6MQyhEjRigvD/TaMQz63HPPedgnQ1sMU5HJ
kyfXDE3u2rWL3njjDY/8cHD00UfTjTfeSLCHxssMWhHYeuPFrRaUA/tAaHzNyObNm+nOO+/00Ewk
JibSq6++SngBWiX4OD322GOKVt6fPF988cU62m+81PEBPvvss2tMYvBhRLsxvAj8YeoCW3dfAtMa
/NQCDGGjrparr75a194acYK9ZkuWraBvp8yiSy66gKiMe79l/CD78iakrlyQ+7CVxofOQ2BjDY01
JmZi30Bmz56tmCqJ0yBM6lGQBQsWKCYVGPo3I8nJyTUmISAuuG/wcdcSdWgvb7vtNsK94E0Cve+8
5ak9Z1WdA83H6ncQ2hfK5w42yRjxg4BM4x6BORFseoWgs4/5GXpzHBDH6vsOecLUDO9o4Kkn0ODq
kWm9MG36UOatLcvoOJBnYfv27YrJhzbPI488UlF8iLk/+MbBfA8mHtBAwy79+eefr3k+33nnHeWa
YQQK72qYPg4dOrQm20svvZQ2btxYc4wdvFcx/6OhiUttlWBB5ZvynLkerABds0tl7WBBvtosYHd9
w93u51J7zurjoJhkDPPYJnHeq1TMfgYFwbYzt23GbvfwS4whyuAR2E7868y/jCZER7RmP9kDagkw
XPvhKInjghwrleWAAvYqIiV8CMD2berUqR4FQquJl8y//vWvmp45evGY+AFNgNZeD3lgwogQ2AGq
CQrC8TLDB69///41mgJMkAPJhKmJVpCHmZc+XoTIQ21PCHKKlx8mZFotmBzjz4RCaNGE/a2oC/DF
y/qiiy6qIdc4Bzvvu+66S9FsQvNuhlyLPIPdWnbNsPojlheHtjiFH3plwZba5z7YevpOz2WhTJSN
OqAuXsg18tMS39NPP73O5M1ATXWg0e3bty/9+9//rtPZwwcdIzZmxN/7zkyeRnGsqrPZfELxDgrn
c4fRp9NOO00xJ9BiCrMXIwnVfTdv3jyaNWtWnWJhggeCGoyEMm+z9fL3WdD7luDdim+ZINcoG984
EGYoONCBgq22tvMLhRNGu2AuoibXSK/3vbFSwYMywiVWE2zUO8YR2u9AYmI8/fvBsdS8Jb/zwyBB
EWzYOJuFA6YcLZIdlMzaa5h99E4nmsreO2p+l9voD/4d39Hd6lVsl/3nVibXrLkGuUZ6purKH8i5
lPAhgGEvtVkFSsbHQs87B85hCB72yFpRD7+p90U82PZiWFVPxo4dS926dfM4BeKMSX/eRNiBq4fh
oBmH5heEPlTy5ptv6n7A9MrDh05r7nLBBRd4nbx43HHH0RFHHKGXXcjCQnLNothkBKsipnViwtvG
bfcMP9NMOi0Tzqu0ykbrd+yn+au307y1e2je8g00b+FSAhnAD55jjAQESD1BDfHQsTzvvPM8ksCk
Q29SrUckHwd6Hh60k7u8ZeHPfectH3/OBVtnUZa3fELxDqqP5w4jdFoxmk8S6vsOmle1rTAUEOi0
G4kZZYZIG8q8RRm+tv48C9OnT/fIDt8heJQyEpj+wIZebT6njosRLq33JGi+1UomxIdHJD3TP3Ve
kbrvCoHb2AP5Cssz3eQOHapNGUyk6NKjAz3w9M3UtWc1yTSRJtgoARNsO6uj09luxowIch0XbVNM
PpAG2mzYU4sfbLlh7gFZtIfo1ikuKuTJiB2YXMO/tjD/4omr1IqJvVbEeYRXOT3Pqo/V8TxjuY/g
9k+KJwIgslrxRe4GDhyoTVJj94eXuprwIiImGuLnTfTK9GZLiLwwS1tMQBF5wywi1JpffIwwSU3t
aUSUr93qtUHvQ6xNF87jsFyzKB4Ow8TCZGiWM6g0Np2ySniOBE+ULKqwURmT5CrilwHsxNT+S7GP
MAf3vJFHTBJVRCUpaTOL7Ozy00b7imz0wZc/0h1336eMAGAUQP2DNxYj0WoR4WKtX79+ipsttR07
hse1rh+N8tQLhz29diQD8YzmIujl4c99p5fe3zCjOqOT7Y8Y5SPabvU7CHWrj+dOr5Mq2qjFK9T3
HUz+3n333ZpiQUiD7SCKzEKZtyjD19bsswDvVdpOLEy9jFxl+ipX7zy+A3jfqDs0mPeDSZUNVRwx
PswX/GzYyh2VtCfHP/OQN14aS88+dRkdeURn1snU5aMIw7m7x19M45lct2nv33vJzybUiW5sdFgn
qmdAGiuZBCH2PON5hCY3Y0Icy6p/I3KLRWI+XOHuucD/9WIm2PAU0iHFRsn8zYQNNgSrFKfwcSc2
JxECG+4rf6yivcUOSop20rihNvpytZNGd7LRMe1tdNtk/iQzm88qQnoHDW1bxa77bIqHkduPttOF
31TR3TzBEQT/3mku5WM+or2THhvlUNIObGWjsUfY6aJvK+nlUx3UOa3uRRR1aaxbTBzRit5QlzoO
euUwE1GTW7g3gkCrrJXevXtrg+oc65Wpl5c6oVYzjHOwBYdtJLQQVkm7du2UF7LavR5e3Bj2N9L0
i7L18IUpiJFgOBOuBoXALAca/lCKHs6humZKO/jF6LRFVXsMqn3miqKYgKe299lUEGyttyGfiXQi
wIxAS4qgvYbgHh89erTiL1ckhX08NFtq4i3OqbcwjxIED6ND8CYBco3y1NK0aVPq1KmTOshjP5j7
ziMjEwdm6wxcMjIyDHM0m4+67XrPiN77QF2ot3cQ4unlaeVzB7IqrvFedr+JkZIpU6aoq6js6ykO
QnXf4X5Rd1ZA4rFmAd6Tal/9MHuABlZtvuJLgx3KvOuAphMQ6LPg732A9/odd9zhUYOnn37akJCj
swFzErUHInwbYX7iS6nkUUiEHUTFJVhWo9W7Kum134v9yq9H9zbUrm2a8jt5dH8qKiqj9RszubNU
qJiONk9P4VHvVlThiKOtOf5pxv2qiJfIARNs+I02IzAJSeDJiy63n3XdJLvyid5aAvsbVkwxiY7m
XxO2FEhnYi7INRJiYv9RPIqcrLIiwPn5vBojFq1ZxfztP39W0Xj2AnL371XUhs0sR7GXkCvYrvvG
X5yUluCk24920L1/VNF8Vsq2SHSyGYqLLupLNHFeFZ3QmYl0Hx7+Zc8mHZs4aTNflPd58RmyOWlZ
Jlz76Va/0QfiQ6UV2IVCk2ck6KlrSRk+mBCxVac1Y2eKiSha0aubNo72GJNKYI6CYUyrBDbdyA9+
UfExFYKXqy+tpl4b4PrNiFjhA6k2WdDau4uyrdzW9zWzsi3+5IXOjLqTBhtMmEcJwYIRsPcUgpEZ
DAODtHgTfGwxedWX+CLrwdx3vsrWnjdbZ0wm9dbBMJuPuu16z0gw7yC0TS9PK587jJ7h502g6cfi
SVoJ1X137LHHKpPqhFcn3NuYS4MRBPyEwPXcypUrPQi2OGe0DWXeRmWqwwN9FvTuA7hRNBLgpH7/
Ih5Gr4wE11LdcYbmGvNrGjK5RlsdsSZJoBEw1eGv/Fas+MH2Ea3O6UsuGOYRlpgYS4MHeSojYI68
Oat+yDUqFxDBxqRDo4VlPFrMB2aWxYRdO/LDIjFCWvLKkDAjEVpvaK+j2Cn2WT04UCPxbHry/gpi
/9Y2OreHXYnzwTJSCDc8gmBFxvR4FyHPDqmsTefjHQV2+n6tU7EHx0XYxw4NTsiw8URLG0+6tNG2
XBfHs9GZXYkenF5FFexqzMFatcNR9LQ6eMFAe2ckcImnJiaIJ4ggvAhAe6zu0eOFBj/Jqal8gQxE
rR0WUfTqJs6pt1qvD7C/hA/TK6+8Uh0tqH28qLE4A7TJ6kVLtJM5UYhaG4QV8bQCfI1WhtTGDcdx
fVwzq9uFaz1smOdLWZQB4qwVdBJ/+OEHj2DY72OoV4j6OoowoRUUx4Fscb+iHHgd8CWB3ne+8vX3
POoMTR06mcGIXtv1nvNg3kGoX30/d1BQYJKcdiQt1PcdViu98MILa0ihdv4BRh9w3+Edrha9e119
HvuhzFtblt5xIM8C3HfCo1RREQ9zVws8vWAEQo98izhmt1AMqck0PF+pj83mE2nx7NGxPDc8mh1B
sblBEHLJsDiCBruw1DwR7tghnU4/dZDXUpEbeJzaRNhrghCcZNrqvzRndyrBijoH9cRRaKShocZP
kGuUBe31+b1sHuYhog4VTLzP7s6LzZxvo4dZkw3p28K9gIxY7pyj1CxaU8KeTcZ0ddE3FzoIi+TA
E8odR7M5yW8uOvkzF2Xy4lXXDbZTHl/wS/va6InRDirlhWkOV4EJgta+CRO6tKvsCXzQm9fT3KiX
uFbvIx1e3npu+0SecFeFBSHUgpcf3Pn5EkxGw+qTWoErJTMLPWjTeTvGR/Pxxx+vg5e3NMBXKxhK
xopfkSThvGahaDeIAya26v3gxUMrMCXSLo6DjzA6euIHLZ9WYG/5999/a4P9OoZbSzPkWmQayH0n
0lqxhb0qPAAFS65RF722h+IdVJ/PXc+ePRW3cHq26qG+79BZwQJVRgJ//Ji8p33nmyHYoczbqL7a
8ECeBe29gLa+/PLL2qwDOobS5ddff635YaG0xiJxTYK3aW6eaqc7T0ugaFZomhHcl49MuIDd1HrX
D+/KIyosN5Nj6OL4TbChVfblms9XdWG7vSGH6LIfXMrv6b9cNfbcyD89XgU072Le0nGs5LtQh0tB
6/0tLw5zyxAbr8pYW/L1TJCfO7lWJQ6SfPcx7nyxf/tR7qYj7VC21b5nuIMJOmtgjiKaO9ZBPdNt
9PYYB53YxUa3ctxF19vZbKQ2/8NpD8REO+kOxAOu87RePDAjHoutaIkrNIRqP8zCP6waR9gAwsxC
vWQ6tL+wTX3ggQc8hjCRDvlhWNCbQMuOiSQYsodnDrVgqA/n1MN36vOB7sNNE9wCmhVMqNF6NMGM
fuALHNUfNuyr8TFbhhXxwnXNrKirFXnAzVagAi22N4GXAphA4Kc34TYQV2n+3nfe6qd3DmYfwp86
tjfffLPiSxkmMvjBRMCMBNL2ULyDQv3cwSuKuMZaEyuYqRkt2hXK+05cn6uvvlpZOEUciy3el+Jd
ryXYIo6vbSjz9lW2OO/vswB3qFrB+gtP8CrDaveuiKMeedWm0TuGKRMmkOJbg2+ZdmRXL01DCYtr
Vnf0NZC692nPC/ydm0BJcSrup5MR7skHx59HgwZm6JytDdpf6OJ5d+Y14rUprd3z3gXQKasJk1+Q
4GAE6fNKiWZsd+eCY9hdQ2MNUxG44cM+tNYu9upxageiawexzY9OuUgLsw6tdGziGdaDCbMQ9b46
Lfxwq48H8ARHIYPb1O6LsMawxctcPWFO2yYMJZ588snKcDW0HmpyB3tTDLtjFvyAAQMIQ2HQaqsJ
ocgPhBNmBkLgheGMM85QJhyKMGzhPxQ2y9BMw1wEBFPvhQZNiRnzDmhdxYcCxB9O/tVaR7QBLz5M
ONFbpUtdN3/28ZHB4jZq+1xv6WEOcO2119YM2yIuOjE33HADYQhz0KBBCvbo0Ojh4S1vq86F65p5
q6/Z+1UvD0xAFLaneucRhnsEWkXEw/2slh49ehiaMGEym5jQhjRIjw8rVn/TE5BMmFNA0NHD/bJu
3bqaqLDbBEkYMmRITZiZHX/vOzN5ijjx8fH03//+VxwGvA207XhGrHwHoQGhfO4wuVl0SvHsqJfF
xkgI5oG8/fbbHjiG+r4ThUFDDaUFOklCoATBpGwhMNVRi957XX1e7Icyb1GGma0/zwLerzDJ034L
4Rccq1rCRSw6efh+mJkvJOoHcx/UQ5B0TJiGC1t/RqdEXpG4jUvz7vnLnzp3bx1Fj12YRB/OKqFV
O+tOeEtvlkz3jzubThrdz2u2h5hb7uZ5fZEgfhNseA/xR2CaAftpLSt3cJADfyrhqNQkick2a6xh
1tM5hbXWvYiGtVdFkruWIqAlBtrMhXYNw274IICMam2KMQtb+2JS5zNmzBjdFRcnTJigvKywXKxa
0MNXk2D1OezDXg6LxIB4+iN48U+cOJEwCUuttYYtJ1Z0xMfWSoFZCiYkatunVwaGjIGHnikLNF0w
kYkECfc107bZ7P2qTYdjEFg1idWLI1bU0y4aA/IBMqS1lxV5LFmyxGM1PpARdAZAYnwJOnZY/RND
x+Xl7jFNpIepBDqcRmUa5evPfWeUR7jC/Wl7KN5B4XruRo4cWUehANtn3GdqshXO+w6dt1NPPbVG
CYC5I1bZBocyb3/uTX+eBXzfQJ61rlXxLIJYa1dgNFMPaKwFuRbxQdrV11yEN8RtYgvWfloorZrY
afw5ibRmdxXNXVdOBVEtqEWrZoqrvdNPGcTffrYd9iLwHAW760gRzy6qj1rBtCPFe/vq5ACf1a15
smmbJJfXX2u2he6c6qIh3CE6lZU+D/No47OjXZJc10G0/gIwfIihLrMvYQwpg7Q+/PDDupWGeQc0
x8LtmW4kTSA021hFCx/bQAS2opg1D7KtFuSJl6GVIma169lZ6pWD1QFB9P3xvwrTkvPPP18vu5CE
1cc1C0lDvGSKkYdFixZ5xMAojjeii+sADZdaYHdpZAagjod9eIzRrlYKDzSBeLrx977T1iXcx/60
3ep3ENoarucOts3wIKEWzAMRIyX1cd9Bqw4f8HAzp7WfFyN/6vr6sx/KvM3Ww59nAZ1ozB3CyKpZ
gZIH6yoY+TLH3A4tjhjNaCwSndSEEpq3s7w5fdo56KaT4mnibf1o4hOX0gXnDTVFrjdle3qes7xi
fmboyTJ8JG7K5iH+Gkq8ciovDsEdCu1Npi0KJiGwp8aiMrXib2m1KeVeaBAYPHiwolXDsBkIhLa3
j1JhbwhXZphcqCUd2lrhpQatOOL/+OOPCslVm6EgPu4dlAs7amhctORYm6evYyyCA+KvJS/QIgZK
3I3KFJO/4PYKw4W+BJNtYB4ALICv+Piq0yFPvKRh36k3OU8dNxT79XHNQtEOozz1bGDNdALhsg8T
moTgemNegbcJZSIuttBgY6QCIypCcA9A+4mfP+LvfedP3qGI60/brX4HoT3heO7QQcPiU7fddlsN
hJgQjrCPPvpIGfGoOVG9E+r7DhPF0XnUk0BNREReocxblGFm68+zgNFRjByBZEPTjOdR64IPpB0+
whEH10e7VLq6TogHMz+802Hyh4443tuNSVI79aXirN1+NSkmuSlbNkRRWV6W13T5O9dTi4EjvcbB
SUxm3JTtqnHrXFrioj27Kmjv7grKP+SkkmInRcfYKCnFTm3bR1PnbjHKsc+Mg4xgW7IHfjvMSXe2
Y8bCL1IkAgIBrICFBWRgJoLePLS10NIEas+MIXJo7pAnXmzICxpztf22KPtw2MKUBXhg8ii0JHhh
e3uh1wcm8prVB+qyTIGA1e8g5NsQnjvRfrkNHQL4BmFdA7FIGt6/+B75UhhqawSzR7j9A9lvbOIs
L6VNk96kqrISn02DW7/0PsOoWe+htGvWt1S4d6vPNF1Ov45imxp7KxHkGoR647oy2rKhnDJ53+mF
2kZF22jIMYk04qREivExsdJnBb1EME2wWYlIWNUQkwqlSAQkAhIBiYBEQCIgEZAISARyNy2nvYt/
MwTCHhVDTbsOoGa9hlJUQrISb9vvH1FJdqZhGnGied/h1HzACHFYsy1gTyELVpTRgqVltHl9GZvj
8YImfkrTZlF0za1plJTsl7W06VJMm4gkskcPSa5N4yojSgQkAhIBiYBEQCIgEWj0CDTtNogqCnPp
4NqFNW2Flh9u/FLa92RyPZDsMey9QiVVrPk2I9lbN1Nx2nDaf6CK9h6opK3bK2njZtZS76vracRM
fuo4udmV9OUHuXT9nSofz+oIQe6bJtjJsVJ1HSTWMrlEQCIgEZAISAQkAhIB0whgflp+gYvNUljJ
yYrWBLhKDo3C1XSd9CK2GDSKUjv3Y7vqbHLExBIWoXHEsZcLA4FpiVpKK2Noa05bynO2odyK5pRd
nEx7s+yUm8+N/c67rbY6H3/3Yae9cU0Zde/jpwcPEwX5QbBN5CajSAQkAhIBiYBEQCIgEZAIBIQA
TB+Wr6qk9ZuqaM9eJ+074OTFaWqnyoFg9+nJC+QdGU0D+3p4hQioPCsTxaY2J/zMSFVFKa91Ekvx
zdpQfHpbWrSlI306tX4m+a39p7T+CDZ6TjARkSIRkAhIBCQCEgGJgERAImAtAktXVtK02RW0ZVuV
1wl6xewh4+/lFcrvzJNj6dwz6oeUBtp6Fy+s5aqqpPYjL6XYJrVkfMfCYs6yftY2P3jQf/ttM+03
pcGO51jS/toMnDKOREAiIBGQCEgEJAISAXMI/LO2ir6bVMbaau8kLzrKRtddEUdtW9vp6x/LaNW6
Spo8rZxGHRdNqSmRbcLrZFLtZE8qLqezBhQ1uUbgJu5Y1JeUshu/UIgpS55YvrBSJAISAYmAREAi
IBGQCEgErEHg+1/K6eW3i32Sa5TWu6eDjhwYRa1b2mnMqW57YawyuWlr/RFTsyiAWKvJtTZdOa/A
uHNP/bUjMdEUFdZW2+exqVxjIsvMx2ejZASJgERAIiARkAhIBCQCkYrA38sracqfZaart2u3k4pg
RcGybkOtBw3YaUe6lJbW2pDr1XXbDpjF6J0JTxgWoAmFmDIRcdgATmBa7HWZTnrm11LafpB7MJgO
K8UQAbi1yUi30/gxcdSTh4GkSAQkAhIBiYBEQCLQ+BBYs76WJJtpXQ6vSPjA44WUyj6b9+6v1fYe
YG4VyQIPKIv+rqKRxxjXctNWVmHXo7TPCM0kQ3MsDrMcAxSQ621ZbNQuybVPBIERsHr6F0/3NT4T
yggSAYmAREAiIBGQCDQYBNgk2W8pLnZ5kOsoNt+NimALgwpu47OvFVNWdm2HQK/Rm+vR/hr16dTV
ehd9yNeUBjsYbgzCKMU/BKDtlyIRkAhIBCQCEgGJQONEINbPtUUQv30bO3Vo56CO7Xjb3kFtW9nJ
wQQb5hX7s5y0a49Tce23O7OKSlhPB5ttTIKsL3n/s1JeGKaKumV47wXU5wTH5BQHtWxjigr7DaOp
XMurAjcR8btGMoHU9st7QCIgEZAISAQkAo0YgeRk35YBzdlk9NzTY5lU26lVC7uy2Exunot2M5GG
icnUGU7azTbYe/d7+soWsG3YXEnbd1XR2Es9V1EU50O5nTqzguYscLvdc9iNzYOLWCu/vx6VigOH
JIQMBlMEuzSAoYyQ1VhmLBGQCEgEJAISAYmARKChIeBiW+MDC4j2zaXWeS249hd7bYGDjXjh93rG
3ArazfPZdrMrP5iJ+CN/Laqgbp0ddNzQ8GmysUjOp9/Wmrp6W3ly2876s3Kws//pwUPj/YHTr7im
CHYJ3xNSh+0XrjKyREAiIBGQCEgEJAISATcCu6cQzR1LVLJfOW5dMpC33gk2VnH8TEVUA4Xypynl
NHRwNEWHgWNjJcpX3i2hKsXywV3jSCXY3XrFUkoTc1MRA8HeVM5OZtcF5r3JBFIPmUYiIBGQCEgE
JAISAYlA40Mgbz3RjH/VkGs0sFXsRjb58G0mYgUYh/KcNH1OeFZJfO/TUkJ5anE4jNu5dUf9mEhA
e33CqUnqalq+b4pgo9RcHqaQ0ngQyM3NpfLy8DxwjQc12RJfCHz11Vd01lln0T///OMratDnf/31
VzrzzDNp4cKFQefVGDO47bbb6JprrqFKH+4KPvjgA3r77bcbIwQha9OWLVvonHPOoXfffTdkZdRb
xvmsYS0+FHjxeXs5fa7v9BUlRDm7fMdDjMKDPItvE6+kXe0I2lyqyIm18QOiylqTCVQsxl5MrZP2
hK2OcxayKUKIZfZ8XsJ9Rd1yEmKN+eNW9oFdHzJ0RCK1aGXKiCPg6pnOPYefhbYp7HbENCUPuE6G
CUf2iqKOzez08TxrieHxPaKoL8/MfWO6W03fpomNxp0WR+O+5EY3Ijl48CA988wztGzZMsrPz1d6
z+3bt6fLLruM/vUv7l2zzJ49mxISEmjIkCGWtHz9+vWUmZlJw4YNo7i48E+0sKQRMhPTCBw6dIiy
s7PD0nnLy8ujnJwcKi31/HCZrmwjjuhktwJZWVlUVlZWM2kaWK1YsYK6dOlCHTt2rGk9OiolJSV0
44031oT52qnipY+PPvpoj2jNmjWjHj160Gmnnab8PE42sgPghfdpQUFBcC3LZYI1LoOoirV4UTx+
/+IOotTWtXnelMpaz/zaY+1e295ET63xDF34BdGbl7nDbv2K6KiLas9PHEW0diZRNLsle0/13IAU
fzeBaMNcJrKbiTCm37YPLx84muj8J5gNJtbmobcHooz0G+cRZW1zx2ieQTTkAnd6R4w7zMWazckT
iZZPItq+lEknk7GmbYi6DSca8x+iDjCbqJZK/h5/fR/R4m+IDu0ToUQZRxCd+wjRsp/5g/V+bbje
3tOMTRvGqF6FyeXWL3Vr0CtpFmUWXKp7zurA/WxukrnPSW3Y80goJCvbRZ98rbqnVIUkJelrsMvK
XJTJEzTDLb36x9OJp4dWe402mSbYMBM5UMT3anK4oagtr0mCjZomel6oVqk26sgzbVdwL6iM31G9
2I1NEruzWcGG8xXcMerBC7ZU8fU7xBMD0vkiV/I+jwzQRr7RhKRyvucfFU2TlpfT7hwXjR3Bs3aZ
yEOSmROCfG9jFzj7ePZup+Z2ymdtfmsudw3P5O3fwUEl5S6P/ES+kbTFB/Hqq68maK5BqDt16kRF
RUW0cuVKJUzU9aGHHiKQ7s8++0wEBbX99ttv6eeff1Z+bdu2DSovmTjyEbjpppvouuuuo6go06+W
gBuF+/iiiy4KS1kBV7KeEtqZIGE0Ab71sQ/ZuHEj3XfffQTNNt4FVkiLFi3o0kvdBGHv3r20dOlS
evDBB2nz5s10++23W1FERObRt29fmjVrVvD33ow33OQarQTZnP4m0XmPWdfmd68hatmNqCOTUiPZ
t4HouVOIDu6ojQG/b7tWuX+b/iK6ezJ/DJvXnlfv7WES+/yprI3erQ5lor2daMpzbiJ9/5/cvnKi
ty9nwvydZ7zcTA77lmjVH0R3/OAm9YjxKit9VnC5EHQ+7PxOKWel1/ZlRBVMvhuKVHAHqUiDTXXd
B8V/RdMpPAQbRS5fVckEu7qzYzF+b35Ywq4BmSjqSLKGt4ko23l1ymDcQIt8/N3m52JtFl4+0ZNO
+puNz/h+dWX2s/F6Wf1o83Ub0pnJ7iPnxlO7NPe2M7uxGdU7mgYw6cVqiGl8UV++LIHOHxLDhNhO
r16RQCf2iaKHzomnvm09m754SxVdy8QaBDqen2XcJvF8H75+ZQKTdAdNvCieunPP74aRsfToeXHU
mg3jbxwVQyewVv2yYTF0bPfQEwpdEEwGrlu3jvbt20cnnXQS3XLLLYqG6fzzz6fHH39cIUQ7duxQ
tNjQzGzdulXZv+eee5TcoaV5/fXXFTJz7LHHKsPyL7zwgqL1EsWPHTuWbr75Zvrtt98UAg+Cjg/s
9OnTlSgoE1py1EEt0HCffPLJ9PLLL6uDFc3QGWecQc8//3xN+A8//KCUccIJJxCIHMi7Wi6++GKl
LeowlI/8//iDX94sH330kXIMs4Jbb71VyUcdX+yL9qBM4DR69GgCHtAACgFOyPuTTz6hiRMn0pgx
Y2j3bveLFJ0XYIQ6nXLKKTR+/Pg6ZhMHDhygRx55RMHz1FNPpccee4w+//xzJc81a/ijxWJU302b
NtEDDzyglIlrgnKAvRBRt/fee08pA/WE6cYbb7zBPlOdhPALLriARo4cqRCuXbtYA1UtwaRFfU8/
/XRau3atkpuoP8gIrhnKw9D6F198IYpTtiCCqNMVV1yhxLn++utpwYIFChZvvsmkQ0d++uknpaz5
8+fXnPWF++rVq2uuWU0i3nn44YeVcNz/EHH91fezOvzHH39Unofjjz9eMcNYtYrJiEqgXcdo0Xnn
nadcX1zb/fvdk5veeecdpSz1vYSkU6dOVcIXL16syokVg999p4SDtApBRxn3DOqtFmAFfCsqKuja
a69VnkWcB9lGHSB4NvEsog1CgP/333+v3BPHHXecbptEXPU2LS2NLr/8cuV377330ocffkhJSUlK
XujUi3upMT4juM/feustBY4JEyYo1wjPmfqHe9pQKljbN/Md9+nYag3xTM4Pmlsh0MD+b6f7F89D
yJCWXWvD7ne/X90ndP5BSF86mwhmH0YCcizI9RmsMX5hK2vFVxMdU038tv7NxPgKo9Qc/7Racn36
vbyyyEZ3HsirSSuiS17gtMxkvn+wllx3Z431QwuIXskkuup1Igd/P6Gpf+F0JqPZbpOQf6rfZ31G
c/k8UvBGDtG9/B4fM55o8DlEFz1bi4OoK2p5/7Ta8FbdjesdrjMVhYYl9UyaQ2nx3N4wyfadtYpF
K4v8jV3yrd9UaZhlUvXtrY2wfadxGm1cK4/37CqnBXOKrMxSNy+7bqhBILTYOw+BekaGHMHOy8sr
XdSUNdBO/kDkcAcAdUSvpE9bh7ItZu0yVpPM5GVGD7Hm+a0Z5TRvYyV1a+XwaMQq9hUZw0Hjz4yj
92aXK+e6c5wDvMznR3PLaea6Sjqqc5SS5+fzy2namkoa1i2KKquI8lg7DjIfyYJh4ZiYGMUEBMSk
sNDzoYf5Rq9evRRtl9hHGgjsDT/++GNq3ry58vFA2Jdffkn/+9//sKsITANgdwsNOEh0eno6de3a
lZo0aaKcxz7yj42NrU7h3vTs2ZPwkcbHXj3UP3nyZIWQnHjiiUpEfKieeuopAkE64ogjFAIHUgvC
KASkA/VQC4bIMTSOLQQECscgy0uWLKGWLVuqo9fsIx+Y0oAkoS3Q+IMkotOAOkBAIJAXCBPIPtqG
H8pAPGCE/c6dO9O0adMUQi9IFYaXb7jhBsLwPLS9wGHKlCn0yiuvKHmCIEGM6otRAdQfmjSY34DY
Q3MoyJmoG2xr0bkA/igT9rZnn322QgxQV5AhdDaAB4g3JJi0or7a+kNzik4B2gmToRdffJF+//13
pTz8Pfroo0qd0NGDedL27dvprrvuUrAAadYT3C/AX8wlMIM77JGRpri42CNLdCIRDqIJ0bufRTi0
tE8++SS/C2zK/QNyfccdd9Tce8gb1x/3dIcOHahfv35KW9GhQ74gYCgLxFkt33zzDc/yj6YjjzxS
HUzDhw9X4v/555814djH9cRWjQ/uJ9wTyAdl4QfBs4u6QHDP41nEfS0EeT399NO8aIWDWrVqRdo2
iXi+tvHx8dStWzfl/YI8xb3UWJ8Rgf3AgQOVTjg64vjhnsQ1zsjIMIYMphwFB93nx1YT7fwsogUc
LqRpO6K09u6fvfpz7WANkAhLZQLrS6BZfuU8frDd3zWP6NBeZ213Bx19IdGFbL6R3sltHnLjJ6z5
HuQ+t2G2J/EXmexdT5S9qzr9RW7SC4058kBeE5lsC7OP1UyOIYn8TYBGvMtQtznMqFuIznnYfa6S
6wgTlij+TkBjDYEpyXQm4dk7eDj5ZDY5ecp9LjGtFoe4JHdc/MPERuAj8qg9G/69Ss93jboCNpuT
zmj2pDrIr328g2Id7m+bmYTwSmKV4E2ZW8qWOjtc9N3PvONFUlJsumehwa4vmfVHIWWHeCHE6jvY
fBPz+Vru5+9dS4MeifmcAovZhjXH0BZXsAuYZbxCEDTWi1j7DPONo9jXI0w3FvIxzEAgMBsRAjLs
FpdClMWR2L41o4xG9opWzEEQtjPbqWjHj+nqUMj1R3PLFHMRkedSXt4T5iJr9lQpZigin0jc4sN3
5513KqT4iSeeUIjjoEGDFO0qCBc+ugifO3cutWnTRtkX7cDHA5rcdu34Zc8C8gSSAI3bf/7zHxFN
IbHQZkFbDTIPDRtsvUH+7r77bjIyEYGGGEQWZAGT1iAgJyCFKBvEGZoi2I2C6IMUooMADR0II7Rx
RkS5pnKaHXz40EEA8TASkAMQwwsv5A8PC+zTx40bp9Tltddeq0kG8g4iO3jwYCUMxAmdDWiVER8v
QRAWTDiDph5aPhAh4IKhegzZQ0BIoH1EuVrR1hfkHBphYAGZN2+eQkhxTY466qia5CBakyZNUsgU
NKCoE4bycS9AWwxSDW0tOg3QNgJzIcGkFXmILTpF6DzgvhB1BcHGPbJnzx4FD5T9EWvA0cEDEQbp
R1yzgk6ZL9zN5oV4uK7q+1mkBWb//ve/a7TDGIXA9URdcf/+8ssvSgcQzwY02BBo4wXpxn0AEj1j
xgzl+UhJSaFt27YpoyO4psKkQ5TXunVr6t+/v9JJw3kIOk3JycnKSA/uS2hT0XmDlhwjJloB6UtM
TFQ6ZRjFwn2nFW9t0sY1OsZICMzO8Dzih+cf0lifEYEDRoOE4F2JDjfea0JBIM55bKe+4j7sfizR
0EvZNpk1sjtXEk3j8OOu8Yga8AHIbBF3sjbN5+Ew973jkdfaGbWH/VkTrRabg6gfE9ody9k0gwkU
8uh1gjoG0Tomw0IGaNIjPC7ZfRaTFGFyAuk6jIeHU9374h9lQ8MNWcd1GnI+EQj/X5+56//FOCL8
mnciOuEGImjKUb+GIHHG3xhUf0TaB7S+8Hj6+9A5hq2x29gsNXYDdYhfyb9/qG3cWv6to5SoA8x1
KulQRWuak3MNTTkwjiqc3AEzkCxe0AU6BP4kBSzwvpfNSsUDRTbmVy6a/EspK4JAt/XFwZcpTXO5
Rcydu1UETQSGaVtZ4aJJ3+TRNbemhazEqEBy3s1kNj7KRimeyshAsvIrzZJtlQQ77K4t7YQ17pdv
L6dXppbSMV2jaPXuKsXuGprkIu4EfDCnTLG7/vQvd+8ONthif97GKo5Te0P8w9rrWEZiF9tff/oX
96BZ3p9dRrlFLnro+xJFU/3Z/DJavJW13FEVNQQchBwTJKEtn7zSrXH0q0Fhjgx7VZgT4MOOjzI0
cX///bdCDNSmGHrVgrbw/fffVyawgWDgYw1NNYiuIHlIBwIHEuWPgByAfOHDBIKCDzS05jCBgCxf
zi94FpAxURa2mEwFoovzOOePIL43co280I5zzz23JtsRI0Yo2j2QUaHpxMk+ffrUkGscQ/MNwQdW
uGGCFhPaW5jqAEuhyRbkHfGhUcQHGWRNK9r6glzNmjVLIXLQvgpPEVoTHJB+oakEgYV2EiQM2EFA
5oYOHaoQbKRVE+xg0mrrD9In7guUBxIt6iquLzp6CIdAqw/8/CHYZnDX1svXsd79DC0vzJeEjBw5
Urlmoj24trju0NhDUy8EIwbCuwrahhEIdAouueQS5d5Hm9HB0hPg99xzzym2zbj38YxAww9TG3Sq
8AxhC7J+zDHH6GXhNcxXm4wSo83oHEPwzKJ9eD+g86aWxvqMqNuIfTzfeJdiFAEdREOBRhhkGgIy
WcTmD9gibMcKnmzI53uMcJ8P5v+8x92Efd8mojkfuic3qvOLia890rNrVoep44pU0e7nVTkECTeS
KP4m2FgD72LlAUxjtKI2ixF5Xv8xUcaRRPM/ddtdgxliAuU341kbsZ1NS97S5hKZxzFNuEPBJLuE
Ryd0BFrsmzpeSSemH0PrCkdQYWUaOZg0gzw3jc6kNnHrqXXcBoqyubmMThbUJHovndXyKeqTNJ1e
2P47E1/9zkcFE+JACTYWHMxiTpRdYuPhC78AABZRSURBVKtWKLpoBysz16/yzn2ap9kMCf1OXjyn
PmUXc8g1K0upzwDVfWxhhQIi2Ch/C5PRbs1slOQflwqq6piACHMNtaznZULX760N+4pXLVLLlJXu
HhImOop9kHG17NBZpvMPngwAwWTIjftq84d5iRBosmEq0pAEWmR8/PDDxxEfaRA1aDWhKdMTDNeD
BMBLAIgiiIIgmPiYCgGRA4HzV+C1BAQBml98pKG9BoFHGESYjiBMLYJsi/MgNdqhf0F61Omwjw+g
LwHhAfFQC0YCoFFXa5m1eaE+qAvapRbUF+kwAgAiBIEdNiaKCRF2uuJYbLVloLMDrX737t0V8xUR
T10vhGVkZIhTyjY1NVXpFAnSjUBhxiNIukgQTFqRh9jCTEYIcAUWojyBhbbt2mOR3mhrBnfR4TFz
nxjdzzBpEpihLmJftAfaWjwfqL/6/oEpj3g+QMqRPzqV0HKDaIswvfah4wWyDlMj3FfoGKGTBI8t
INkwBcF8g1GjRgU08c5Xm/TqhDCUK0xd8HwOGDBAaY+2w6u9f81cK3FfRPIzosYF2nqMeOH6wHwN
97mhTH259tTndxHhpxact4JgJzC5u/MnoseGMsErqDs5sPeo2lKXfE808no3EUYoXOKtnOI+H8+a
6E5MdrWiTr/0B8/0iAsinJ7Bmmx+33UazMRhMf8Wud3zwYxDCCY5CoHnEggI+cl3un95+3jC4y+M
0795OKSIaNE3RFe8VmtG4k4Ruf8p3Q0Jtqh018QFhF8w0iVxEZ3X4UX6cuu9utlEsWKUXx2mhbs0
BKuFA2x+i61bEMp9Jf70z/y9JtB9Sue/eTOdQA46wBYC3jTf+qmsD4WpSO/+cYadgGBK9ANqz2Jg
67yZO92FtdzTM4I8iigEQITnzJnjUSd87GEvCRG2miCQsGVVC4Y7QRhgBw0tGkxJ4GlEK4K8qMOR
H0SbpzoO9qHRg8AEBKYiIA+CoMKUBQINnVqEDa84j/bgYww7XiHoPOiJXl218UDCYDIjBF4YMJQP
+1X1x1ObF+oDvET9kB5kCxpW2LVD+yzMSWBagg4MbDahuYZWU0+0ZYDUwCUayBXsgTHBrKEK8AIR
RfthSoF7FZpQ2LD7I2ZwF6ZEwlYd+cMmHNdWK1rMteeNjsX9CE0ynhfxw0Q4mAxBcP9AW437CRpP
kDPxDOjli84tzEpAsHFfwUUeSDGeExB75AGyrSW26rzE6IDokKrPBbqPDh5Gw/DDswZba706aLE0
c60a0jOC5/2///2v8pzjeRT3mS6uIJ3LJumeqgnEecSzQuCmDtpg7vTXkbQObCM9wB28ehq797vU
baIBMvviGbykd/Vz0f90fTLbrCNRuz7u9Kv4/fzmJUSrebt2OnsIYBOPCf1qzUgGneWOB4L87ElE
C/n53jyfZ+DewzZPL7nPJbAtQY/j3fvvXsVu+vi9tp3fiZgE2ofTNKv+7oB867XHndLjH6Zx6PTW
q7SqblMYKjE66UnKaK0zSsBlx8WaqwDMQODUYs0BF21m93u15Lo2/cplFZR9sKo2wGCvRbrOfcdx
d2oUnQbJQx6cnVVJK5d6ch6rCvXSxfZdRBWz7I3ZPA+C/UY3U400+U4pY4QbAZBrDFn27t1bIXfQ
nmE4Ex9saLVhvgCBBwFokKEdxYcbE7OEphiTsGAmAdJpRAS17YKXBXgwePXVVxV7amjxQAy1AtME
2Ftjoh9ETTagWYc2G+dgbw0t3cyZMxViCs2e8OkL8xeYb8BOFTanixYtUgiMtix/jvHRhHcQaIah
ZQQRFG7JjPIB6QEBRpthhoPOCMgjSAbsnSHIE+Y5IEtoq+jYNG3aVNGQawmJtixoC9GRQHoQdtgu
N1RB/eHNBpM0YaesxsKfNpnBHZ0w3Gv46OJagCCqO0L+lGcUF/WAR46XXnpJmXSKUR90GPBDh0iM
HsD8CPb4eN4yMjLqTG7U5o95D8AJctVVTD5Y0EFGpw1tgMmTIKXKSc0f6gFtO+5FPNPQEMOzTDAC
Tbp2ZMlMfmauVUN6RjCiBG82eL/u3LlT+QEHPPswifIQTNhzVhMTuK9Ta4bXz2KvH+e4z//JGtqL
n/dIGvDB4HOJzppA9PMTdbPAhMOJrDXeu4E1w1+7f+pYvUYSXfueOsRzfxy/s58ZxYxsi1uzDO2y
WiY/w7bbI4nOHO/uNMzivFAWyLxakljVCS8hsNvGhMb5n7txmKKDwbDLmGA71Kl19zGBG3Nc8N2C
V6d6k46M/8qnw1I8TE6O7TiXtu/lDolGunf1TvlKeEAe2mqse8L0zlDKy3heyaxyw/PqE+3b6BPs
HRFCsFHXudOKqP8R8X5p99VtNNrnbmBwwh132p7rot35bNsTXFYydQgRgMYLZBmaMriCwwQ/fBBA
qPGRF4QONqcgwSBsIAmYgAZzErjGA2nEBEa4kBs5cqSp2kLrhiFwpIELMZAMIxGkGkRbbQuM+PAy
AVIB7SbqC/KPCWjQFgm58sorlbJgk/z1118rw+hw9xaoQEMIPECs4XkFJAgEBwTfm4BAQZOHlzoI
P3BDWtQVJAkCYgK3adA8oh2wPwYhEx4koLH0JkiLyaggpXABCK26MFXwli5SzwEXuHLDxxD2xugM
YtIdRBBSX3U3gzvygLcMTBrEtcEEUDwbZu9nX3XAedQDK/yhw4f7HfML0JkVZlYiD2g5EQci7n1x
Tm+L+w4TTzGyo64vyCoEkxfFc6yXHp1DmISBEONeE51ZvbihDjNzrRrSMyJGyuCeEuYh4ocJrx5S
ztrb2dVkFZpfmENgwp/4DRzDE/ky3EnmvM9mGhzfKjn3UaKBZ9TNrWlb1jTPITr+GvZe0MV93mZj
zXRfolPu4oVwmEDHJtVNJ0KgBf8Ppx9+RW3dcQ7tOPMBt8cQ4vygdb7mHfYuwkSzy9E8jBPtzqFJ
a14M5wJ24TWTbdoGu8NAss95iB+mju5j8Q8N9vn8zr+sWuMtwg22eCeiw25k/miQzPrg9COJkrju
YZIjYmu/6eoihw6uS7DB2w6xwhvK0rWssT5Y7J1cI7/FvNhfcZFTnbXhfqcOfO11ZFcEEezcnEr6
Z5n1Wmzbkj3e+ik6qHgJSo2zUaem7NJShefxTxZ4SSFPGSEwZwK/YEIkIKcg2iCQRoJhZNhaqz/Y
0OLiJyarGaXVC/eWFvXBkDnsUeGKD5OmvM2+R93EcLdeWQgzE8coLcLRKYBZi/AtHUx+MP/Qwwxa
R5BwYUYDe3EQLWABe1q1/a5RXYOpl1Ge9REO8xmQLuFKDkO6999/vzLJEZ5X4KpOK5jgio4gTEmE
qZM6jhHuIg7Og8SpzX3EOSu3uI/ENUa+4n7HPjqsIN8gYmKkCOGhFm2dQl2er/yNrpV8RnwhF4Lz
sHeOZluCBP6YByJYnRITIuFGz5tgqfT8A2z2oSHR2jSIl72TKKUl16mJ9qzPY/Xz5jNyKCOsfoGZ
6T2hLKE27+hEmrBzP6nd8nXkBfP+c3cCRVUr/rHo3kF2/pDFfbjyqtqkvvYK2MnFB68V8XsM1Ny7
8KeM3nk2mhzct9LKvY8V0DZeEDBSpF3HGBp7m4971s/K1u3O+JmBOnoer+KzNotXVuQOufAwAoIG
+zQp5hFQk1rzqczHBKHwRq6Rkx6BBeEzQ/r0amKUFt4QoIEFQYLZCTRz3si1Ud20ZerVXxvHn+Ng
8tMj19B0wfwEpAraehAMEC08K/CeYhbnYOrlT/tDGRdthkYeE207deqk3JvQ/KLzAJ/YWnKNyX4w
j4H5DeLrkWvUVw93dTt8nVfHDWZfTa6RDzoMaB+ec2jRMachnOQaddDWCWH1KXrXQj4j9XRFzPjW
9lY1aMTNSDSTcF/kGvkgXqu6ZoVmikCcUHegzdaDet1KtIY17warOprOx0zEiiJq17KcCXYUt99G
R7Pm+sKzYxVyrZiBMKmGq71AqNk89p5mhlyjmh3a2XXJNc7t2Rs55Br12b2jnLL2VVLzVtbRYscN
4x5+BJlbJfDWAfudCqeNkrkTPHs9+2jkCynFPAKdmjvo3MHVw2fmkzXImCBRmACIle8w1A2NXiSQ
RrhYwxC+L3OQQEGHvSxMcSCYTAmSCfMQ+Av31cEItMxITQeiCbMQXHeYAOFewJwAaPMxKRBaZrXA
fhp2rrCzhz9v4W1CHSeS97E4CToIINXwiS285URyneujbvIZqQ/UZZkhQwCL3iS2YZva780XgTSp
3Llow6ZEnS9h91d3Eh3xCLNBNtspy/WaT7fjT6NhI7vS+WfF0pEDo6iYORkWCtyTz9+cCq9JDU/u
Z69tM35jA2yTMrifjQb09nx/Iyk8iEz6w3w+JosLOpqdzS+69mTiapFYaiKirVM0D0WUlzjp1all
tF1xcC6JthYj9TGIRka6XVnmvWfrujelOq7clwhIBCQCEgGJgESggSGw4lH2IvNI3Uonsua/aT/3
L60/b9kGvklvnrATwxrLPFY5r+DfMrbrWEq0jSeSOn2w5GGvk7PHLey3mp3B8IrU/piB1K2cO+Sb
j0to13aeCWlSrr/MQccOqctlVqyuoCdesnB+gcn6+IoWH2+nux9qQQ6LlNgWZaNf7QoeAbDF2Omh
8+OpHa+wGFtt+6MfW4ZKBCQCEgGJgERAIiARaMQIDHyYNdInso3ENLbVauEm0iDWMdU276Vslw4i
DS31Sp7Qif2Cbex42j8FZUF+Nm3d7yLYWlshWzZU+kWuUWan9qoJeapK7M6MLPMQUbUSVghvWl9G
Pftao8UOKcEWlcYM1bwyl7K8eqtkm8ckSBFHbiUCEgGJgERAInBYIYDVOiqK+cdqRidrBvGrqtYQ
Qo0GEwH8YIccneD2xHFYAdRIG9tiOBF+evIrh+dv1jvjV1hhCdtKV5NrG99XsX+9ThV92OVsWme/
8lEiM7ef86c5t3wic/jcbtNSn2Dv4QX8IlUaHMEGkOh87SvkzhivWd82mdem5yXP9aGPVNhlvSQC
EgGJgERAImABAnC/V8bGsCDWRlJVwWSbf5Cyam9cINqxKaztTHSHy//Gh0BSx1qCHd+Sba8vYh/j
vCDPwSV+tdUZxURLSCWTY77fojZNp6qj/SfYq1dWUI6JRWVEcdjCPR9bvepK5v7IJdib11lnG17X
OEYXDusCYTay/RDR+iwXFfjXIbKuEjIniYBEQCIgEZAIhBuBSh7Ozc/kJZD3eyfXRvUCIUda5IG8
pDQ+BDCpUciJPxMd/TLRGXPZRWErEepzWxWdQjmtmZhXiwtuF1lsBfvIkbW+OtTchued08LZ/pO1
fj2N6eX+A5FpIgJECvKraN+e6lEkcxAZxjJGwDCJNScwi3XjQV6GM4eX0bamLdZUTOYiEZAISAQk
AhIBqxEoOmgdMRZEHXlKaVwIYIKjkNhqv98OJsh2N0kWp4y25XHtaNOQqVQex5pwIapVL6O2zBah
prb/LK2gvEP+a5z79tRXX/OyF5TN3kwiWTatt6bzWm8EW4Cr+M7m1YN2MOAV/l9DkY3cSgQkAhIB
iYBEIPIQgJ01aw4VkxCrawczE+SNMqQ0DgQwARJ295AZFxJteJtoJm8Ld7jDDP6htd7bZQKtPfYf
Kko5yiOWzVWrMbYVHqCoff94nDc6qGRF6MK5/muvU1N4PZS2+gR7v+JRzqjEyAjfutH/NuvVvPoq
6p0KbxiW58xh++zWPAmyBZuX2fWvTXgrJUuTCEgEJAISAYlAoAiA+ObzyobCljrQfLylwyRJlJHS
Vk6C9IZTQzmX3IXomNeJFtzGpIiJ8F83GdecjZyLUo+i3Fbn0cF211NVVLXGW5PCVsCeSVQCLXZV
i97kEkRedU69u+Lvcioq8L/z1q+HMYHbF8HmIaLte9lEBPMGjWzIRTxf24gh2KgoFm3fk+9euhNu
/ZrG+aq+PC8RkAhIBCQCEoEIRYC1hSEl16LZIPAoK9m8na5IKrcRiECPG4jankS0cxJV7phClUV7
eZTCrYUui8ug0qQ+VJLcm/LTT6KKmDY+G+DYt8ozTskhZcJjRY9TPMNVR+U812/xX3xfBSB9exkb
R+w/4D9hD6AKQSUpL3PSwf3Br+oYUQRbIAKH6FtzXMpKkB2bSP/ZAhe5lQhIBCQCEoEGggDso6Fd
DpegLJSZmB6uEmU5IUSgIqET7Wx1Bx1qckdQpdh5UmzU7qWktXp27FpMzqQWVNV2kG7+SxeWU0mx
/2QYWt++PXSzVAJhItIQJHN3RdDLpht3MyIAgQLuQa3Ngns/V52bIwKqJ6sgEZAISAQkAhKBughg
EiLso8MtKFN6Fwk36paWByKcVeSiNTwggTVEghHHoR0Us+QTNtHX9yQRs34yRW+ZSTaNCVMpm+su
WRCYHXJHXlwmOdHYRORgrpbqB9PC0KXN3KWPmT8lRqQGW90AJ9uN7OF3BuyzM1ibnRCtPiv3JQIS
AYmAREAiEGEIFLN7rPoSlJ3i22ygvqonyzVGAI4etjEBhXKRbUKMI3o5Y2PjYXv+bnLsWMgu+Taw
LbFxPjjn2DaPFG12WhdyNmnHv460ZHEalfPigIFIfwPvISKvgzkNRIO9KzDzGNFObCOeYIvKlnBb
17Nbv46pRM14kRopEgGJgERAIiARiDgEsIhMfWqRUTbqIBejibhbw1uF8phUb2dyLVZfNIprKy9W
CLQN15g104r2mVf/tJXzYkQleco5qlAYunmKzgvR2A+sU34o9/iqWErJ6E4Ld/Ympz2OCiua8IQ/
c7xrcF/vhhHZDYRgHzx4GGiw1TcZOmJYpKaY290uhWd4qk/KfYmAREAiIBGQCNQ3AvVhGqJtM+og
CbYWlYg8hp54N1+uA2wK60tsvNBQ7DxeeMbA5MNXerPnYxxllFOYQPvymWix2KmImiXlU0JsFZVW
pVBhJWs6dSSNnZhk8AqORlLJ8+sO5TUMDXZZiZNgKhMXb9weo3aK8AajwRYVxhY3YjGbB3VJs1GU
986SOpnclwhIBCQCEgGJQOgQgFs+b8ufh65kz5xRB9TFJj+QnsBE1hG01Vtz2ZW5WXMMZcGY0BNU
KDNX7O1aA5aT1ZlZhUyqC91BiTHZ1DypgBwOO+WVp1NJVYJyYvAAR00avZ2c3NDXXa/cQMNysyup
dbvA7ZIb7NNXyAR7U7aLqnx3+gLFVqaTCEgEJAISAYmAeQTC6TXEV60iqS6+6noYni/lkXiYvZom
14yRKypG8V8dari25LSj/DI3adYrq6g8jrbnNKctWc3oYB5reZ37qFXcVkp27Wa/2caTI7MbyARH
0eZDubUL9Igwf7YNUoMtGojl1rfwfI5uzaS5iMBEbiUCEgGJgESgnhBg+9iIEWixY5IipjqyIrUI
QEG4mV0RVwWg0K3ocxZRQhpPTPw7ZKMlyzO71VbWxF52cTLht2UK0ee/FVG7tL3UI6OK+vROpP6D
0iklxa3ZPpQXHGE1URVLo+TmBFffBk2wgSR6f3vybYpNtqXIyswkAhIBiYBEQCLgDwKqJan9SRaS
uCG20w1JnQ+DTMXoOxbWC0jYTKSi8wiq6HQcOXK2kj1rE9lzt5O9ONurxxCzZZVXRdGa/Rlmo9eJ
53TZaGd2Kv+Ipi3l058WUMvUYuqWUUkxcVg9MKZOmkgNOJQdQA9I1Zj/A+EQyAY2Yfd8AAAAAElF
TkSuQmCC

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A56E6EDD369F424DEA6A0A2C280FAF72@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body marginwidth=3D"0" marginheight=3D"0"></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-32EDED34D84F5788E610775E0E2D458E@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=159110&us_privacy=1---&predirect=https%3A%2F%2Fu.4dex.io%2Fsetuid%3Fbidder%3Dpubmatic%26it%3Dadg-pb-clt%26us_privacy%3D1---%26uid%3D(PM_UID)

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body marginwidth=3D"0" marginheight=3D"0"></body><=
/html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-03A216DC1E3FEE2C88015B0E64D722B6@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://eus.rubiconproject.com/usync.html?p=seedtag&endpoint=eu

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.=
w3.org/TR/html4/loose.dtd"><!-- Copyright Magnite 2024 --><html><head><meta=
 http-equiv=3D"Content-Type" content=3D"text/html; charset=3DUTF-8">
    <title>User-Sync</title>
</head>
<body>
   =20


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-CD9CE534A494EDE420FBB3C308E6558D@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://csync.smartadserver.com/rtb/csync/CookieSync.html?nwid=3050&dcid=3

<!DOCTYPE html><html xmlns=3D"http://www.w3.org/1999/xhtml"><head><meta htt=
p-equiv=3D"Content-Type" content=3D"text/html; charset=3Dwindows-1252">
    <title>CookieSync Page</title>
</head>
<body>
   =20
   =20
   =20
   =20


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-16A1475035ABAE428ACF8E198AD4669B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.pubmatic.com/AdServer/js/user_sync.html?p=157743&gdpr=0&gdpr_consent=&us_privacy=1---&predirect=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fpubmatic%3Fchanneluid%3D

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-B9DFCD084E23FB77884C45C86187A269@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-1F927622FAF42D253C8D6A6A6EBFA345@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-7D4A94A5BF2582648BC296D4D3CED912@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://onetag-sys.com/usync/?pubId=75601b04186d260

<!DOCTYPE html><html lang=3D"en"><head><meta http-equiv=3D"Content-Type" co=
ntent=3D"text/html; charset=3DUTF-8">
   =20
    <title>Sync Pixels</title>
</head>
<body>




</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-94E743DEFC9006B44877629AC34D4644@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-97BB4A7B9D400C120D2124352F72D084@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-C96B4FB2B000EE519291C75CEBA1E7CA@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-08106324CBA18E2F03F00829972CABCE@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://match.prod.bidr.io/cookie-sync/see?_bee_ppp=1

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"><meta name=3D"color-scheme" content=3D"light dark"></head>=
<body><pre style=3D"word-wrap: break-word; white-space: pre-wrap;">unknown =
partner: see</pre></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-37B91C19A024614E65799007253AF571@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://sync.adkernel.com/user-sync?zone=217236&gdpr=0&gdpr_consent=&us_privacy=1---&r=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Fxapads%3Fchanneluid%3D%7BUID%7D

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"><meta name=3D"color-scheme" content=3D"light dark"></head>=
<body><pre style=3D"word-wrap: break-word; white-space: pre-wrap;">Unrecogn=
ized pub point</pre></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-35B7E4867095D21706C7D5B98C1E7544@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://ads.us.e-planning.net/uspd/1/624cc8b63b155a6a?ct=1&ruidm=1&du=https%3A%2F%2Fs.seedtag.com%2Fcs%2Fcookiesync%2Feplanning%3Fchanneluid%3D%24UID

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-20B65E073520220D12DB665E6A13A372@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-E3D4CF2BD8C9FBB31FF681B5D895413A@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://hde.tynt.com/deb/?m=xch&rt=html&gdpr=0&gdpr_consent=&us_privacy=1---&ru=https%3A%2F%2Fcookies.nextmillmedia.com%2Fsetuid%3Fbidder%3D33across%26nmuid%3D%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26uid%3D33XUSERID33X&id=zzz000000000002zzz&b=1

<!DOCTYPE html><html><head><meta http-equiv=3D"Content-Type" content=3D"tex=
t/html; charset=3Dwindows-1252"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A81B6AF1E6E306B3494CA3D4D4C63DD3@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=1---&gpp=&gpp_sid=&s=pbs&cb=https%3A%2F%2Fcookies.nextmillmedia.com%2Fsetuid%3Fbidder%3Damx%26nmuid%3D%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26uid%3D%24UID

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8">

</head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/png
Content-ID: <frame-E83CA299C8F36B52AA0A7CB8B6459E49@mhtml.blink>
Content-Transfer-Encoding: base64
Content-Location: https://pbs.nextmillmedia.com/setuid?bidder=appnexus&uid=3016583850375373964

iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAABHNCSVQICAgIfAhkiAAAAA1JREFU
CJljYGBgYAAAAAUAAYehTtQAAAAASUVORK5CYII=

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-A4E0DADD1999BF1EBA55E9152D230BD7@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-8053950A21E3548872E5BB87FB37685B@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/png
Content-ID: <frame-11D2A7D62CE0DF2AEE4E3D0F0582827D@mhtml.blink>
Content-Transfer-Encoding: base64
Content-Location: https://pbs.nextmillmedia.com/setuid?bidder=loopme&uid=cba3c608-7dd2-4574-b720-813c65c8b21a

iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAABHNCSVQICAgIfAhkiAAAAA1JREFU
CJljYGBgYAAAAAUAAYehTtQAAAAASUVORK5CYII=

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-57F2AB50BE1E880E73721C8D8820BF9C@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-D826CBEF07E6ED4C16794EF11BBCDCFC@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://image8.pubmatic.com/AdServer/ImgSync?p=157577&gdpr=0&gdpr_consent=&us_privacy=1---&pu=https%3A%2F%2Fcookies.nextmillmedia.com%2Fsetuid%3Fbidder%3Dpubmatic%26nmuid%3D%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26uid%3D%23PMUID&rdf=1

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3Dwindows-1252"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-732E8870E44D2DB4CCB7AAE658FC1279@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://eus.rubiconproject.com/usync.html?p=17888&endpoint=us-east

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.=
w3.org/TR/html4/loose.dtd"><!-- Copyright Magnite 2024 --><html><head><meta=
 http-equiv=3D"Content-Type" content=3D"text/html; charset=3DUTF-8">
    <title>User-Sync</title>
</head>
<body>
   =20


</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-4CFAE9391EFA35B60BB12B905FE71035@mhtml.blink>
Content-Transfer-Encoding: quoted-printable

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8"></head><body></body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/gif
Content-ID: <frame-17C2E5790FB4D824A129FE6441EBF1B1@mhtml.blink>
Content-Transfer-Encoding: base64
Content-Location: https://eb2.3lift.com/getuid?ld=1&gdpr=0&cmp_cs=&us_privacy=1---&redir=https%3A%2F%2Fcookies.nextmillmedia.com%2Fsetuid%3Fbidder%3Dtriplelift%26nmuid%3D%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26uid%3D%24UID

R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: image/png
Content-ID: <frame-F126C0FAF0F66BE156B54198B58EFEED@mhtml.blink>
Content-Transfer-Encoding: base64
Content-Location: https://pbs.nextmillmedia.com/setuid?bidder=yieldmo&uid=Vmp_biittUiTZ_ZjxuBp

iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAABHNCSVQICAgIfAhkiAAAAA1JREFU
CJljYGBgYAAAAAUAAYehTtQAAAAASUVORK5CYII=

------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-9818D5E81D03B69CD972BF2A1A9DDC39@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://onetag-sys.com/usync/?redir=https%3A%2F%2Fcookies.nextmillmedia.com%2Fsetuid%3Fbidder%3Donetag%26nmuid%3D%26gdpr%3D0%26gdpr_consent%3D%26us_privacy%3D1---%26uid%3D%24%7BUSER_TOKEN%7D&gdpr=0&gdpr_consent=&us_privacy=1---

<!DOCTYPE html><html lang=3D"en"><head><meta http-equiv=3D"Content-Type" co=
ntent=3D"text/html; charset=3DUTF-8">
   =20
    <title>Sync Pixels</title>
</head>
<body>




</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1----
Content-Type: text/html
Content-ID: <frame-0AEAD1453CC5020344FFDE60352E6550@mhtml.blink>
Content-Transfer-Encoding: quoted-printable
Content-Location: https://www.googleadservices.com/pagead/managed/js/activeview/current/reach_worklet.html

<html><head><meta http-equiv=3D"Content-Type" content=3D"text/html; charset=
=3DUTF-8">
<meta http-equiv=3D"origin-trial" content=3D"AxjhRadLCARYRJawRjMjq4U8V8okQv=
SnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iO=
iJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVy=
QVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"></head>

<body>
 =20



</body></html>
------MultipartBoundary--5z1wlmOuIVeiWxV5NvvfL1uoTZQk03HO6eJiOaKGM1------
