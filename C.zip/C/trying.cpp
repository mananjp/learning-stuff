#include <graphics.h>

main()
{

    initwindow(1000,600);

    line(500, 200, 400, 400);

    getch();
}
