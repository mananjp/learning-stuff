#include <stdio.h>
#include <string.h>
int main()
{
    float i,j;
    char c[100];
    printf("the given operators are +, -, x, /\n");
    printf("give two numbers: ");
    scanf("%f %f", &i, &j);
    printf("give operator: ");
    scanf("%s", c);
    if(*c=='+')
    {
        float a;
        a = (i+j);
        printf("%.1f", a);
    }
    else if(*c=='-')
    {
        float s;
        s = (i-j);
        printf("%.1f", s);
    }
    else if(*c=='x')
    {
        float m;
        m = (i*j);
        printf("%.1f", m);
    }
    else if(*c=='/')
    {
        float d;
        d = (i/j);
        printf("%.1f", d);
    }
}