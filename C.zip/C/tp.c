#include <stdio.h>
int main()
{
    printf("manan");
}