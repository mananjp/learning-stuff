#include <stdio.h>

int main() {
   
    FILE *file;

 
    file = fopen("example.txt", "w");
    

    if (file == NULL) {
        perror("Error opening file");
        return 1; 
    }


    fprintf(file, "Hello, World!\n");
    fprintf(file, "This is a file created in C.\n");

    

    fclose(file);

    return 0; 
}
