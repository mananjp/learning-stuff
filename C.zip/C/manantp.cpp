#include <iostream>  // Include the standard input/output stream library

int main() {
    // Output "Hello, World!" to the console
    std::cout << "Hello manan" << std::endl;

    return 0;  // Return 0 to indicate successful execution
}
