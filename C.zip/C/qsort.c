#include <stdio.h>

// Function to swap two elements
void swap(int *x, int *y) {
    int t = *x;
    *x = *y;
    *y = t;
}

// Function to partition the array
int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // Pivot element
    int i = low - 1; // Index of smaller element

    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return i + 1;
}

// Quick sort function
void qsort(int arr[], int low, int high) {
    if (low < high) {
        int pr = partition(arr, low, high);
        qsort(arr, low, pr - 1);
        qsort(arr, pr + 1, high);
    }
}

// Main function
int main() {
    int arr[] = {44, 42, 12, 32, 53};
    int n = sizeof(arr) / sizeof(arr[0]);

    qsort(arr, 0, n - 1);

    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    return 0;
}
