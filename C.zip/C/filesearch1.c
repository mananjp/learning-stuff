#include <stdio.h>
#include <string.h>

int main() {
    
    FILE *file; //creating a file pointer
    char buffer[100]; //buffer reads the contents of the file
    char word[100]; //word is for user input

  
    printf("Enter a word to search for: ");
    fgets(word, sizeof(word), stdin); //getting user input
    word[strcspn(word, "\n")] = '\0'; //limiting space from given word to null

   
    file = fopen("example.txt", "r"); 

  
    if (file == NULL) {
        perror("Error opening file");
        return 1; 
    }

    int found = 0; //its a flag returns 1 if found else 0

 
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
       
        if (strstr(buffer, word) != NULL) {
            found = 1; 
            break; 
        }
    }

   
    if (found) {
        printf("Word found in the file.\n");
    } else {
        printf("Word not found in the file.\n");
    }

    fclose(file);
    return 0; 
}
