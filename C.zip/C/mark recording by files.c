#include <stdio.h>

int main() {
    FILE *file;
    int marks[5] = {90, 85, 78, 92, 88};
    int i;


    file = fopen("marks.txt", "w");
    if (file == NULL) {
        printf("Could not open file for writing\n");
        return 1;
    }

    for (i = 0; i < 5; i++) {
        putw(marks[i], file);
    }

    fclose(file);


    file = fopen("marks.txt", "r");
    if (file == NULL) {
        printf("Could not open file for reading\n");
        return 1;
    }

    printf("Student Marks:\n");
    for (i = 0; i < 5; i++) {
        int mark = getw(file);
        printf("%d\n", mark);
    }
    printf("name:Manan Panchal id:24AIMl024");

    fclose(file);
    return 0;
}
