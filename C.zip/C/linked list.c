// C program to show the implementation of singly linked
// list
#include <stdio.h>
#include <stdlib.h>

// A linked list node
struct Node {
    int data;
    struct Node* next;
};

// Constructor function to initialize a new node with data
struct Node* createNode(int new_data) {
    struct Node* new_node
        = (struct Node*)malloc(sizeof(struct Node));
    new_node->data = new_data;
    new_node->next = NULL;
    return new_node;
}

// Function to print the linked list
void printList(struct Node* head) {

    // Loop that runs till head is NULL
    while (head != NULL) {

        // Printing current node data
        printf(" %d", head->data);

        // Moving to the next node in the list
        head = head->next;
    }
    printf("\n");
}

// Driver code
int main() {

    // Create a hard-coded linked list:
    // 2 -> 3 -> 4 -> 5 -> 6
    struct Node* head = createNode(2);
    head->next = createNode(3);
    head->next->next = createNode(4);
    head->next->next->next = createNode(5);
    head->next->next->next->next = createNode(6);

    // Printing the above list
    printf("Linked List:");
    printList(head);

    return 0;
}
